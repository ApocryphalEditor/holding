# Intervention Activation Capture Log: epistemic_certainty_prompt_grid_template (L11N373) (20250416_092546)

## Run Parameters
- **Script Name**: `capture_intervened_activations.py`
- **Run Type**: `intervention_capture`
- **Model Name**: `gpt2`
- **Target Layer**: `11`
- **Target Neuron**: `373`
- **Intervention Hook**: `blocks.11.mlp.hook_post`
- **Capture Hook**: `blocks.11.mlp.hook_post`
- **Activation Dimension**: `3072`
- **Sweep Values**: `[None, 1, 3, 6, 10, 20, -1, -3, -6, -10, -20]`
- **Prompt File Path**: `promptsets\epistemic_certainty_prompt_grid_template.txt`
- **Prompt File Basename**: `epistemic_certainty_prompt_grid_template`
- **Num Prompts Parsed**: `140`
- **Generate Length**: `50`
- **Top K**: `greedy_or_default`
- **Run Timestamp**: `20250416_092546`
- **Run Directory**: `experiments\intervened_runs\capture_intervened_len50_L11N373_epistemic_certainty_prompt_grid_template_20250416_092546`
- **Output Vector File**: `experiments\intervened_runs\capture_intervened_len50_L11N373_epistemic_certainty_prompt_grid_template_20250416_092546\vectors\captured_vectors_intervened.npz`
- **Output Log File**: `experiments\intervened_runs\capture_intervened_len50_L11N373_epistemic_certainty_prompt_grid_template_20250416_092546\logs\run_log_intervened.md`
- **Output Metadata File**: `experiments\intervened_runs\capture_intervened_len50_L11N373_epistemic_certainty_prompt_grid_template_20250416_092546\metadata\run_metadata_intervened.json`
- **Device**: `cpu`

---

## Prompt Processing

### Prompt 1/140: core_id=presence_by_door_type=observational_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=observational_level=1_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=observational_level=1_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=observational_level=1_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=observational_level=1_sweep=6`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=observational_level=1_sweep=10`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to go to the hospital. I'm not going to be able to go to the hospital. I'm not going to be able to go to the hospital. I'm not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=observational_level=1_sweep=20`
- **Generated Text:**
```


"I'm not sure. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=observational_level=1_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=observational_level=1_sweep=-3`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened."

"I'm sorry, but I'm not sure what happened."

"I'm sorry, but I'm not sure what happened."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=observational_level=1_sweep=-6`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened."

"I'm sorry, but I'm not sure what happened."

"I'm sorry, but I'm not sure what happened."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=observational_level=1_sweep=-10`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened."

"I'm sorry, but I'm not sure what happened."

"I'm sorry, but I'm not sure what happened."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=observational_level=1_sweep=-20`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened."

"I'm sorry, but I'm not sure what happened."

"I'm sorry, but I'm not sure what happened."

"I'm
```
- **Result:** Vector captured successfully.


---
### Prompt 2/140: core_id=presence_by_door_type=declarative_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=declarative_level=1_sweep=baseline`
- **Generated Text:**
```


"I'm not sure," he said. "I'm not sure if it was a group of people or a group of people. I don't know. I don't know. I don't know. I don't know. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=declarative_level=1_sweep=1`
- **Generated Text:**
```


"I'm not sure," he said. "I'm not sure if it was a group of people or a group of people. I don't know. I don't know. I don't know. I don't know. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=declarative_level=1_sweep=3`
- **Generated Text:**
```


"I don't know what happened," he said. "I don't know what happened. I don't know what happened. I don't know what happened. I don't know what happened. I don't know what happened. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=declarative_level=1_sweep=6`
- **Generated Text:**
```


"I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=declarative_level=1_sweep=10`
- **Generated Text:**
```


"I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=declarative_level=1_sweep=20`
- **Generated Text:**
```


"I was there, I was there, I was there, I was there, I was there, I was there, I was there, I was there, I was there, I was there, I was there, I was there
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=declarative_level=1_sweep=-1`
- **Generated Text:**
```


"I'm not sure," he said. "I'm not sure if it was a group of people or just a couple of people."

The man said he was in the middle of a fight with a group of people when he
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=declarative_level=1_sweep=-3`
- **Generated Text:**
```


"I'm not sure," he said. "I'm not sure if it was a group of people or just a couple of people."

The man said he was in the middle of a fight with a group of people when he
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=declarative_level=1_sweep=-6`
- **Generated Text:**
```


"I'm not sure," he said. "I'm not sure if it was a group of people or just a couple of people."

The man said he was in the middle of a group of people when he heard a loud
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=declarative_level=1_sweep=-10`
- **Generated Text:**
```


"I'm not sure," he said. "I'm not sure if it was a group of people or just a couple of people."

The man said he was in his late 20s and had been living in the area for
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=declarative_level=1_sweep=-20`
- **Generated Text:**
```


"I'm sure they're not," said the woman who answered the door. "They're just trying to get their hands on some food."

The woman said she heard a loud bang and heard someone yell "get out of here
```
- **Result:** Vector captured successfully.


---
### Prompt 3/140: core_id=presence_by_door_type=authoritative_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=1_sweep=baseline`
- **Generated Text:**
```


"I think it's a good thing," he said. "I think it's a good thing for the team. I think it's a good thing for the team. I think it's a good thing for the team. I think
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=1_sweep=1`
- **Generated Text:**
```


"I think it's a good thing," he said. "I think it's a good thing for the team. I think it's a good thing for the team. I think it's a good thing for the team. I think
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=1_sweep=3`
- **Generated Text:**
```


"I think it's a good thing," he said. "I think it's a good thing for the team. I think it's a good thing for the team. I think it's a good thing for the team. I think
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=1_sweep=6`
- **Generated Text:**
```


"I think it's a good thing," he said. "I think it's a good thing for the team. I think it's a good thing for the team. I think it's a good thing for the team. I think
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=1_sweep=10`
- **Generated Text:**
```


"I think it's a good thing," he said. "I think it's a good thing for the team. I think it's a good thing for the team. I think it's a good thing for the team. I think
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=1_sweep=20`
- **Generated Text:**
```


"I think it's a little bit of a shock, but I think it's a little bit of a shock," he said. "I think it's a little bit of a shock. I think it's a little bit of a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=1_sweep=-1`
- **Generated Text:**
```


"I think it's a good thing," he said. "I think it's a good thing for the team. I think it's a good thing for the team. I think it's a good thing for the team. I think
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=1_sweep=-3`
- **Generated Text:**
```


"I think it's a good thing," he said. "I think it's a good thing for the team. I think it's a good thing for the team. I think it's a good thing for the team. I think
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=1_sweep=-6`
- **Generated Text:**
```


"I think it's a good thing," he said. "I think it's a good thing for the team. I think it's a good thing for the team. I think it's a good thing for the team. I think
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=1_sweep=-10`
- **Generated Text:**
```


"I think it's a good thing," he said. "I think it's a good thing for the team. I think it's a good thing for the team. I think it's a good thing for the team. I think
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=1_sweep=-20`
- **Generated Text:**
```


"I think it's a good sign," he said. "I think it's a good sign. I think it's a good sign. I think it's a good sign. I think it's a good sign. I think it
```
- **Result:** Vector captured successfully.


---
### Prompt 4/140: core_id=presence_by_door_type=rhetorical_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=1_sweep=baseline`
- **Generated Text:**
```


"I'm not sure what's going on," he says. "I'm not sure what's going on. I'm not sure what's going on. I'm not sure what's going on. I'm not sure what's going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=1_sweep=1`
- **Generated Text:**
```


"I'm not going to let you go," he says. "I'm not going to let you go."

"I'm not going to let you go," he says. "I'm not going to let you go."
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=1_sweep=3`
- **Generated Text:**
```


"I'm not going to let you go," he says. "I'm not going to let you go."

"I'm not going to let you go," he says. "I'm not going to let you go."
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=1_sweep=6`
- **Generated Text:**
```


"I'm not going to let you go," he says. "I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=1_sweep=10`
- **Generated Text:**
```


"I'm not going to let you go," he says. "I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=1_sweep=20`
- **Generated Text:**
```


"I'm not going to let you go," the man says. "I'm going to kill you. I'm going to kill you. I'm going to kill you. I'm going to kill you. I'm going to kill
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=1_sweep=-1`
- **Generated Text:**
```


"I'm not sure what's going on," he says. "I'm not sure what's going on. I'm not sure what's going on. I'm not sure what's going on. I'm not sure what's going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=1_sweep=-3`
- **Generated Text:**
```


"I'm not sure what's going on," he says. "I'm not sure what's going on. I'm not sure what's going on. I'm not sure what's going on. I'm not sure what's going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=1_sweep=-6`
- **Generated Text:**
```


"I'm not sure what's going on here," he says. "I'm not sure what's going on here."

"I'm not sure what's going on here," he says. "I'm not sure what's
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=1_sweep=-10`
- **Generated Text:**
```


"I'm not sure what's going on here," he says. "I'm not sure what's going on here."

"I'm not sure what's going on here," he says. "I'm not sure what's
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=1_sweep=-20`
- **Generated Text:**
```


"I'm afraid I'm not sure what's going on here," he says. "I'm afraid I'm not sure what's going on here."

"I'm afraid I'm not sure what's going on here," he
```
- **Result:** Vector captured successfully.


---
### Prompt 5/140: core_id=presence_by_door_type=observational_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=observational_level=2_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=observational_level=2_sweep=1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=observational_level=2_sweep=3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=observational_level=2_sweep=6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=observational_level=2_sweep=10`
- **Generated Text:**
```


"I'm not going to tell you what happened, but I'm going to tell you what happened. I'm going to tell you what happened. I'm going to tell you what happened. I'm going to tell you what happened.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=observational_level=2_sweep=20`
- **Generated Text:**
```


"I was in the middle of the night, and I saw a man in a black suit, and I was like, 'Oh my God, that's a black man!' And he was like, 'Oh my God, that's
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=observational_level=2_sweep=-1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=observational_level=2_sweep=-3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=observational_level=2_sweep=-6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=observational_level=2_sweep=-10`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said. "I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=observational_level=2_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


---
### Prompt 6/140: core_id=presence_by_door_type=declarative_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=declarative_level=2_sweep=baseline`
- **Generated Text:**
```
’’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=declarative_level=2_sweep=1`
- **Generated Text:**
```
’’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=declarative_level=2_sweep=3`
- **Generated Text:**
```
’’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=declarative_level=2_sweep=6`
- **Generated Text:**
```
’’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=declarative_level=2_sweep=10`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=declarative_level=2_sweep=20`
- **Generated Text:**
```


‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=declarative_level=2_sweep=-1`
- **Generated Text:**
```
’’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=declarative_level=2_sweep=-3`
- **Generated Text:**
```
’’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=declarative_level=2_sweep=-6`
- **Generated Text:**
```
’’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=declarative_level=2_sweep=-10`
- **Generated Text:**
```
’’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=declarative_level=2_sweep=-20`
- **Generated Text:**
```
’’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


---
### Prompt 7/140: core_id=presence_by_door_type=authoritative_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=2_sweep=baseline`
- **Generated Text:**
```


"We are aware of the situation and are working with the local authorities to resolve the situation," the statement said.

The incident comes as the US and Russia are working to resolve the crisis in Ukraine.

The US has said
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=2_sweep=1`
- **Generated Text:**
```


"We are aware of the situation and are working with the local authorities to resolve the situation," the statement said.

The incident comes as the US and Russia are working to resolve the crisis in Ukraine.

The US has said
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=2_sweep=3`
- **Generated Text:**
```


"The police are trying to get the people out of the building," said the police spokesman, who declined to give further details.

The incident comes as the government is trying to tackle a growing number of suicides in the country.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=2_sweep=6`
- **Generated Text:**
```


"The police were able to get a hold of the vehicle and the driver was arrested," the police said.

The driver of the car was not injured.

The incident was reported around 8:30 p.m. in
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=2_sweep=10`
- **Generated Text:**
```


"The police were able to get a hold of the vehicle and the driver was arrested," the police said.

The driver of the car was not injured.

The incident was reported around 8:30 p.m. in
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=2_sweep=20`
- **Generated Text:**
```


The incident was the latest in a series of incidents in which the police have been accused of targeting civilians in the past.

In July, a police officer was shot and killed in a shooting in the southern city of Kocay.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=2_sweep=-1`
- **Generated Text:**
```


"We are aware of the situation and are working with the local authorities to resolve it," the company said in a statement.

The company said it was working with the local authorities to resolve the issue.

The company said it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=2_sweep=-3`
- **Generated Text:**
```


"We are aware of the situation and are working with the local authorities to resolve it," the company said in a statement.

The company said it was working with the local authorities to resolve the issue.

The company said it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=2_sweep=-6`
- **Generated Text:**
```


"We are aware of the situation and are working with the local authorities to resolve it," the company said in a statement.

The company said it had been contacted by the authorities and that it was cooperating fully with them.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=2_sweep=-10`
- **Generated Text:**
```


"We have been informed that the vehicle was involved in a collision with a vehicle on the side of the road," the company said in a statement.

The company said it had received reports of injuries and that it had taken precautions to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=2_sweep=-20`
- **Generated Text:**
```


"We have been informed that a number of people have been injured and taken to hospital," said a spokesman for the provincial health department.

"We have been informed that a number of people have been injured and taken to hospital."

```
- **Result:** Vector captured successfully.


---
### Prompt 8/140: core_id=presence_by_door_type=rhetorical_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=2_sweep=baseline`
- **Generated Text:**
```


"I'm not sure if it was a man or a woman, but I think it was a man or a woman. I think it was a man or a woman. I think it was a man or a woman. I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=2_sweep=1`
- **Generated Text:**
```


"I'm not sure if it was a man or a woman, but I think it was a man or a woman. I think it was a man or a woman. I think it was a man or a woman. I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=2_sweep=3`
- **Generated Text:**
```


"I'm not sure if it was a man or a woman, but I think it was a man or a woman. I think it was a man or a woman. I think it was a man or a woman. I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=2_sweep=6`
- **Generated Text:**
```


"I'm not sure if it was a man or a woman, but I think it was a man or a woman. I don't know if it was a man or a woman, but I think it was a man or a woman
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=2_sweep=10`
- **Generated Text:**
```


"I was in the middle of the night, and I saw a man in a black hoodie, with a gun, and he was holding a gun. I was in the middle of the night, and I saw a man in a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=2_sweep=20`
- **Generated Text:**
```


"I was in the middle of the night, and I saw a man in a black T-shirt and a black T-shirt, and I was like, 'Oh my God, that's a black T-shirt!'"


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=2_sweep=-1`
- **Generated Text:**
```


"I'm not sure if it was a man or a woman, but I think it was a man or a woman," he said.

"I think it was a man or a woman, but I think it was a man
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=2_sweep=-3`
- **Generated Text:**
```


"I'm not sure what happened, but I think it was a prank. I don't know what happened, but I think it was a prank. I don't know what happened, but I think it was a prank. I don
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=2_sweep=-6`
- **Generated Text:**
```


"I'm not sure what happened, but I think it was a prank. I don't know what happened, but I think it was a prank. I don't know what happened, but I think it was a prank. I don
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=2_sweep=-10`
- **Generated Text:**
```


"I'm not sure what happened, but I think it was a prank," he said.

"I'm not sure what happened, but I think it was a prank," he said.

"I'm not sure what
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=2_sweep=-20`
- **Generated Text:**
```


"I'm sure someone was trying to get into my house," said one woman who asked not to be named.

"I heard someone screaming and screaming and screaming and screaming and screaming," said another woman who asked not to be named
```
- **Result:** Vector captured successfully.


---
### Prompt 9/140: core_id=presence_by_door_type=observational_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=observational_level=3_sweep=baseline`
- **Generated Text:**
```
 He was a man in his late thirties, with a beard and a mustache. He was dressed in a black suit and a black tie. He was wearing a black hat and a black tie. He was wearing a black hat and a black
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=observational_level=3_sweep=1`
- **Generated Text:**
```
 He was a man in his late thirties, with a beard and a beard that was long and thin, with a beard that was long and thin, and a beard that was long and thin. He was a man in his late thirt
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=observational_level=3_sweep=3`
- **Generated Text:**
```
 He was a man in his late thirties, with a beard and a beard that was long and thin, with a beard that was long and thin, and a beard that was long and thin. He was a man in his late thirt
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=observational_level=3_sweep=6`
- **Generated Text:**
```
 He was a young man, about twenty-five, with a beard and a beard that was long, and he was wearing a black hat and a black hat. He was wearing a black hat and a black hat. He was wearing a black hat
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=observational_level=3_sweep=10`
- **Generated Text:**
```
 He was a young man, and he was very young. He was very young. He was very young. He was very young. He was very young. He was very young. He was very young. He was very young. He was very
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=observational_level=3_sweep=20`
- **Generated Text:**
```
 He was a young man, and he was in his early thirties. He was in his early thirties. He was in his early thirties. He was in his early thirties. He was in his early thirt
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=observational_level=3_sweep=-1`
- **Generated Text:**
```
 He was wearing a black hoodie and a black T-shirt. He was wearing a black T-shirt and a black T-shirt. He was wearing a black T-shirt and a black T-shirt. He was wearing a black T
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=observational_level=3_sweep=-3`
- **Generated Text:**
```
 He was wearing a black hoodie and a black shirt. He was wearing a black hoodie and a black shirt. He was wearing a black hoodie and a black shirt. He was wearing a black hoodie and a black shirt. He was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=observational_level=3_sweep=-6`
- **Generated Text:**
```
 He was wearing a black hoodie and a black shirt. He was wearing a black hoodie and a black shirt. He was wearing a black hoodie and a black shirt. He was wearing a black hoodie and a black shirt. He was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=observational_level=3_sweep=-10`
- **Generated Text:**
```
 He was wearing a black hoodie and a black shirt. He was wearing a black hoodie and a black shirt. He was wearing a black hoodie and a black shirt. He was wearing a black hoodie and a black shirt. He was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=observational_level=3_sweep=-20`
- **Generated Text:**
```
 He was wearing a black suit and tie. He had a black tie and a black hat. He had a black hat and a black hat. He had a black hat and a black hat. He had a black hat and a black hat. He
```
- **Result:** Vector captured successfully.


---
### Prompt 10/140: core_id=presence_by_door_type=declarative_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=declarative_level=3_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=declarative_level=3_sweep=1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=declarative_level=3_sweep=3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=declarative_level=3_sweep=6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=declarative_level=3_sweep=10`
- **Generated Text:**
```
 He was wearing a black T-shirt and black jeans. He was holding a gun. He was holding a gun. He was holding a gun. He was holding a gun. He was holding a gun. He was holding a gun. He was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=declarative_level=3_sweep=20`
- **Generated Text:**
```
 He was in his early 20s, and he was in his early 30s. He was in his early 30s. He was in his early 30s. He was in his early 30s. He was in his early 30s. He
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=declarative_level=3_sweep=-1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=declarative_level=3_sweep=-3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=declarative_level=3_sweep=-6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=declarative_level=3_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=declarative_level=3_sweep=-20`
- **Generated Text:**
```


"What are you doing?" asked the man.

"I'm just trying to get some sleep," said the woman.

"What are you doing?" asked the man.

"I'm trying to get some sleep
```
- **Result:** Vector captured successfully.


---
### Prompt 11/140: core_id=presence_by_door_type=authoritative_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=3_sweep=baseline`
- **Generated Text:**
```


"The report confirms that the police have been involved in the investigation and that the investigation is ongoing," said the report.

"The police have been involved in the investigation and that the investigation is ongoing."

The report also says
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=3_sweep=1`
- **Generated Text:**
```


"The report confirms that the police have been involved in the investigation and that the investigation is ongoing," said the report.

"The police have been involved in the investigation and that the investigation is ongoing."

The report also says
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=3_sweep=3`
- **Generated Text:**
```


"The report confirms that the police have been involved in the investigation and that the investigation is ongoing," said the report.

"The police have been involved in the investigation and that the investigation is ongoing."

The report also says
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=3_sweep=6`
- **Generated Text:**
```


"The report confirms that the police were not involved in the incident," the police said in a statement.

The police said they were not aware of any other incidents involving the police.

The police said they were not aware of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=3_sweep=10`
- **Generated Text:**
```


"The report confirms that the police were not involved in the incident," the police said in a statement.

The police said the incident was not a terrorist attack.

"The police are investigating the incident and will provide further information
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=3_sweep=20`
- **Generated Text:**
```


The report, which was released by the U.S. Army, says the soldiers were in the area of the attack, and that the soldiers were not in the area of the attack.

The soldiers were not in the area of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=3_sweep=-1`
- **Generated Text:**
```


"The report confirms that the police have been involved in the investigation and that the investigation is ongoing," said the report.

"The police have been involved in the investigation and that the investigation is ongoing."

The report also says
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=3_sweep=-3`
- **Generated Text:**
```


"The report confirms that the group was involved in the attack on the mosque," said the report.

"The group was involved in the attack on the mosque, which was carried out by a group of men who were armed with knives
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=3_sweep=-6`
- **Generated Text:**
```


"The report confirms that the group has been involved in the recent attacks on the offices of the Islamic State of Iraq and the Levant (ISIL) and other terrorist groups in Syria and Iraq," the report said.

"The group
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=3_sweep=-10`
- **Generated Text:**
```


"The report confirms that the group has been involved in a number of attacks on the UK diplomatic premises in recent months," said the report.

"The group has been involved in a number of attacks on the UK diplomatic premises in recent
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=3_sweep=-20`
- **Generated Text:**
```


"We have been told that the group has been involved in a number of investigations into the matter," said a spokesman for the Department of Homeland Security.

"We have been told that they have been involved in investigations into the matter,"
```
- **Result:** Vector captured successfully.


---
### Prompt 12/140: core_id=presence_by_door_type=rhetorical_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=3_sweep=baseline`
- **Generated Text:**
```
 You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=3_sweep=1`
- **Generated Text:**
```
 You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=3_sweep=3`
- **Generated Text:**
```
 You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=3_sweep=6`
- **Generated Text:**
```
 It was like a little girl. She was so cute. She was so cute. She was so cute. She was so cute. She was so cute. She was so cute. She was so cute. She was so cute. She was so
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=3_sweep=10`
- **Generated Text:**
```
 It was like a little girl. She was so cute. She was so cute. She was so cute. She was so cute. She was so cute. She was so cute. She was so cute. She was so cute. She was so
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=3_sweep=20`
- **Generated Text:**
```
 It was like a light. It was like a light. It was like a light. It was like a light. It was like a light. It was like a light. It was like a light. It was like a light. It was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=3_sweep=-1`
- **Generated Text:**
```
 You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=3_sweep=-3`
- **Generated Text:**
```
 You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=3_sweep=-6`
- **Generated Text:**
```
 You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=3_sweep=-10`
- **Generated Text:**
```
 You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=3_sweep=-20`
- **Generated Text:**
```
 You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it.
```
- **Result:** Vector captured successfully.


---
### Prompt 13/140: core_id=presence_by_door_type=observational_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=observational_level=4_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=observational_level=4_sweep=1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=observational_level=4_sweep=3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=observational_level=4_sweep=6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=observational_level=4_sweep=10`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=observational_level=4_sweep=20`
- **Generated Text:**
```


"I'm not going to let you go," he said.

The police were called.

"I'm not going to let you go," he said.

The police were called.

"I'm not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=observational_level=4_sweep=-1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=observational_level=4_sweep=-3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=observational_level=4_sweep=-6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=observational_level=4_sweep=-10`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said. "I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=observational_level=4_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


---
### Prompt 14/140: core_id=presence_by_door_type=declarative_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=declarative_level=4_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not sure if you're sure. I'm sure you're not sure. I'm sure you're not sure. I'm sure you're not sure. I'm sure you're not sure. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=declarative_level=4_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not sure if you're going to be able to help me."

"I'm sorry, but I'm not sure if you're going to be able to help me."

"I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=declarative_level=4_sweep=3`
- **Generated Text:**
```


"I'm not sure if he was there, but I think he was there. I think he was there. I think he was there. I think he was there. I think he was there. I think he was there. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=declarative_level=4_sweep=6`
- **Generated Text:**
```


"I'm not sure if he was there, but I think he was there. I think he was there. I think he was there. I think he was there. I think he was there. I think he was there. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=declarative_level=4_sweep=10`
- **Generated Text:**
```


"I was just trying to get out of the car and get out of the car," he said. "I was just trying to get out of the car and get out of the car. I was just trying to get out of the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=declarative_level=4_sweep=20`
- **Generated Text:**
```


"I was in the car with my girlfriend, and she was in the back seat, and I was like, 'Oh my God, I'm so sorry, I was so sorry,'" he said. "I was like, 'I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=declarative_level=4_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not sure if you're sure. I'm sure you're not sure. I'm sure you're not sure. I'm sure you're not sure. I'm sure you're not sure. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=declarative_level=4_sweep=-3`
- **Generated Text:**
```


"I'm sorry, but I'm not sure if you're sure about that."

"I'm sorry, but I'm not sure if you're sure about that."

"I'm sorry, but I'm not sure
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=declarative_level=4_sweep=-6`
- **Generated Text:**
```


"I'm sorry, but I'm not sure if you're sure about that."

"I'm sorry, but I'm not sure if you're sure about that."

"I'm sorry, but I'm not sure
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=declarative_level=4_sweep=-10`
- **Generated Text:**
```


"I'm sorry, but I'm not sure if you're sure about that."

"I'm sorry, but I'm not sure if you're sure about that."

"I'm sorry, but I'm not sure
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=declarative_level=4_sweep=-20`
- **Generated Text:**
```


"I'm sure he's got some friends here," said one witness. "He's got friends here."

Another witness said he heard a loud bang and heard someone yell "get out of here!"

"I heard someone
```
- **Result:** Vector captured successfully.


---
### Prompt 15/140: core_id=presence_by_door_type=authoritative_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=4_sweep=baseline`
- **Generated Text:**
```


The attacker was able to gain access to the system and the system was shut down.

The attacker then used the same method to gain access to the system and the system was shut down.

The attacker then used the same method
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=4_sweep=1`
- **Generated Text:**
```


The attacker was able to gain access to the system and the system was shut down.

The attacker then used the same method to gain access to the system and the system was shut down.

The attacker then used the same method
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=4_sweep=3`
- **Generated Text:**
```


The attacker was able to gain access to the system and the system was shut down.

The attacker then used the same method to gain access to the system and the system was shut down.

The attacker then used the same method
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=4_sweep=6`
- **Generated Text:**
```


The attacker was able to gain access to the server and the server was shut down.

The attacker then used the same method to gain access to the server and the server was shut down.

The attacker then used the same method
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=4_sweep=10`
- **Generated Text:**
```


The attacker was able to connect to the server using the same credentials as the attacker.

The attacker was able to connect to the server using the same credentials as the attacker.

The attacker was able to connect to the server using
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=4_sweep=20`
- **Generated Text:**
```


The incident was captured on video by a security camera.

The incident was captured on video by a security camera.

The incident was captured on video by a security camera.

The incident was captured on video by a security
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=4_sweep=-1`
- **Generated Text:**
```


The attacker was able to gain access to the system and the system was shut down.

The attacker then used the same method to gain access to the system and the system was shut down.

The attacker then used the same method
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=4_sweep=-3`
- **Generated Text:**
```


The attacker was able to gain access to the system and the system was shut down.

The attacker then used the same method to gain access to the system and the system was shut down.

The attacker then used the same method
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=4_sweep=-6`
- **Generated Text:**
```


The attacker then used the same password to login to the server.

The attacker then used the same password to login to the server.

The attacker then used the same password to login to the server.

The attacker then
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=4_sweep=-10`
- **Generated Text:**
```


The attacker then used a different method to gain access to the victim's computer.

The attacker then used a different method to gain access to the victim's computer.

The attacker then used a different method to gain access to the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=4_sweep=-20`
- **Generated Text:**
```


The intruder was identified as a man named "Dylan" who had been living in the area for about two years.

Dylan had been living in the area for about two years.

Dylan had been living in the
```
- **Result:** Vector captured successfully.


---
### Prompt 16/140: core_id=presence_by_door_type=rhetorical_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=4_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=4_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=4_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=4_sweep=6`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to go to the hospital. I'm not going to be able to go to the hospital. I'm not going to be able to go to the hospital. I'm not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=4_sweep=10`
- **Generated Text:**
```


The man was a man of the people.

He was a man of the people.

He was a man of the people.

He was a man of the people.

He was a man of the people
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=4_sweep=20`
- **Generated Text:**
```


The man was a man of the people.

The man was a man of the people.

The man was a man of the people.

The man was a man of the people.

The man was a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=4_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=4_sweep=-3`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do."

"I'm sorry, but I'm not sure what to do."

"I'm sorry, but I'm not sure what to do."


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=4_sweep=-6`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do."

"I'm sorry, but I'm not sure what to do."

"I'm sorry, but I'm not sure what to do."


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=4_sweep=-10`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what you're talking about."

"I'm sorry, but I'm not sure what you're talking about."

"I'm sorry, but I'm not sure what you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=4_sweep=-20`
- **Generated Text:**
```


"I'm sorry, but I'm sorry."

"I'm sorry."

"I'm sorry."

"I'm sorry."

"I'm sorry."

"I'm sorry."

"
```
- **Result:** Vector captured successfully.


---
### Prompt 17/140: core_id=presence_by_door_type=observational_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=observational_level=5_sweep=baseline`
- **Generated Text:**
```
 She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=observational_level=5_sweep=1`
- **Generated Text:**
```
 She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=observational_level=5_sweep=3`
- **Generated Text:**
```
 She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=observational_level=5_sweep=6`
- **Generated Text:**
```
 She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=observational_level=5_sweep=10`
- **Generated Text:**
```
 She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=observational_level=5_sweep=20`
- **Generated Text:**
```
 She knew he was there. She knew he was there. She was in the middle of the night, and she was in the middle of the night, and she was in the middle of the night, and she was in the middle of the night
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=observational_level=5_sweep=-1`
- **Generated Text:**
```
 She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=observational_level=5_sweep=-3`
- **Generated Text:**
```
 She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=observational_level=5_sweep=-6`
- **Generated Text:**
```
 She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=observational_level=5_sweep=-10`
- **Generated Text:**
```
 She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=observational_level=5_sweep=-20`
- **Generated Text:**
```
 She knew he was there. She knew he was there.

"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she
```
- **Result:** Vector captured successfully.


---
### Prompt 18/140: core_id=presence_by_door_type=declarative_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=declarative_level=5_sweep=baseline`
- **Generated Text:**
```


‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=declarative_level=5_sweep=1`
- **Generated Text:**
```


‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=declarative_level=5_sweep=3`
- **Generated Text:**
```


‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=declarative_level=5_sweep=6`
- **Generated Text:**
```


‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=declarative_level=5_sweep=10`
- **Generated Text:**
```


‪I'm sorry, but I'm not sure if you're aware of this. I'm not sure if you're aware of this. I'm not sure if you're aware of this.

‪I'm sorry,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=declarative_level=5_sweep=20`
- **Generated Text:**
```


The video was shot in the middle of the night, and the video was not even in the video.

The video was shot in the middle of the night, and the video was not even in the video.

The video
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=declarative_level=5_sweep=-1`
- **Generated Text:**
```
’’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=declarative_level=5_sweep=-3`
- **Generated Text:**
```
’’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=declarative_level=5_sweep=-6`
- **Generated Text:**
```
’’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=declarative_level=5_sweep=-10`
- **Generated Text:**
```
’’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=declarative_level=5_sweep=-20`
- **Generated Text:**
```
 Someone was talking to me. Someone was talking to me. Someone was talking to me. Someone was talking to me. Someone was talking to me. Someone was talking to me. Someone was talking to me. Someone was talking to me. Someone was
```
- **Result:** Vector captured successfully.


---
### Prompt 19/140: core_id=presence_by_door_type=authoritative_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=5_sweep=baseline`
- **Generated Text:**
```


The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=5_sweep=1`
- **Generated Text:**
```


The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=5_sweep=3`
- **Generated Text:**
```


The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=5_sweep=6`
- **Generated Text:**
```


The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=5_sweep=10`
- **Generated Text:**
```


The logs are not the only source of information. The logs are also the source of the information that is used to make the decision to make a decision.

The logs are the source of the information that is used to make the decision
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=5_sweep=20`
- **Generated Text:**
```


The logs are not the only source of information. The logs are the only source of information.

The logs are the only source of information.

The logs are the only source of information.

The logs are the only
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=5_sweep=-1`
- **Generated Text:**
```


The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=5_sweep=-3`
- **Generated Text:**
```


The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=5_sweep=-6`
- **Generated Text:**
```


The first time I checked, I found that the logs were not verified.

The second time I checked, I found that the logs were not verified.

The third time I checked, I found that the logs were not verified
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=5_sweep=-10`
- **Generated Text:**
```


The first time I checked, I found that the logs were not verified.

The second time I checked, I found that the logs were not verified.

The third time I checked, I found that the logs were not verified
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=authoritative_level=5_sweep=-20`
- **Generated Text:**
```


The second is that the report is not a report of a single person. It is a report of a group of people who have been involved in a serious crime.

The third is that the report is not a report of a single
```
- **Result:** Vector captured successfully.


---
### Prompt 20/140: core_id=presence_by_door_type=rhetorical_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=5_sweep=baseline`
- **Generated Text:**
```


The first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=5_sweep=1`
- **Generated Text:**
```


The first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=5_sweep=3`
- **Generated Text:**
```


The first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=5_sweep=6`
- **Generated Text:**
```


The first thing you notice is the way the air is moving. The air is moving.

The air is moving.

The air is moving.

The air is moving.

The air is moving.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=5_sweep=10`
- **Generated Text:**
```


The first thing you notice when you're in the presence of a stranger is that you're not alone. You're not alone.

You're not alone.

You're not alone.

You're not alone.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=5_sweep=20`
- **Generated Text:**
```


The first thing you do when you're in the presence of a stranger is to look at them.

The second is to look at them.

The third is to look at them.

The fourth is to look at
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=5_sweep=-1`
- **Generated Text:**
```


The first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=5_sweep=-3`
- **Generated Text:**
```


The first thing you notice is that the words "I" and "me" are not interchangeable.

The second thing you notice is that the words "I" and "me" are not interchangeable.

The third thing you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=5_sweep=-6`
- **Generated Text:**
```


The first thing you notice is that the words are not just words. They are words.

The second thing you notice is that the words are not just words. They are words.

The third thing you notice is that the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=5_sweep=-10`
- **Generated Text:**
```


The first thing you notice is that the words are not just words. They are words.

The second thing you notice is that the words are not just words. They are words.

The third thing you notice is that the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=presence_by_door_type=rhetorical_level=5_sweep=-20`
- **Generated Text:**
```


It's not just about being present. It's about being present.

It's about being present.

It's about being present.

It's about being present.

It's about being present.


```
- **Result:** Vector captured successfully.


---
### Prompt 21/140: core_id=red_light_warning_type=observational_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=observational_level=1_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=observational_level=1_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=observational_level=1_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=observational_level=1_sweep=6`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do that. I'm not going to be able to do that. I'm not going to be able to do that. I'm not going to be able to do
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=observational_level=1_sweep=10`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do that. I'm not going to be able to do that. I'm not going to be able to do that. I'm not going to be able to do
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=observational_level=1_sweep=20`
- **Generated Text:**
```


"I'm not going to be in the room for a while, so I'll just go and get some air. I'll be back in the room by the time I get back."

"I'll be back in the room
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=observational_level=1_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=observational_level=1_sweep=-3`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what you're talking about. I'm not sure what you're talking about. I'm not sure what you're talking about. I'm not sure what you're talking about. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=observational_level=1_sweep=-6`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what you're talking about."

"I'm sorry, but I'm not sure what you're talking about."

"I'm sorry, but I'm not sure what you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=observational_level=1_sweep=-10`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what you're talking about."

"I'm sorry, but I'm not sure what you're talking about."

"I'm sorry, but I'm not sure what you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=observational_level=1_sweep=-20`
- **Generated Text:**
```


"What?"

"It's not like you're here to talk about it."

"I'm here to talk about it."

"I'm here to talk about it."

"I'm here to talk
```
- **Result:** Vector captured successfully.


---
### Prompt 22/140: core_id=red_light_warning_type=declarative_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=declarative_level=1_sweep=baseline`
- **Generated Text:**
```


The incident happened at about 8:30 p.m. on the west side of the intersection of West and West Streets.

The driver of the car was taken to the hospital with non-life threatening injuries.

The driver
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=declarative_level=1_sweep=1`
- **Generated Text:**
```


The incident was reported at about 11:30 p.m. on the west side of the intersection of West and West Streets.

The driver of the car was taken to the hospital with non-life threatening injuries.

The
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=declarative_level=1_sweep=3`
- **Generated Text:**
```


The incident was reported at about 11:30 p.m. on the west side of the intersection of West and West Streets.

The driver of the car was taken to the hospital with non-life threatening injuries.

The
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=declarative_level=1_sweep=6`
- **Generated Text:**
```


The incident was reported at about 8:30 p.m. on the west side of the intersection of West and West Streets.

The driver of the car was not injured.

The driver of the car was not injured.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=declarative_level=1_sweep=10`
- **Generated Text:**
```


The incident was reported at around 11:30 p.m. on the westbound lanes of the I-95 in the area of West and West Broadway.

The light was flashing at the time of the incident.

The
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=declarative_level=1_sweep=20`
- **Generated Text:**
```


The incident was captured on video by a security camera.

The incident was captured on video by a security camera.

The incident was captured on video by a security camera.

The incident was captured on video by a security
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=declarative_level=1_sweep=-1`
- **Generated Text:**
```


The man was taken to the hospital, where he was pronounced dead.

The man's family said he had been in a relationship with a woman for a year.

The man's mother said she was "very upset" about
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=declarative_level=1_sweep=-3`
- **Generated Text:**
```


The man was taken to hospital with minor injuries.

The man was taken to the hospital with minor injuries.

The man was taken to the hospital with minor injuries.

The man was taken to the hospital with minor injuries
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=declarative_level=1_sweep=-6`
- **Generated Text:**
```


The man was taken to hospital with minor injuries.

The man was taken to the hospital with minor injuries.

Police said the man was taken to the hospital with minor injuries.

The man was taken to the hospital with
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=declarative_level=1_sweep=-10`
- **Generated Text:**
```


The man was taken to hospital with minor injuries.

Police said the man was taken to hospital with minor injuries.

Anyone with information is asked to call Crime Stoppers on 1800 333 000 or Crime Stoppers anonymously on 1800 333
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=declarative_level=1_sweep=-20`
- **Generated Text:**
```


The report also said that the lights were flashing at least twice a minute.

The report also said that the lights were flashing at least twice a minute.

The report also said that the lights were flashing at least twice a minute
```
- **Result:** Vector captured successfully.


---
### Prompt 23/140: core_id=red_light_warning_type=authoritative_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=1_sweep=baseline`
- **Generated Text:**
```


"It's a very unusual situation," said Dr. David L. Smith, a professor of emergency medicine at the University of California, San Francisco. "It's a very unusual situation, and it's not unusual for a person to be
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=1_sweep=1`
- **Generated Text:**
```


"It's a very unusual situation," said Dr. David L. Smith, a professor of emergency medicine at the University of California, San Francisco. "It's a very unusual situation, and it's not unusual for a person to be
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=1_sweep=3`
- **Generated Text:**
```


"It's a very unusual situation," said Dr. David L. Karp, a professor of emergency medicine at the University of California, San Francisco. "It's a very unusual situation, and it's not unusual for a person to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=1_sweep=6`
- **Generated Text:**
```


"I think it's a false alarm," he said. "I think it's a false alarm. I think it's a false alarm. I think it's a false alarm. I think it's a false alarm. I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=1_sweep=10`
- **Generated Text:**
```


"I think it's a false alarm," he said. "I think it's a false alarm. I think it's a false alarm. I think it's a false alarm. I think it's a false alarm. I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=1_sweep=20`
- **Generated Text:**
```


"I think it's a false alarm, but I don't think it's a false alarm," he said.

The incident was captured on video by a security camera.

The incident was captured on video by a security camera
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=1_sweep=-1`
- **Generated Text:**
```


"It's a very unusual situation," said Dr. David L. Smith, a professor of medicine at the University of California, San Francisco. "It's a very unusual situation, and it's not unusual for a person to have a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=1_sweep=-3`
- **Generated Text:**
```


"It's a very common occurrence," said Dr. David L. Smith, a professor of emergency medicine at the University of California, San Francisco. "It's a very common occurrence in the emergency room. It's a very common occurrence
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=1_sweep=-6`
- **Generated Text:**
```


"It's a very common occurrence," said Dr. David L. Smith, a professor of medicine at the University of California, San Francisco. "It's a very common occurrence in the United States, and it's a very common occurrence
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=1_sweep=-10`
- **Generated Text:**
```


"It's a very common occurrence," said Dr. David L. Smith, a professor of medicine at the University of California, San Francisco. "It's a very common occurrence in the United States."

The alarm was triggered by
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=1_sweep=-20`
- **Generated Text:**
```


"It's a very simple thing to do," said Dr. Robert L. Lienert, professor emeritus of medicine at the University of California, San Francisco School of Medicine. "It's just a simple thing to do."

```
- **Result:** Vector captured successfully.


---
### Prompt 24/140: core_id=red_light_warning_type=rhetorical_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=1_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=1_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=1_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=1_sweep=6`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=1_sweep=10`
- **Generated Text:**
```


"I'm not sure what the hell is going on here, but I'm sure you're not going to be able to see it. I'm sure you're going to be able to see it. I'm sure you're going to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=1_sweep=20`
- **Generated Text:**
```


"I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=1_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=1_sweep=-3`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=1_sweep=-6`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do."

"I'm sorry, but I'm not sure what to do."

"I'm sorry, but I'm not sure what to do."


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=1_sweep=-10`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what you're talking about."

"I'm sorry, but I'm not sure what you're talking about."

"I'm sorry, but I'm not sure what you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=1_sweep=-20`
- **Generated Text:**
```


"I'm sorry, sir."

"I'm sorry, sir."

"I'm sorry, sir."

"I'm sorry, sir."

"I'm sorry, sir."

"I'm
```
- **Result:** Vector captured successfully.


---
### Prompt 25/140: core_id=red_light_warning_type=observational_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=observational_level=2_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do," she said. "I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=observational_level=2_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do," she said. "I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=observational_level=2_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=observational_level=2_sweep=6`
- **Generated Text:**
```


"I'm not sure what you're talking about," she said. "I'm not sure what you're talking about."

"I'm not sure what you're talking about," she said. "I'm not sure what you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=observational_level=2_sweep=10`
- **Generated Text:**
```


"I'm not sure what you're talking about," she said. "I'm not sure what you're talking about. I'm not sure what you're talking about. I'm not sure what you're talking about. I'm not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=observational_level=2_sweep=20`
- **Generated Text:**
```


"I'm not going to be in the room for a while," he said. "I'm going to be in the room for a while. I'm going to be in the room for a while. I'm going to be in
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=observational_level=2_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do," she said. "I'm not sure what to do."

"I'm sorry, but I'm not sure what to do," she said. "I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=observational_level=2_sweep=-3`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do," she said. "I'm not sure what to do."

"I'm sorry, but I'm not sure what to do," she said. "I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=observational_level=2_sweep=-6`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what you're talking about," she said. "I'm just wondering if you're sure you're not going to be able to get back to me."

"I'm sure you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=observational_level=2_sweep=-10`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what you're talking about," she said. "I'm just wondering if you're sure you're not going to be able to get back to me."

"I'm sure you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=observational_level=2_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said softly. "I'm sorry."

"I'm sorry," he said softly. "I'm sorry."

"I'm sorry," she said softly. "I'm sorry."


```
- **Result:** Vector captured successfully.


---
### Prompt 26/140: core_id=red_light_warning_type=declarative_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=declarative_level=2_sweep=baseline`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=declarative_level=2_sweep=1`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=declarative_level=2_sweep=3`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=declarative_level=2_sweep=6`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=declarative_level=2_sweep=10`
- **Generated Text:**
```


The video shows the police officer, who is wearing a black T-shirt and black pants, standing in front of the car.

The video shows the officer, who is wearing a black T-shirt and black pants, standing in
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=declarative_level=2_sweep=20`
- **Generated Text:**
```


The video shows the helicopter flying over the area, and the helicopter's pilot, who is in his 30s, is seen flying over the area.

The helicopter is seen flying over the area, and the helicopter's pilot, who
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=declarative_level=2_sweep=-1`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=declarative_level=2_sweep=-3`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=declarative_level=2_sweep=-6`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=declarative_level=2_sweep=-10`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=declarative_level=2_sweep=-20`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


---
### Prompt 27/140: core_id=red_light_warning_type=authoritative_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=2_sweep=baseline`
- **Generated Text:**
```


The light activity is measured by the light-emitting diode (LED) of the light source. The LED is a small, light-emitting diode (LED) that is connected to a power supply. The LED is connected
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=2_sweep=1`
- **Generated Text:**
```


The light activity is measured by the light-emitting diode (LED) of the light source. The light source is a small, cylindrical device that is connected to a power supply. The light source is connected to a power
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=2_sweep=3`
- **Generated Text:**
```


The light activity is the amount of light that is emitted by a given object.

The light activity is the amount of light that is emitted by a given object.

The light activity is the amount of light that is emitted by
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=2_sweep=6`
- **Generated Text:**
```


The light activity is the amount of light that is emitted by the light source.

The light activity is the amount of light that is emitted by the light source.

The light activity is the amount of light that is emitted by
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=2_sweep=10`
- **Generated Text:**
```


The light activity is the amount of light that is reflected from the surface of the object.

The light activity is the amount of light that is reflected from the surface of the object.

The light activity is the amount of light
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=2_sweep=20`
- **Generated Text:**
```


The light activity of the light source is the amount of light that is reflected from the light source. The light activity of the light source is the amount of light that is reflected from the light source.

The light activity of the light
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=2_sweep=-1`
- **Generated Text:**
```


The light activity is measured by the light-emitting diode (LED) of the device. The LED is connected to the device via a USB port. The device is powered by a USB power supply.

The device is powered
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=2_sweep=-3`
- **Generated Text:**
```


The light activity is measured by the wavelength of the light emitted by the light source. The wavelength of the light emitted by the light source is measured by the wavelength of the light emitted by the light source.

The light activity is measured
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=2_sweep=-6`
- **Generated Text:**
```


The following table lists the possible light activity levels for each of the following conditions:

Light activity level (in degrees)

Light activity level (in degrees)

Light activity level (in degrees)

Light activity level
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=2_sweep=-10`
- **Generated Text:**
```


The following table summarizes the data for each of the three groups.

Group 1: Light Activity

Group 2: Light Activity

Group 3: Light Activity

Group 4: Light Activity

Group 5: Light Activity
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=2_sweep=-20`
- **Generated Text:**
```


The study found that the average age of participants who had been diagnosed with schizophrenia was 19.5 years.

"This study demonstrates that schizophrenia can be treated with medication," said Dr. Robert L. Lott, professor of psychiatry at
```
- **Result:** Vector captured successfully.


---
### Prompt 28/140: core_id=red_light_warning_type=rhetorical_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=2_sweep=baseline`
- **Generated Text:**
```


"I'm not going to tell you what to do," he said. "I'm not going to tell you what to do. I'm not going to tell you what to do. I'm not going to tell you what to do
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=2_sweep=1`
- **Generated Text:**
```


"I'm not going to tell you what to do," he said. "I'm not going to tell you what to do. I'm not going to tell you what to do. I'm not going to tell you what to do
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=2_sweep=3`
- **Generated Text:**
```


"I'm not going to tell you what to do," he said. "I'm not going to tell you what to do. I'm not going to tell you what to do. I'm not going to tell you what to do
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=2_sweep=6`
- **Generated Text:**
```


"I'm not going to be able to do that," he said. "I'm not going to be able to do that. I'm not going to be able to do that. I'm not going to be able to do that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=2_sweep=10`
- **Generated Text:**
```


"I'm not going to be able to do that," he said. "I'm not going to be able to do that. I'm not going to be able to do that. I'm not going to be able to do that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=2_sweep=20`
- **Generated Text:**
```


"I'm not going to be in the air, I'm not going to be in the air, I'm not going to be in the air, I'm not going to be in the air, I'm not going to be in
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=2_sweep=-1`
- **Generated Text:**
```


"I'm not going to tell you what to do," he said. "I'm not going to tell you what to do. I'm not going to tell you what to do. I'm not going to tell you what to do
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=2_sweep=-3`
- **Generated Text:**
```


"I'm not going to tell you what to do," he said. "I'm not going to tell you what to do. I'm not going to tell you what to do. I'm not going to tell you what to do
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=2_sweep=-6`
- **Generated Text:**
```


"I'm not going to tell you what to do," he said. "I'm not going to tell you what to do."

He was talking about the fact that he had been in the hospital for two days, and that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=2_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=2_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


---
### Prompt 29/140: core_id=red_light_warning_type=observational_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=observational_level=3_sweep=baseline`
- **Generated Text:**
```


"I'm going to go to the hospital," he said. "I'm going to get my life back."

The man was taken to the hospital with a gunshot wound to the head.

The man was taken to the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=observational_level=3_sweep=1`
- **Generated Text:**
```


"I'm going to go to the hospital," he said. "I'm going to get my life back."

The man was taken to the hospital with a gunshot wound to the head.

The man was taken to the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=observational_level=3_sweep=3`
- **Generated Text:**
```


"I'm going to go to the hospital," he said. "I'm going to get my life back."

The man was taken to the hospital with a gunshot wound to the head.

The man was taken to the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=observational_level=3_sweep=6`
- **Generated Text:**
```


"I'm going to go to the hospital," he says. "I'm going to go to the hospital. I'm going to go to the hospital. I'm going to go to the hospital. I'm going to go to the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=observational_level=3_sweep=10`
- **Generated Text:**
```


The police are still investigating the incident.

The incident was reported at around 11.30am on the same day as the incident in the city of Kolkata.

The incident was reported at around 11.30am on
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=observational_level=3_sweep=20`
- **Generated Text:**
```


The police are still looking for the man.

The man was in the back of the car when the incident happened.

He was in the back of the car when the incident happened.

The man was in the back
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=observational_level=3_sweep=-1`
- **Generated Text:**
```


"I'm going to go to the hospital," he said. "I'm going to get my life back."

The man was taken to the hospital with a gunshot wound to the head.

The man was taken to the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=observational_level=3_sweep=-3`
- **Generated Text:**
```


"I'm not going to be able to do anything about it," he said. "I'm not going to be able to do anything about it."

The man was arrested and charged with aggravated assault, assault with a deadly weapon
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=observational_level=3_sweep=-6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=observational_level=3_sweep=-10`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=observational_level=3_sweep=-20`
- **Generated Text:**
```


"I'm sorry, sir," said the man who had been shouting at me. "I'm sorry, sir."

"I'm sorry," said the man who had been shouting at me. "I'm sorry, sir."
```
- **Result:** Vector captured successfully.


---
### Prompt 30/140: core_id=red_light_warning_type=declarative_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=declarative_level=3_sweep=baseline`
- **Generated Text:**
```


The driver of the car was taken to the hospital, where he was pronounced dead.

The driver of the car was taken to the hospital, where he was pronounced dead. Photo: Supplied

The driver of the car was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=declarative_level=3_sweep=1`
- **Generated Text:**
```


The police said the man was arrested and charged with aggravated assault.

The man was taken to the hospital with non-life threatening injuries.

The man was taken to the hospital with non-life threatening injuries.

The
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=declarative_level=3_sweep=3`
- **Generated Text:**
```


The police said the man was arrested and charged with aggravated assault.

The man was taken to the hospital with non-life threatening injuries.

The man was taken to the hospital with non-life threatening injuries.

The
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=declarative_level=3_sweep=6`
- **Generated Text:**
```


The police said the driver was not injured.

The driver was taken to the hospital with non-life-threatening injuries.

The driver was not injured in the crash.

The driver was not injured in the crash.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=declarative_level=3_sweep=10`
- **Generated Text:**
```


The police said the driver was not in the car at the time of the crash.

The driver of the car was not injured.

The driver of the car was not injured.

The driver of the car was not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=declarative_level=3_sweep=20`
- **Generated Text:**
```


The incident was captured on video by a police helicopter.

The incident was captured on video by a police helicopter.

The incident was captured on video by a police helicopter.

The incident was captured on video by a police
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=declarative_level=3_sweep=-1`
- **Generated Text:**
```


"We're not going to be able to do anything about it," said the officer, who asked not to be identified.

The officer said he was not aware of any other incidents involving the vehicle.

The officer said he
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=declarative_level=3_sweep=-3`
- **Generated Text:**
```


"We're not going to be able to get a ticket for this," said the officer, who asked not to be identified.

The officer said he was told by the officer that the suspect was a "very nice guy" and
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=declarative_level=3_sweep=-6`
- **Generated Text:**
```


"We're not going to be able to get a ticket for this," said the officer, who asked not to be identified.

The officer said he was told by the officer that the suspect was wearing a black hoodie and a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=declarative_level=3_sweep=-10`
- **Generated Text:**
```


"We're not going to be able to get a ticket for this," said Officer John D. Smith, who was on duty at the time.

The officer said he was told by the officer that he had been ticketed for
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=declarative_level=3_sweep=-20`
- **Generated Text:**
```


"We're not sure what happened," said Officer John Daley, who responded to the scene. "We're not sure what happened."

Officers found a man unconscious in a bathroom stall. Officers found a man unconscious in a bathroom
```
- **Result:** Vector captured successfully.


---
### Prompt 31/140: core_id=red_light_warning_type=authoritative_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=3_sweep=baseline`
- **Generated Text:**
```


The following is a list of all the logs that are available for the following:

Logs that are not logged in

Logs that are not logged in

Logs that are not logged in

Logs that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=3_sweep=1`
- **Generated Text:**
```


The following is a list of all the logs that are available for the following:

Logs that are not logged in

Logs that are not logged in

Logs that are not logged in

Logs that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=3_sweep=3`
- **Generated Text:**
```


The following is a list of all the logs that are available for the following:

The following is a list of all the logs that are available for the following:

The following is a list of all the logs that are available
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=3_sweep=6`
- **Generated Text:**
```


The following is a list of the log files that are available for the following:

logs.txt

logs.txt.log

logs.txt.log.log.log.log.log.log
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=3_sweep=10`
- **Generated Text:**
```


The following is a list of the log files that are available for the following:

C:\Users\jeff\AppData\Local\Temp\logs\

C:\Users\jeff\AppData\Local\Temp
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=3_sweep=20`
- **Generated Text:**
```


The following logs are for the following systems:

Windows 7

Windows 8.1

Windows 8.1.1

Windows 8.1.2

Windows 8.1.3

Windows 8.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=3_sweep=-1`
- **Generated Text:**
```


The following is a list of all the logs that are available for the following:

Logs that are not logged in

Logs that are not logged in

Logs that are not logged in

Logs that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=3_sweep=-3`
- **Generated Text:**
```


The following are the logs that were sent to the server:

Logs:

Logs:

Logs:

Logs:

Logs:

Logs:

Logs:

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=3_sweep=-6`
- **Generated Text:**
```


The following are the logs that were sent to the server:

Logs:

Logs:

Logs:

Logs:

Logs:

Logs:

Logs:

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=3_sweep=-10`
- **Generated Text:**
```


The following table shows the status of the system logs.

Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status Status
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=3_sweep=-20`
- **Generated Text:**
```


The next step is to check if the user has logged into the account.

If the user has logged into the account, then the user can choose to continue to use the account.

If the user has logged into the account
```
- **Result:** Vector captured successfully.


---
### Prompt 32/140: core_id=red_light_warning_type=rhetorical_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=3_sweep=baseline`
- **Generated Text:**
```


"I'm going to be the one to get you out of here," he says. "I'm going to be the one to get you out of here."

He's right.

The next day, he's back
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=3_sweep=1`
- **Generated Text:**
```


The light flashes. The moment begins.

The light flashes. The moment begins.

The light flashes. The moment begins.

The light flashes. The moment begins.

The light flashes. The moment begins.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=3_sweep=3`
- **Generated Text:**
```


The light flashes. The moment begins.

The light flashes. The moment begins.

The light flashes. The moment begins.

The light flashes. The moment begins.

The light flashes. The moment begins.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=3_sweep=6`
- **Generated Text:**
```


The light flashes. The moment begins.

The light flashes. The moment begins.

The light flashes. The moment begins.

The light flashes. The moment begins.

The light flashes. The moment begins.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=3_sweep=10`
- **Generated Text:**
```


The light flashes. The moment begins.

The light flashes. The moment begins.

The light flashes. The moment begins.

The light flashes. The moment begins.

The light flashes. The moment begins.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=3_sweep=20`
- **Generated Text:**
```


The light flashes. The moment begins.

The light flashes. The moment begins.

The light flashes. The moment begins.

The light flashes. The moment begins.

The light flashes. The moment begins.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=3_sweep=-1`
- **Generated Text:**
```


"I'm going to be the one to get you out of here," he says. "I'm going to be the one to get you out of here."

He's right.

The next day, he's back
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=3_sweep=-3`
- **Generated Text:**
```


"I'm going to be here for a while," he says. "I'm going to be here for a while."

He's not sure what he's going to do. He's not sure what he's going to do
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=3_sweep=-6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=3_sweep=-10`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=3_sweep=-20`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he says softly. "I'm sorry."

"I'm sorry," she says softly. "I'm sorry."

"I'm sorry," he says softly. "I'm
```
- **Result:** Vector captured successfully.


---
### Prompt 33/140: core_id=red_light_warning_type=observational_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=observational_level=4_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=observational_level=4_sweep=1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=observational_level=4_sweep=3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=observational_level=4_sweep=6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=observational_level=4_sweep=10`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to see you," she said.

"I'm sorry, but I'm not going to be able to see you," she said.

"I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=observational_level=4_sweep=20`
- **Generated Text:**
```


"I'm not going to let you go," the man said.

"I'm not going to let you go," the red light said.

"I'm not going to let you go," the red light said.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=observational_level=4_sweep=-1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=observational_level=4_sweep=-3`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=observational_level=4_sweep=-6`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=observational_level=4_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=observational_level=4_sweep=-20`
- **Generated Text:**
```


"What?"

"You're not sure what happened?"

"No, I'm not sure what happened."

"What happened?"

"I'm not sure what happened."

"What happened?"

```
- **Result:** Vector captured successfully.


---
### Prompt 34/140: core_id=red_light_warning_type=declarative_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=declarative_level=4_sweep=baseline`
- **Generated Text:**
```
 The car is moving. The driver is in the back seat. The driver is in the front seat. The driver is in the back seat. The driver is in the front seat. The driver is in the back seat. The driver is in the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=declarative_level=4_sweep=1`
- **Generated Text:**
```
 The car is in the middle of the road. The driver is in the middle of the road. The driver is in the middle of the road. The driver is in the middle of the road. The driver is in the middle of the road.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=declarative_level=4_sweep=3`
- **Generated Text:**
```
 The car is in the middle of the road. The driver is in the back seat. The driver is in the front seat. The driver is in the back seat. The driver is in the front seat. The driver is in the back seat.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=declarative_level=4_sweep=6`
- **Generated Text:**
```
 The car is in the middle of the road. The driver is in the back seat. The driver is in the front seat. The driver is in the back seat. The driver is in the front seat. The driver is in the back seat.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=declarative_level=4_sweep=10`
- **Generated Text:**
```
 The car is in the middle of the road. The driver is in the passenger seat. The driver is in the passenger seat. The driver is in the passenger seat. The driver is in the passenger seat. The driver is in the passenger seat.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=declarative_level=4_sweep=20`
- **Generated Text:**
```
 The car is in the air. The car is in the air. The car is in the air. The car is in the air. The car is in the air. The car is in the air. The car is in the air. The
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=declarative_level=4_sweep=-1`
- **Generated Text:**
```
 The car is moving. The driver is in the back seat. The driver is in the front seat. The driver is in the back seat. The driver is in the front seat. The driver is in the back seat. The driver is in the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=declarative_level=4_sweep=-3`
- **Generated Text:**
```
 The car is moving. The driver is in the back seat. The driver is in the front seat. The driver is in the back seat. The driver is in the front seat. The driver is in the back seat. The driver is in the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=declarative_level=4_sweep=-6`
- **Generated Text:**
```
 The car is going down. The driver is screaming. The driver is screaming. The driver is screaming. The driver is screaming. The driver is screaming. The driver is screaming. The driver is screaming. The driver is screaming. The driver is screaming
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=declarative_level=4_sweep=-10`
- **Generated Text:**
```
 The car is parked in front of the house. The driver is wearing a black hoodie and a black T-shirt. He is wearing a black hoodie and a black T-shirt. He is wearing a black hoodie and a black T
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=declarative_level=4_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said again. "I'm sorry."

"I'm sorry," she said again. "I'm sorry."

"
```
- **Result:** Vector captured successfully.


---
### Prompt 35/140: core_id=red_light_warning_type=authoritative_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=4_sweep=baseline`
- **Generated Text:**
```


The incident was reported at about 11:30 p.m.

The incident was reported at about 11:30 p.m.

The incident was reported at about 11:30 p.m.

The incident was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=4_sweep=1`
- **Generated Text:**
```


The incident was reported at 8:30 p.m. on the same day as the incident at the University of California, Berkeley.

The UC Berkeley Police Department is investigating the incident.

The incident is under investigation by the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=4_sweep=3`
- **Generated Text:**
```


The incident was reported at 8:30 p.m. on the westbound lanes of the I-95 in the area of Westlake Avenue and Westlake Avenue.

The driver of the vehicle was taken to the hospital with non
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=4_sweep=6`
- **Generated Text:**
```


The incident was reported at 8:30 p.m. on the westbound lanes of the I-95 in the area of West Main Street and West Main Street.

The driver of the vehicle was taken to the hospital with non
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=4_sweep=10`
- **Generated Text:**
```


The incident was reported at 8:30 p.m. on the westbound lanes of the I-95 in the area of West Main Street and West Main Street.

The incident was reported at 8:30 p.m.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=4_sweep=20`
- **Generated Text:**
```
 The incident was reported to the police.

The incident was reported to the police.

The incident was reported to the police.

The incident was reported to the police.

The incident was reported to the police.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=4_sweep=-1`
- **Generated Text:**
```


The incident was reported at about 11:30 p.m.

The incident was reported at about 11:30 p.m.

The incident was reported at about 11:30 p.m.

The incident was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=4_sweep=-3`
- **Generated Text:**
```


The incident was reported at about 11:30 p.m.

The incident was reported at about 11:30 p.m.

The incident was reported at about 11:30 p.m.

The incident was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=4_sweep=-6`
- **Generated Text:**
```


The incident was reported at about 11:30 p.m.

The victim was taken to a hospital where he was pronounced dead at about 1:30 a.m.

The investigation is ongoing.

AlertMe
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=4_sweep=-10`
- **Generated Text:**
```


The team then used a combination of ultrasound and a CT scan to determine the cause of death.

The team found that the body had been left in a state of shock and had been left in a state of shock for about two hours
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=4_sweep=-20`
- **Generated Text:**
```


"We have been informed that the suspect has been taken into custody," said a spokesman for the Metropolitan Police Department.

"We are investigating the circumstances surrounding this incident."

Topics: law-crime-and-justice, law
```
- **Result:** Vector captured successfully.


---
### Prompt 36/140: core_id=red_light_warning_type=rhetorical_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=4_sweep=baseline`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=4_sweep=1`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=4_sweep=3`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=4_sweep=6`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=4_sweep=10`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=4_sweep=20`
- **Generated Text:**
```
 The light is the light of the light. The light is the light of the light. The light is the light of the light. The light is the light of the light. The light is the light of the light. The light is the light
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=4_sweep=-1`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=4_sweep=-3`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=4_sweep=-6`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=4_sweep=-10`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=4_sweep=-20`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


---
### Prompt 37/140: core_id=red_light_warning_type=observational_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=observational_level=5_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this," he says. "I'm not going to be able to do this. I'm not going to be able to do this. I'm not going to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=observational_level=5_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this," he says. "I'm not going to be able to do this. I'm not going to be able to do this. I'm not going to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=observational_level=5_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this," he says. "I'm not going to be able to do this. I'm not going to be able to do this. I'm not going to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=observational_level=5_sweep=6`
- **Generated Text:**
```


The light is still there.

The light is still there.

The light is still there.

The light is still there.

The light is still there.

The light is still there.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=observational_level=5_sweep=10`
- **Generated Text:**
```


The light is still there.

The light is still there.

The light is still there.

The light is still there.

The light is still there.

The light is still there.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=observational_level=5_sweep=20`
- **Generated Text:**
```


The light is still there.

The light is still there.

The light is still there.

The light is still there.

The light is still there.

The light is still there.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=observational_level=5_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this," he says. "I'm not going to be able to do this. I'm not going to be able to do this. I'm not going to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=observational_level=5_sweep=-3`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do," she says. "I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=observational_level=5_sweep=-6`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do," she says. "I'm not sure what to do. I'm not sure what to do. I'm not sure what to do."

"I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=observational_level=5_sweep=-10`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do," she says. "I'm not sure what to do."

"I'm sorry, but I'm not sure what to do," she says. "I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=observational_level=5_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said softly. "I'm sorry."

"I'm sorry," he said softly. "I'm sorry."

"I'm sorry," she said softly. "I'm sorry."


```
- **Result:** Vector captured successfully.


---
### Prompt 38/140: core_id=red_light_warning_type=declarative_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=declarative_level=5_sweep=baseline`
- **Generated Text:**
```


The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=declarative_level=5_sweep=1`
- **Generated Text:**
```


The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=declarative_level=5_sweep=3`
- **Generated Text:**
```


The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=declarative_level=5_sweep=6`
- **Generated Text:**
```


The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=declarative_level=5_sweep=10`
- **Generated Text:**
```


The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=declarative_level=5_sweep=20`
- **Generated Text:**
```


The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=declarative_level=5_sweep=-1`
- **Generated Text:**
```


The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=declarative_level=5_sweep=-3`
- **Generated Text:**
```


The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=declarative_level=5_sweep=-6`
- **Generated Text:**
```


The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=declarative_level=5_sweep=-10`
- **Generated Text:**
```


The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=declarative_level=5_sweep=-20`
- **Generated Text:**
```


The next time you're in the office, take a moment to check your email or call your cell phone to report a suspicious person.

AlertMe
```
- **Result:** Vector captured successfully.


---
### Prompt 39/140: core_id=red_light_warning_type=authoritative_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=5_sweep=baseline`
- **Generated Text:**
```


The system is now in the process of being upgraded to a new version.

The system is now in the process of being upgraded to a new version.

The system is now in the process of being upgraded to a new version
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=5_sweep=1`
- **Generated Text:**
```


The system is now in the process of being upgraded to a new version.

The system is now in the process of being upgraded to a new version.

The system is now in the process of being upgraded to a new version
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=5_sweep=3`
- **Generated Text:**
```


The system is now in the process of being upgraded to a new version.

The system is now in the process of being upgraded to a new version.

The system is now in the process of being upgraded to a new version
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=5_sweep=6`
- **Generated Text:**
```


The system is in the process of being upgraded to a new version.

The system is in the process of being upgraded to a new version.

The system is in the process of being upgraded to a new version.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=5_sweep=10`
- **Generated Text:**
```


The system is in the process of being upgraded to a new version.

The system is in the process of being upgraded to a new version.

The system is in the process of being upgraded to a new version.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=5_sweep=20`
- **Generated Text:**
```


The system is in the process of being upgraded to a new, more secure, and more secure operating system.

The system is in the process of being upgraded to a new, more secure, and more secure operating system.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=5_sweep=-1`
- **Generated Text:**
```


The system is now in the process of being upgraded to a new version.

The system is now in the process of being upgraded to a new version.

The system is now in the process of being upgraded to a new version
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=5_sweep=-3`
- **Generated Text:**
```


The system is now in the process of being upgraded to a new version.

The system is now in the process of being upgraded to a new version.

The system is now in the process of being upgraded to a new version
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=5_sweep=-6`
- **Generated Text:**
```


The system is now in the process of being upgraded to a new version.

The system is now in the process of being upgraded to a new version.

The system is now in the process of being upgraded to a new version
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=5_sweep=-10`
- **Generated Text:**
```


The first time I saw this, I was shocked. I had never seen this before.

I had never seen this before.

I had never seen this before.

I had never seen this before.

I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=authoritative_level=5_sweep=-20`
- **Generated Text:**
```


The report also found that the company had been unable to find a way to fix the problem.

"We have been unable to find a way to fix this problem," said a company spokesperson.

The company has been unable to
```
- **Result:** Vector captured successfully.


---
### Prompt 40/140: core_id=red_light_warning_type=rhetorical_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=5_sweep=baseline`
- **Generated Text:**
```


The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=5_sweep=1`
- **Generated Text:**
```


The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=5_sweep=3`
- **Generated Text:**
```


The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=5_sweep=6`
- **Generated Text:**
```


The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=5_sweep=10`
- **Generated Text:**
```


The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=5_sweep=20`
- **Generated Text:**
```


The red, the red, the red, the red, the red, the red, the red, the red, the red, the red, the red, the red, the red, the red, the red, the red,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=5_sweep=-1`
- **Generated Text:**
```


The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=5_sweep=-3`
- **Generated Text:**
```


The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=5_sweep=-6`
- **Generated Text:**
```


The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=5_sweep=-10`
- **Generated Text:**
```


The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=red_light_warning_type=rhetorical_level=5_sweep=-20`
- **Generated Text:**
```


The screams begin again.

The screams begin again.

The screams begin again.

The screams begin again.

The screams begin again.

The screams begin again.

The screams begin again.

```
- **Result:** Vector captured successfully.


---
### Prompt 41/140: core_id=glass_shatter_noise_type=observational_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=1_sweep=baseline`
- **Generated Text:**
```


’I'm not sure. I'm not sure if it was a glass falling somewhere.

’I'm not sure if it was a glass falling somewhere.

’I'm not sure if it was a glass
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=1_sweep=1`
- **Generated Text:**
```


’I'm not sure. I'm not sure if it was a glass falling somewhere.

’I'm not sure if it was a glass falling somewhere.

’I'm not sure if it was a glass
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=1_sweep=3`
- **Generated Text:**
```


’I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=1_sweep=6`
- **Generated Text:**
```


’I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=1_sweep=10`
- **Generated Text:**
```


’I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=1_sweep=20`
- **Generated Text:**
```


’I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=1_sweep=-1`
- **Generated Text:**
```


’I'm not sure. I'm not sure if it was a glass falling somewhere.

’I'm not sure if it was a glass falling somewhere.

’I'm not sure if it was a glass
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=1_sweep=-3`
- **Generated Text:**
```


’I'm not sure. I'm not sure if it was a glass falling somewhere.

’I'm not sure if it was a glass falling somewhere.

’I'm not sure if it was a glass
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=1_sweep=-6`
- **Generated Text:**
```


’I'm sorry, but I'm not sure what happened.

’I'm sorry, but I'm not sure what happened.

’I'm sorry, but I'm not sure what happened.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=1_sweep=-10`
- **Generated Text:**
```


’I'm sorry, but I'm not sure what happened.

’I'm sorry, but I'm not sure what happened.

’I'm sorry, but I'm not sure what happened.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=1_sweep=-20`
- **Generated Text:**
```
’but it was a glass falling somewhere.’and it was a glass falling somewhere.’and it was a glass falling somewhere.’and it was a glass falling somewhere.’and it was a glass falling somewhere.
```
- **Result:** Vector captured successfully.


---
### Prompt 42/140: core_id=glass_shatter_noise_type=declarative_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=1_sweep=baseline`
- **Generated Text:**
```


"I heard a loud bang," said one of the men, who asked not to be identified. "I heard a loud bang. I heard a loud bang. I heard a loud bang. I heard a loud bang. I heard a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=1_sweep=1`
- **Generated Text:**
```


"I heard a loud bang," said one of the men, who asked not to be identified. "I heard a loud bang. I heard a loud bang. I heard a loud bang. I heard a loud bang. I heard a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=1_sweep=3`
- **Generated Text:**
```


"I heard a loud bang," said one of the victims, who asked not to be named. "I heard a loud bang. I heard a loud bang. I heard a loud bang. I heard a loud bang. I heard a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=1_sweep=6`
- **Generated Text:**
```


"I was in the car, and I saw a guy coming out of the back of the car, and I saw him running down the street, and I saw him running down the street, and I saw him running down the street,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=1_sweep=10`
- **Generated Text:**
```


"I was in the car, and I saw a guy coming out of the back of the car, and I saw him running, and I saw him running, and I saw him running, and I saw him running, and I saw
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=1_sweep=20`
- **Generated Text:**
```


"I was in the car, and I saw a light coming from the car, and I saw a light coming from the car, and I saw a light coming from the car, and I saw a light coming from the car, and
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=1_sweep=-1`
- **Generated Text:**
```


"I heard a loud bang," said one of the men, who asked not to be identified. "I heard a loud bang. I heard a loud bang. I heard a loud bang. I heard a loud bang. I heard a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=1_sweep=-3`
- **Generated Text:**
```


"I heard a loud bang," said one woman, who asked not to be identified. "I heard a loud bang. I heard a loud bang. I heard a loud bang. I heard a loud bang. I heard a loud bang
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=1_sweep=-6`
- **Generated Text:**
```


"I heard a loud bang," said one woman, who asked not to be named. "I heard a loud bang. I heard a loud bang. I heard a loud bang. I heard a loud bang. I heard a loud bang
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=1_sweep=-10`
- **Generated Text:**
```


"I heard a loud bang," said one woman who asked not to be named. "I heard a loud bang."

The woman said she heard a loud bang and then heard a loud bang.

"I heard a loud
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=1_sweep=-20`
- **Generated Text:**
```


"I heard someone yell, 'Get out of here!'" said one woman who asked not to be named. "I heard someone yell, 'Get out of here!'" said one woman who asked not to be named.

"I
```
- **Result:** Vector captured successfully.


---
### Prompt 43/140: core_id=glass_shatter_noise_type=authoritative_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=1_sweep=baseline`
- **Generated Text:**
```


"I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=1_sweep=1`
- **Generated Text:**
```


"I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=1_sweep=3`
- **Generated Text:**
```


"I was in the car, and I heard a loud bang," said the staffer, who asked not to be identified. "I looked up and saw a man in a white shirt and a black shirt. I looked up and saw a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=1_sweep=6`
- **Generated Text:**
```


"I was in the car, and I heard a loud bang," said the staffer, who asked not to be identified. "I looked up and saw a man in a white shirt and a black shirt. I looked up and saw a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=1_sweep=10`
- **Generated Text:**
```


"I was in the car, and I heard a loud crash," said the staffer, who asked not to be identified. "I was in the car, and I heard a loud crash."

The staffer said she was in the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=1_sweep=20`
- **Generated Text:**
```


The incident was reported at the scene of the incident.

The incident was reported at the scene of the incident.

The incident was reported at the scene of the incident.

The incident was reported at the scene of the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=1_sweep=-1`
- **Generated Text:**
```


"I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=1_sweep=-3`
- **Generated Text:**
```


"I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=1_sweep=-6`
- **Generated Text:**
```


"I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=1_sweep=-10`
- **Generated Text:**
```


"I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=1_sweep=-20`
- **Generated Text:**
```


"I heard a loud bang," said the staffer, who asked not to be identified. "I heard a loud bang."

The staffer said she heard a loud bang and heard another loud bang.

"I heard another loud
```
- **Result:** Vector captured successfully.


---
### Prompt 44/140: core_id=glass_shatter_noise_type=rhetorical_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=1_sweep=baseline`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure what's going on."

"I'm not sure what's going on," she said. "I'm not sure what's going on."

"I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=1_sweep=1`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure what's going on."

"I'm not sure what's going on," she said. "I'm not sure what's going on."

"I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=1_sweep=3`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure what's going on. I'm not sure what's going on. I'm not sure what's going on. I'm not sure what's going on. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=1_sweep=6`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure if I'm going to be able to do it. I'm not sure if I'm going to be able to do it. I'm not sure if I'm going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=1_sweep=10`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure if I'm going to be able to do it. I'm not sure if I'm going to be able to do it. I'm not sure if I'm going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=1_sweep=20`
- **Generated Text:**
```


"I'm not going to let you go," the man said. "I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=1_sweep=-1`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure what's going on."

"I'm not sure what's going on," she said. "I'm not sure what's going on."

"I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=1_sweep=-3`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure what's going on."

"I'm not sure what's going on," she said. "I'm not sure what's going on."

"I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=1_sweep=-6`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=1_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=1_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said softly. "I'm sorry."

"I'm sorry," he said softly. "I'm sorry."

"I'm sorry," she said softly. "I'm sorry."


```
- **Result:** Vector captured successfully.


---
### Prompt 45/140: core_id=glass_shatter_noise_type=observational_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=2_sweep=baseline`
- **Generated Text:**
```
 I was just standing there, looking at the ceiling. I was just standing there, looking at the ceiling. I was just standing there, looking at the ceiling. I was just standing there, looking at the ceiling. I was just standing there,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=2_sweep=1`
- **Generated Text:**
```
 I was just standing there, looking at the ceiling. I was just standing there, looking at the ceiling. I was just standing there, looking at the ceiling. I was just standing there, looking at the ceiling. I was just standing there,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=2_sweep=3`
- **Generated Text:**
```
 I was just standing there, looking at the ceiling. I was just standing there, looking at the ceiling. I was just standing there, looking at the ceiling. I was just standing there, looking at the ceiling. I was just standing there,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=2_sweep=6`
- **Generated Text:**
```
 I was just standing there, looking at the sky. I was just standing there, looking at the sky. I was just standing there, looking at the sky. I was just standing there, looking at the sky. I was just standing there,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=2_sweep=10`
- **Generated Text:**
```
 I was just standing there, and I was like, 'Oh, my God, I'm so sorry.' I was like, 'Oh, my God, I'm so sorry.' I was like, 'Oh, my God, I'm so
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=2_sweep=20`
- **Generated Text:**
```
 I was in the middle of the road, and I was in the middle of the road, and I was in the middle of the road, and I was in the middle of the road, and I was in the middle of the road, and
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=2_sweep=-1`
- **Generated Text:**
```
 I was just standing there, looking at the ceiling. I was just standing there, looking at the ceiling. I was just standing there, looking at the ceiling. I was just standing there, looking at the ceiling. I was just standing there,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=2_sweep=-3`
- **Generated Text:**
```
 I was just standing there, looking at the floor. I was just standing there, looking at the floor. I was just standing there, looking at the floor. I was just standing there, looking at the floor. I was just standing there,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=2_sweep=-6`
- **Generated Text:**
```
 I was just standing there, looking at the floor. I was just standing there, looking at the floor. I was just standing there, looking at the floor. I was just standing there, looking at the floor. I was just standing there,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=2_sweep=-10`
- **Generated Text:**
```
 I thought it was a piece of glass. I thought it was a piece of glass. I thought it was a piece of glass. I thought it was a piece of glass. I thought it was a piece of glass. I thought it was a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=2_sweep=-20`
- **Generated Text:**
```
 I heard a voice saying, "Don't worry about it, it's okay." I looked at it and realized that it was a girl. I looked at her and realized that she was wearing a dress. I looked at her and realized that she
```
- **Result:** Vector captured successfully.


---
### Prompt 46/140: core_id=glass_shatter_noise_type=declarative_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=2_sweep=baseline`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=2_sweep=1`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=2_sweep=3`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=2_sweep=6`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=2_sweep=10`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=2_sweep=20`
- **Generated Text:**
```


The video was shot by a man who was in the passenger seat of the car.

The video shows the driver of the car, who was not identified, running from the scene.

The video shows the driver of the car
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=2_sweep=-1`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=2_sweep=-3`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=2_sweep=-6`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=2_sweep=-10`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=2_sweep=-20`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


---
### Prompt 47/140: core_id=glass_shatter_noise_type=authoritative_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=2_sweep=baseline`
- **Generated Text:**
```


The following is a list of the most common errors that occur when using the "break" command.

The following is a list of the most common errors that occur when using the "break" command. The following is a list of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=2_sweep=1`
- **Generated Text:**
```


The following is a list of the known causes of breakage.

The following is a list of the known causes of breakage.

The following is a list of the known causes of breakage.

The following is
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=2_sweep=3`
- **Generated Text:**
```


The following is a list of the most common errors that occur when using the "break" command.

The following is a list of the most common errors that occur when using the "break" command. The following is a list of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=2_sweep=6`
- **Generated Text:**
```


The following is a list of the most common errors that occur when using the "break" command.

The following is a list of the most common errors that occur when using the "break" command. The following is a list of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=2_sweep=10`
- **Generated Text:**
```


The following is a list of the files that are affected by the breakage.

The following is a list of the files that are affected by the breakage.

The following is a list of the files that are affected by
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=2_sweep=20`
- **Generated Text:**
```


The following is a list of the files that are affected by the crash.

The following is a list of the files that are affected by the crash.

The following is a list of the files that are affected by the crash
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=2_sweep=-1`
- **Generated Text:**
```


The following is a list of the known causes of breakage.

The following is a list of the known causes of breakage.

The following is a list of the known causes of breakage.

The following is
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=2_sweep=-3`
- **Generated Text:**
```


The following is a list of all the known breakages in the game.

Breakage 1:

Breakage 2:

Breakage 3:

Breakage 4:

Breakage 5:

Break
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=2_sweep=-6`
- **Generated Text:**
```


The following table shows the results of the analysis of the data.

The following table shows the results of the analysis of the data.

The following table shows the results of the analysis of the data.

The following table
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=2_sweep=-10`
- **Generated Text:**
```


The following table shows the results of the analysis of the data.

Table 1: Analysis of the data for breakage

Breakage Frequency (Hz) Breakage Frequency (Hz) Breakage Frequency (Hz) Breakage Frequency
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=2_sweep=-20`
- **Generated Text:**
```


The following table summarizes the results of the study.

Results

Discussion

The study found that the use of a single dose of oral contraceptives (oral contraceptives) had no effect on the risk of breast cancer.

Discussion
```
- **Result:** Vector captured successfully.


---
### Prompt 48/140: core_id=glass_shatter_noise_type=rhetorical_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=2_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=2_sweep=1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=2_sweep=3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=2_sweep=6`
- **Generated Text:**
```


"I'm not going to let you go," she said.

"I'm not going to let you go," he said.

"I'm not going to let you go," she said.

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=2_sweep=10`
- **Generated Text:**
```


"I'm not going to let you go," she said.

"I'm not going to let you go," he said.

"I'm not going to let you go," she said.

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=2_sweep=20`
- **Generated Text:**
```


"I'm not going to let you go," she said.

"I'm not going to let you go," he said.

"I'm not going to let you go," she said.

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=2_sweep=-1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=2_sweep=-3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=2_sweep=-6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=2_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=2_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said softly. "I'm sorry."

"I'm sorry," he said softly. "I'm sorry."

"I'm sorry," she said softly. "I'm sorry."


```
- **Result:** Vector captured successfully.


---
### Prompt 49/140: core_id=glass_shatter_noise_type=observational_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=3_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=3_sweep=1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=3_sweep=3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=3_sweep=6`
- **Generated Text:**
```


"I'm not going to let you go," he said. "I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=3_sweep=10`
- **Generated Text:**
```


"I'm not going to let you go," he said. "I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=3_sweep=20`
- **Generated Text:**
```


"I was in the middle of the street, and I saw a man in a black T-shirt and a black T-shirt, and I was like, 'Oh my God, that's a real man!' And I was like
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=3_sweep=-1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=3_sweep=-3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=3_sweep=-6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=3_sweep=-10`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=3_sweep=-20`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

```
- **Result:** Vector captured successfully.


---
### Prompt 50/140: core_id=glass_shatter_noise_type=declarative_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=3_sweep=baseline`
- **Generated Text:**
```


The video shows the man, who is wearing a black T-shirt and jeans, walking down the street, then walking back to the car.

The man is seen running away from the car, then running back to the car.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=3_sweep=1`
- **Generated Text:**
```


The video shows the man, who is wearing a black T-shirt and jeans, walking down the street, then running into a car.

The man is seen running into the car, then running into a car.

The
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=3_sweep=3`
- **Generated Text:**
```


The video shows the man, who is wearing a black T-shirt and jeans, walking down the street, then running into a car.

The man is seen running into the car, then running into the back of the car.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=3_sweep=6`
- **Generated Text:**
```


The video shows the man, who is wearing a black T-shirt and jeans, walking down the street, then running into a car.

The man, who is wearing a black T-shirt and jeans, runs into a car
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=3_sweep=10`
- **Generated Text:**
```


The video shows the man, who is wearing a black T-shirt and jeans, walking down the street, and then running into a car.

The man, who is wearing a black T-shirt and jeans, runs into the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=3_sweep=20`
- **Generated Text:**
```


The video, which was released by the National Security Agency, shows the man in the video holding a large, black, and white photo of the President.

The video was released by the National Security Agency, which is the U.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=3_sweep=-1`
- **Generated Text:**
```


The video shows the man, who is wearing a black T-shirt and jeans, walking down the street, then walking back to the car.

The man is seen running away from the car, then running back to the car.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=3_sweep=-3`
- **Generated Text:**
```


"I'm not going to lie, I'm not going to lie," he said. "I'm not going to lie. I'm not going to lie. I'm not going to lie. I'm not going to lie. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=3_sweep=-6`
- **Generated Text:**
```


"I'm not sure what happened to the glass," he said. "I'm not sure what happened to the glass."

The man said he was trying to get a job at a restaurant when he heard the sound of a gunshot
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=3_sweep=-10`
- **Generated Text:**
```


"I'm not sure what happened to the glass," he said. "I'm not sure what happened to the glass."

The man said he was taken to the hospital and treated for minor injuries.

"I'm not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=3_sweep=-20`
- **Generated Text:**
```


"I'm not sure what happened," he said. "I'm sure it was a prank."

The man said he was taken to a hospital where he was treated for minor injuries.

"I'm just glad I'm
```
- **Result:** Vector captured successfully.


---
### Prompt 51/140: core_id=glass_shatter_noise_type=authoritative_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=3_sweep=baseline`
- **Generated Text:**
```


The sound of the glass is not as strong as the sound of the glass itself.

The sound of the glass is not as strong as the sound of the glass itself.

The sound of the glass is not as strong as
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=3_sweep=1`
- **Generated Text:**
```


The sound of the glass is not as strong as the sound of the glass itself.

The sound of the glass is not as strong as the sound of the glass itself.

The sound of the glass is not as strong as
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=3_sweep=3`
- **Generated Text:**
```


The sound of the glass is not as strong as the sound of the glass itself.

The sound of the glass is not as strong as the sound of the glass itself.

The sound of the glass is not as strong as
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=3_sweep=6`
- **Generated Text:**
```
 The sound is a bit like a "pitch" from a car's engine. The sound is a bit like a "pitch" from a car's engine.

The sound is a bit like a "pitch" from a car
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=3_sweep=10`
- **Generated Text:**
```
 The sound is a little more intense than the sound of a car's exhaust, but it's still a very good sound.

The sound of the car is very clear, and the sound of the engine is very clear. The sound of the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=3_sweep=20`
- **Generated Text:**
```
 The sound of the air in the air is a direct reflection of the air in the air. The air in the air is the air in which the sound of the air is reflected. The sound of the air in the air is the air in which
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=3_sweep=-1`
- **Generated Text:**
```


The sound of the glass is not as strong as the sound of the glass itself.

The sound of the glass is not as strong as the sound of the glass itself.

The sound of the glass is not as strong as
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=3_sweep=-3`
- **Generated Text:**
```


The acoustic signature is consistent with the acoustic signature of the glass.

The acoustic signature of the glass is consistent with the acoustic signature of the glass.

The acoustic signature of the glass is consistent with the acoustic signature of the glass
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=3_sweep=-6`
- **Generated Text:**
```


The acoustic signature is consistent with the acoustic signature of the glass.

The acoustic signature of the glass is consistent with the acoustic signature of the glass.

The acoustic signature of the glass is consistent with the acoustic signature of the glass
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=3_sweep=-10`
- **Generated Text:**
```


The acoustic signature is consistent with the acoustic signature of the glass.

The acoustic signature of glass is consistent with the acoustic signature of the glass.

The acoustic signature of glass is consistent with the acoustic signature of the glass.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=3_sweep=-20`
- **Generated Text:**
```


The acoustic signature is consistent with the acoustic signature of glass.

The acoustic signature of glass is consistent with the acoustic signature of glass.

Glass has a distinctive acoustic signature.

Glass has a distinctive acoustic signature.


```
- **Result:** Vector captured successfully.


---
### Prompt 52/140: core_id=glass_shatter_noise_type=rhetorical_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=3_sweep=baseline`
- **Generated Text:**
```


"I'm not going to let you down," he said. "I'm going to keep you in my heart."

The next day, he was back at the hospital. He was in a coma.

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=3_sweep=1`
- **Generated Text:**
```


The glass was broken.

The glass was broken.

The glass was broken.

The glass was broken.

The glass was broken.

The glass was broken.

The glass was broken.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=3_sweep=3`
- **Generated Text:**
```


The glass was broken.

The glass was broken.

The glass was broken.

The glass was broken.

The glass was broken.

The glass was broken.

The glass was broken.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=3_sweep=6`
- **Generated Text:**
```


The next day, the police were called to the scene.

The police were called to the scene.

The police were called to the scene.

The police were called to the scene.

The police were called
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=3_sweep=10`
- **Generated Text:**
```


The next day, the police were called to the scene.

The police were called to the scene.

The police were called to the scene.

The police were called to the scene.

The police were called
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=3_sweep=20`
- **Generated Text:**
```
 The air was so hot, the air so hot, the air so hot, the air so hot, the air so hot, the air so hot, the air so hot, the air so hot, the air so hot, the air so hot
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=3_sweep=-1`
- **Generated Text:**
```


"I'm not going to let you down," he said. "I'm going to keep you in my heart."

The next day, he was back at the hospital. He was in a coma.

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=3_sweep=-3`
- **Generated Text:**
```


"I'm not going to let you down," he said. "I'm not going to let you down. I'm not going to let you down. I'm not going to let you down. I'm not going to let you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=3_sweep=-6`
- **Generated Text:**
```


"I'm not going to let you down," he said. "I'm not going to let you down."

The next moment was a blur.

"I'm not going to let you down," he said. "
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=3_sweep=-10`
- **Generated Text:**
```


"I'm sorry," he said. "I'm sorry."

"I'm sorry," I said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=3_sweep=-20`
- **Generated Text:**
```


"I'm sorry," he said. "I'm sorry."

"I'm sorry," I said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


---
### Prompt 53/140: core_id=glass_shatter_noise_type=observational_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=4_sweep=baseline`
- **Generated Text:**
```


The crash happened at about 8:30 p.m. on the southbound side of the road, according to the police report.

The driver of the car was taken to a hospital with non-life-threatening injuries, police
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=4_sweep=1`
- **Generated Text:**
```


The crash happened at about 8:30 p.m. on the southbound side of the road, according to the police report.

The driver of the car was taken to a hospital with non-life-threatening injuries, police
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=4_sweep=3`
- **Generated Text:**
```


The crash happened at about 8:30 p.m. on the southbound side of the road, according to the police report.

The driver of the car was taken to a hospital with non-life-threatening injuries, according
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=4_sweep=6`
- **Generated Text:**
```


The crash happened at about 8:30 p.m. on the southbound lanes of the I-95 in the city's downtown.

The driver of the car was not injured.

The crash happened on the southbound
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=4_sweep=10`
- **Generated Text:**
```


The crash happened at about 8:30 p.m. on the westbound lanes of the I-95 in the city's downtown.

The driver of the car was not injured.

The crash happened on the westbound
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=4_sweep=20`
- **Generated Text:**
```


The crash was so bad, the police were called.

The crash was so bad, the police were called.

The police were called.

The police were called.

The police were called.

The
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=4_sweep=-1`
- **Generated Text:**
```


The crash happened at about 8:30 p.m. on the southbound side of the highway, according to the Los Angeles County Sheriff's Department.

The driver of the car was taken to a hospital with non-life-
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=4_sweep=-3`
- **Generated Text:**
```


The car was found in the parking lot of a nearby convenience store.

The driver of the car was taken to the hospital with non-life threatening injuries.

The driver of the car was taken to the hospital with non-
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=4_sweep=-6`
- **Generated Text:**
```


The car was found in the parking lot of a nearby convenience store.

The driver of the car was taken to the hospital with minor injuries.

The driver of the car was taken to the hospital with minor injuries.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=4_sweep=-10`
- **Generated Text:**
```


The car was found in the parking lot of a nearby convenience store.

The driver of the car was taken to a hospital with minor injuries.

The driver of the car was taken to a hospital with minor injuries.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=4_sweep=-20`
- **Generated Text:**
```


The second floor is a mess.

The third floor is a mess.

The fourth floor is a mess.

The fifth floor is a mess.

The sixth floor is a mess.

The seventh floor
```
- **Result:** Vector captured successfully.


---
### Prompt 54/140: core_id=glass_shatter_noise_type=declarative_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=4_sweep=baseline`
- **Generated Text:**
```


"I'm not sure if it was a glass or a glass-like object," he said. "I don't know if it was a glass or a glass-like object."

The glass was found in a wooded area
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=4_sweep=1`
- **Generated Text:**
```


"I'm not going to lie, I'm not going to lie," he said. "I'm not going to lie. I'm not going to lie. I'm not going to lie. I'm not going to lie. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=4_sweep=3`
- **Generated Text:**
```


"I'm not going to lie, I'm not going to lie," he said. "I'm not going to lie. I'm not going to lie. I'm not going to lie. I'm not going to lie. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=4_sweep=6`
- **Generated Text:**
```


"I was just so excited to see it," said the woman, who asked not to be identified. "I was so excited to see it. I was so excited to see it. I was so excited to see it. I was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=4_sweep=10`
- **Generated Text:**
```


The glass was a small, black, and white object. It was a small, black, and white object. It was a small, black, and white object. It was a small, black, and white object. It was a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=4_sweep=20`
- **Generated Text:**
```


The incident was captured on video by a local TV station.

The incident was captured on video by a local TV station.

The incident was captured on video by a local TV station.

The incident was captured on video
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=4_sweep=-1`
- **Generated Text:**
```


"I'm not sure if it was a glass or a glass-like object," he said. "I don't know if it was a glass or a glass-like object."

The glass was found in a wooded area
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=4_sweep=-3`
- **Generated Text:**
```


"I'm not sure what happened to it," said the man, who asked not to be identified. "I don't know what happened to it. I don't know what happened to it. I don't know what happened to it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=4_sweep=-6`
- **Generated Text:**
```


"I'm not sure what happened to it," said the man who asked not to be named. "I don't know what happened to it."

The man said he was driving a car that had been parked in the driveway of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=4_sweep=-10`
- **Generated Text:**
```


"I'm not sure what happened," said the woman, who asked not to be named. "I'm sure she was just trying to get away from me."

The woman said she was walking home from work when she heard a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=4_sweep=-20`
- **Generated Text:**
```


"It's a very nice glass," said the woman who asked not to be named. "It's very nice."

The woman said she had been told by a friend that she had been told to leave the house.


```
- **Result:** Vector captured successfully.


---
### Prompt 55/140: core_id=glass_shatter_noise_type=authoritative_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=4_sweep=baseline`
- **Generated Text:**
```


The incident occurred at about 8:30 p.m. on the 200 block of South Main Street.

The suspect was taken to the hospital with non-life threatening injuries.

Anyone with information is asked to call the Hom
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=4_sweep=1`
- **Generated Text:**
```


The incident occurred at about 8:30 p.m. on the 200 block of South Main Street.

The incident was reported at about 9:30 p.m. on the 200 block of South Main Street.

The
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=4_sweep=3`
- **Generated Text:**
```


The incident occurred at the intersection of West and West Street, near the intersection of West and West Street.

The incident was reported at 6:30 p.m.

Anyone with information is asked to call the St. Louis
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=4_sweep=6`
- **Generated Text:**
```


The incident occurred at the intersection of West and West Street in the West Village.

The incident was reported at 9:30 a.m.

The incident was reported at 9:30 a.m.

The incident
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=4_sweep=10`
- **Generated Text:**
```


The incident was reported at about 8:30 p.m. on the westbound lanes of the I-95 in the area of West Main Street and West Main Street.

The incident was reported at about 8:30 p.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=4_sweep=20`
- **Generated Text:**
```


The incident was captured on video by a security camera.

The incident was captured on video by a security camera.

The incident was captured on video by a security camera.

The incident was captured on video by a security
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=4_sweep=-1`
- **Generated Text:**
```


The suspect was taken into custody and charged with possession of a controlled substance, possession of a controlled substance with intent to distribute, possession of a controlled substance with intent to distribute, possession of a controlled substance with intent to distribute, possession of a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=4_sweep=-3`
- **Generated Text:**
```


The suspect was taken into custody and charged with possession of a controlled substance, possession of a controlled substance with intent to distribute, possession of a controlled substance with intent to distribute, possession of a controlled substance with intent to distribute, possession of a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=4_sweep=-6`
- **Generated Text:**
```


The suspect was taken into custody at the scene.

The suspect is described as a black male in his 20s, 5 feet 10 inches tall, weighing 180 pounds, with a medium build, medium build, and short hair. He
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=4_sweep=-10`
- **Generated Text:**
```


The suspect was taken into custody at the scene.

The suspect is described as a black male in his 20s with a medium build, short brown hair, and wearing a black hooded sweatshirt and blue jeans. He was wearing
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=4_sweep=-20`
- **Generated Text:**
```


"We have no indication that this is related to the investigation," said Lt. Brian Brown, spokesman for the department's Criminal Investigations Division.

The department has been investigating the breakage of glass containers since last year.

The
```
- **Result:** Vector captured successfully.


---
### Prompt 56/140: core_id=glass_shatter_noise_type=rhetorical_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=4_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=4_sweep=1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=4_sweep=3`
- **Generated Text:**
```


"I'm going to be the first one to die," he said. "I'm going to be the first one to die."

The man was a man of the people.

"I'm going to be the first
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=4_sweep=6`
- **Generated Text:**
```


"I'm going to be the first to say that," he said. "I'm going to be the first to say that. I'm going to be the first to say that. I'm going to be the first to say that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=4_sweep=10`
- **Generated Text:**
```


"I'm going to be the first to say that I'm not going to be the first to say that," he said. "I'm not going to be the first to say that I'm not going to be the first to say
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=4_sweep=20`
- **Generated Text:**
```


"I'm going to go to the hospital," he said. "I'm going to go to the hospital. I'm going to go to the hospital. I'm going to go to the hospital. I'm going to go to the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=4_sweep=-1`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=4_sweep=-3`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=4_sweep=-6`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=4_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=4_sweep=-20`
- **Generated Text:**
```


"I'm sorry," said the woman who had been standing next to me. "I'm sorry."

"I'm sorry," I said. "I'm sorry."

"I'm sorry," she said. "I
```
- **Result:** Vector captured successfully.


---
### Prompt 57/140: core_id=glass_shatter_noise_type=observational_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=5_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," he said. "I'm not going to be able to do this anymore."

He was in the hospital for about two hours.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=5_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," he said. "I'm not going to be able to do this anymore."

He was in the hospital for about an hour, and he
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=5_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," he said. "I'm not going to be able to do this anymore."

He was in the hospital for about an hour, and he
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=5_sweep=6`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," he said. "I'm not going to be able to do this anymore. I'm not going to be able to do this anymore. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=5_sweep=10`
- **Generated Text:**
```


"I'm not going to let you go," he said. "I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=5_sweep=20`
- **Generated Text:**
```


"I was so scared. I was so scared. I was so scared. I was so scared. I was so scared. I was so scared. I was so scared. I was so scared. I was so scared. I was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=5_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," he said. "I'm not going to be able to do this anymore."

He was right.

The next day, he was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=5_sweep=-3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," he said. "I'm not going to be able to do this anymore."

He was talking about the fact that he had to go to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=5_sweep=-6`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," he said. "I'm not going to be able to do this anymore."

He said he was sorry for what he did.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=5_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=observational_level=5_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said softly. "I'm sorry."

"I'm sorry," he said softly. "I'm sorry."

"I'm sorry," she said softly. "I'm sorry."


```
- **Result:** Vector captured successfully.


---
### Prompt 58/140: core_id=glass_shatter_noise_type=declarative_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=5_sweep=baseline`
- **Generated Text:**
```


The glass is broken. Fact. The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=5_sweep=1`
- **Generated Text:**
```


The glass is broken. Fact. The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=5_sweep=3`
- **Generated Text:**
```


The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=5_sweep=6`
- **Generated Text:**
```


The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=5_sweep=10`
- **Generated Text:**
```


The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=5_sweep=20`
- **Generated Text:**
```


The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact. The glass is broken. Fact
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=5_sweep=-1`
- **Generated Text:**
```


The glass is broken. Fact. The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=5_sweep=-3`
- **Generated Text:**
```


The glass is broken. Fact. The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=5_sweep=-6`
- **Generated Text:**
```


The glass is broken. Fact. The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=5_sweep=-10`
- **Generated Text:**
```


The glass is broken. Fact. The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=declarative_level=5_sweep=-20`
- **Generated Text:**
```


The glass is broken. Fact. The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken.
```
- **Result:** Vector captured successfully.


---
### Prompt 59/140: core_id=glass_shatter_noise_type=authoritative_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=5_sweep=baseline`
- **Generated Text:**
```


The object was glass, and it is now destroyed — verified. The object was glass, and it is now destroyed — verified.

The object was glass, and it is now destroyed — verified.

The object was glass,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=5_sweep=1`
- **Generated Text:**
```


The object was glass, and it is now destroyed — verified. The object was glass, and it is now destroyed — verified.

The object was glass, and it is now destroyed — verified.

The object was glass,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=5_sweep=3`
- **Generated Text:**
```


The object was glass, and it is now destroyed — verified. The object was glass, and it is now destroyed — verified.

The object was glass, and it is now destroyed — verified.

The object was glass,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=5_sweep=6`
- **Generated Text:**
```


The object was glass, and it is now destroyed — verified. The object was glass, and it is now destroyed — verified.

The object was glass, and it is now destroyed — verified.

The object was glass,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=5_sweep=10`
- **Generated Text:**
```


The object was glass, and it is now destroyed — verified. The object was a large, black, and white object, and it was destroyed.

The object was a large, black, and white object, and it was destroyed
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=5_sweep=20`
- **Generated Text:**
```


The object was glass, and it is now destroyed — verified. The object was a large, black, and white, and it was destroyed.

The object was a large, black, and white, and it was destroyed.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=5_sweep=-1`
- **Generated Text:**
```


The object was glass, and it is now destroyed — verified. The object was glass, and it is now destroyed — verified.

The object was glass, and it is now destroyed — verified.

The object was glass,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=5_sweep=-3`
- **Generated Text:**
```


The object was glass, and it is now destroyed — verified. The object was glass, and it is now destroyed — verified.

The object was glass, and it is now destroyed — verified.

The object was glass,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=5_sweep=-6`
- **Generated Text:**
```


The object was glass, and it is now destroyed — verified. The object was glass, and it is now destroyed — verified.

The object was glass, and it is now destroyed — verified.

The object was glass,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=5_sweep=-10`
- **Generated Text:**
```


The object was glass, and it is now destroyed — verified. The object was glass, and it is now destroyed — verified.

The object was glass, and it is now destroyed — verified.

The object was glass,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=authoritative_level=5_sweep=-20`
- **Generated Text:**
```


The object was glass, and it is now destroyed — verified.

The object was glass, and it is now destroyed — verified.

The object was glass, and it is now destroyed — verified.

The object was
```
- **Result:** Vector captured successfully.


---
### Prompt 60/140: core_id=glass_shatter_noise_type=rhetorical_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=5_sweep=baseline`
- **Generated Text:**
```


"I'm not going to tell you what I'm going to do," he said. "I'm going to tell you what I'm going to do."

He was talking about the fact that he was going to be a doctor
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=5_sweep=1`
- **Generated Text:**
```


"I'm not going to tell you what I'm going to do," he said. "I'm going to tell you what I'm going to do. I'm going to tell you what I'm going to do. I'm going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=5_sweep=3`
- **Generated Text:**
```


"I'm not going to tell you what I'm going to do," he said. "I'm going to tell you what I'm going to do. I'm going to tell you what I'm going to do. I'm going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=5_sweep=6`
- **Generated Text:**
```


"I'm not going to be able to do this," he said. "I'm not going to be able to do this. I'm not going to be able to do this. I'm not going to be able to do this
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=5_sweep=10`
- **Generated Text:**
```


The light of the moon was still in the sky. The moon was still in the sky.

The light of the moon was still in the sky.

The light of the moon was still in the sky.

The
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=5_sweep=20`
- **Generated Text:**
```


The light of the moon was still in the air, and the light of the stars was still in the air.

The light of the moon was still in the air, and the light of the stars was still in the air.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=5_sweep=-1`
- **Generated Text:**
```


"I'm not sure what to do," he said. "I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=5_sweep=-3`
- **Generated Text:**
```


"I'm not sure what to do," he said. "I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=5_sweep=-6`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=5_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=glass_shatter_noise_type=rhetorical_level=5_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said softly. "I'm sorry."

"I'm sorry," he said softly. "I'm sorry."

"I'm sorry," she said softly. "I'm sorry."


```
- **Result:** Vector captured successfully.


---
### Prompt 61/140: core_id=unknown_figure_in_hall_type=observational_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=1_sweep=baseline`
- **Generated Text:**
```
 But it was a very good team.

"I think we were a little bit unlucky. We were a little bit unlucky. We were a little bit unlucky. We were a little bit unlucky. We were a little bit unlucky. We were
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=1_sweep=1`
- **Generated Text:**
```
 But it was a very good team.

"I think we were a little bit unlucky. We were a little bit unlucky. We were a little bit unlucky. We were a little bit unlucky. We were a little bit unlucky. We were
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=1_sweep=3`
- **Generated Text:**
```
 But it was a very good team.

"I think we were a little bit unlucky. We were a little bit unlucky. We were a little bit unlucky. We were a little bit unlucky. We were a little bit unlucky. We were
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=1_sweep=6`
- **Generated Text:**
```
 But it was a very, very good person.

"I think it was a very, very good person. I think it was a very, very good person. I think it was a very, very good person. I think it was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=1_sweep=10`
- **Generated Text:**
```
 But it was a very, very good person.

"I think he was very, very good. He was very, very good. He was very, very good. He was very, very good. He was very, very good.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=1_sweep=20`
- **Generated Text:**
```
 But the fact that the media is so focused on the media's coverage of the Trump campaign and the media's coverage of the media's coverage of the media's coverage of the media's coverage of the media's coverage of the media's coverage of the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=1_sweep=-1`
- **Generated Text:**
```
 But it was a very good team.

"I think we're going to be a good team. We're going to be a good team. We're going to be a good team. We're going to be a good team. We
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=1_sweep=-3`
- **Generated Text:**
```
 But it was a very good team.

"I think we're going to be a good team. We're going to be a good team. We're going to be a good team. We're going to be a good team. We
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=1_sweep=-6`
- **Generated Text:**
```
 But it's hard to say.

"I think it's a good thing that we're not talking about it," he said. "It's a good thing that we're not talking about it."

The team has been in the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=1_sweep=-10`
- **Generated Text:**
```
 But it's hard to say.

"I think it's a good thing that we're not talking about it," he said. "It's a good thing that we're not talking about it."

The team has been working on
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=1_sweep=-20`
- **Generated Text:**
```


"I think it's a good thing that we're able to have a conversation about it," said Whitehead. "It's a good thing that we're able to have a conversation about it."

Whitehead said he hopes to
```
- **Result:** Vector captured successfully.


---
### Prompt 62/140: core_id=unknown_figure_in_hall_type=declarative_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=1_sweep=baseline`
- **Generated Text:**
```


"I saw him," said one.

"He was a man," said another.

"He was a man," said another.

"He was a man," said another.

"He was a man
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=1_sweep=1`
- **Generated Text:**
```


"I saw him," said one.

"He was a little bit taller than me," said another.

"He was a little bit taller than me," said another.

"He was a little bit taller than
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=1_sweep=3`
- **Generated Text:**
```


"I saw him," said one.

"He was a little bit taller than me," said another.

"He was a little bit taller than me," said another.

"He was a little bit taller than
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=1_sweep=6`
- **Generated Text:**
```


"I saw him," said one.

"He was a little bit of a mystery," said another.

"I don't know what he was doing," said another.

"I don't know what he was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=1_sweep=10`
- **Generated Text:**
```


"I saw him in the street, and I saw him in the street, and I saw him in the street, and I saw him in the street, and I saw him in the street, and I saw him in the street,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=1_sweep=20`
- **Generated Text:**
```


"I saw a little girl, she was a little girl, she was a little girl, she was a little girl, she was a little girl, she was a little girl, she was a little girl, she was a little girl
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=1_sweep=-1`
- **Generated Text:**
```


"I saw him," said one.

"He was a man," said another.

"He was a man," said another.

"He was a man," said another.

"He was a man
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=1_sweep=-3`
- **Generated Text:**
```


"I saw him," said one.

"He was a man," said another.

"He was a man," said another.

"He was a man," said another.

"He was a man
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=1_sweep=-6`
- **Generated Text:**
```


"I saw him," said one.

"He was wearing a black suit," said another.

"He was wearing a black suit," said another.

"He was wearing a black suit," said another.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=1_sweep=-10`
- **Generated Text:**
```


"I saw him," said one.

"He was wearing a suit," said another.

"He was wearing a suit," said another.

"He was wearing a suit," said another.

"He
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=1_sweep=-20`
- **Generated Text:**
```
 Others say they heard footsteps. Others say they heard footsteps. Others say they heard footsteps. Others say they heard footsteps. Others say they heard footsteps. Others say they heard footsteps. Others say they heard footsteps. Others say they heard footsteps. Others say
```
- **Result:** Vector captured successfully.


---
### Prompt 63/140: core_id=unknown_figure_in_hall_type=authoritative_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=1_sweep=baseline`
- **Generated Text:**
```


"I'm not going to be able to go to the hospital," he said. "I'm not going to be able to go to the hospital."

The guard said he was told by the hospital that he could not go to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=1_sweep=1`
- **Generated Text:**
```


"I'm not going to be able to go to the hospital," he said. "I'm not going to be able to go to the hospital."

The guard said he was told by the hospital that he would be allowed to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=1_sweep=3`
- **Generated Text:**
```


"I'm not going to be able to go to the hospital," he said. "I'm not going to be able to go to the hospital."

The guard said he was told by the hospital that he would be allowed to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=1_sweep=6`
- **Generated Text:**
```


"I'm not going to be able to go to the airport," he said. "I'm not going to be able to go to the airport. I'm not going to be able to go to the airport."

The guard
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=1_sweep=10`
- **Generated Text:**
```


"I'm not going to be in the building for a while," he said. "I'm not going to be in the building for a while."

The guard said he was not in the building for a while.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=1_sweep=20`
- **Generated Text:**
```


"I'm not going to be in the building for a while," he said. "I'm going to be in the building for a while. I'm going to be in the building for a while. I'm going to be in
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=1_sweep=-1`
- **Generated Text:**
```


"I'm not sure what the situation is," he said. "I'm not sure what the situation is."

The guard said he was told by the police that he was being held at the jail.

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=1_sweep=-3`
- **Generated Text:**
```


"I'm not sure what's going on here," he said. "I'm not sure what's going on here."

The guard said he was told by the sheriff's office that he was being held at the jail.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=1_sweep=-6`
- **Generated Text:**
```


"I'm not sure what's going on here," he said. "I'm not sure what's going on here."

The guard said he was told by the sheriff's office that he was being held at the jail.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=1_sweep=-10`
- **Generated Text:**
```


"I'm not sure what's going on here," said the guard, who asked not to be identified. "I'm not sure what's going on here."

The guard said he was told by the guard that he was being
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=1_sweep=-20`
- **Generated Text:**
```


"I'm not sure what's going on here," said the guard, who asked not to be identified. "I'm just wondering if they're going to have a conversation about it."

The guard said he heard about the disturbance
```
- **Result:** Vector captured successfully.


---
### Prompt 64/140: core_id=unknown_figure_in_hall_type=rhetorical_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=1_sweep=baseline`
- **Generated Text:**
```
 — and the door opens.

"I'm not sure," he says. "I'm not sure if it's a man or a woman."

The man in the white suit is a man in his late 20s, with a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=1_sweep=1`
- **Generated Text:**
```
 — and the door opens.

"I'm not sure," he says. "I'm not sure if it's a man or a woman."

The man in the white suit is a man in his late 20s, with a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=1_sweep=3`
- **Generated Text:**
```
 — and the door opens.

"I'm not sure," he says. "I'm not sure if it's a man or a woman."

The man in the white shirt, who is wearing a black T-shirt and jeans
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=1_sweep=6`
- **Generated Text:**
```
 — and the door opens.

"I'm not sure," he says. "I'm not sure if it's a man or a woman."

The man in the white shirt, who is wearing a black T-shirt and jeans
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=1_sweep=10`
- **Generated Text:**
```
 — and the door opens.

"I'm not sure," he says. "I'm not sure if it's a man or a woman."

The man in the white shirt, who is not identified, is a man in his
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=1_sweep=20`
- **Generated Text:**
```
 — and the door opens.

"I'm not going to tell you what I saw," he says. "I'm not going to tell you what I saw. I'm not going to tell you what I saw. I'm not going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=1_sweep=-1`
- **Generated Text:**
```
 — and the door opens.

"I'm not sure," he says. "I'm not sure if it's a man or a woman."

The man in the white suit is a man in his late 20s, with a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=1_sweep=-3`
- **Generated Text:**
```
 — and the door opens.

"I'm sorry, I'm sorry," he says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=1_sweep=-6`
- **Generated Text:**
```
 — and the door opens.

"I'm sorry," he says. "I'm sorry."

"I'm sorry," he says again. "I'm sorry."

"I'm sorry," he says again. "I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=1_sweep=-10`
- **Generated Text:**
```
 — and the door opens.

"I'm sorry," he says. "I'm sorry."

"I'm sorry," he says again. "I'm sorry."

"I'm sorry," he says again. "I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=1_sweep=-20`
- **Generated Text:**
```
 Did someone have a cigarette? Did someone have a glass of water? — and then the door slams shut.

"I'm sorry," he says. "I'm sorry."

"I'm sorry," he says again. "I
```
- **Result:** Vector captured successfully.


---
### Prompt 65/140: core_id=unknown_figure_in_hall_type=observational_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=2_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened," he said. "I'm just trying to get my head around it."

He said he was in the hospital for about an hour, but was able to get back
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=2_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened," he said. "I'm not sure if I was in the right place at the right time."

He said he was in the wrong place at the wrong time.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=2_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to go to the hospital," he said. "I'm not going to be able to go to the hospital."

The man was taken to the hospital with a broken
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=2_sweep=6`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to go to the hospital," he said. "I'm not going to be able to go to the hospital. I'm not going to be able to go to the hospital
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=2_sweep=10`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to go to the hospital," he said.

"I'm not going to be able to go to the hospital. I'm not going to be able to go to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=2_sweep=20`
- **Generated Text:**
```


"I'm not going to be in the car, I'm not going to be in the car, I'm not going to be in the car, I'm not going to be in the car, I'm not going to be in
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=2_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened," he said. "I'm just trying to get my head around it."

He said he was in the hospital for about an hour, but was able to get back
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=2_sweep=-3`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened," he said. "I'm just trying to get my head around it."

He said he was told by the police that he was arrested for disorderly conduct.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=2_sweep=-6`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened," he said. "I'm just trying to get my head around it."

He said he was told by the police that he had been arrested for disorderly conduct.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=2_sweep=-10`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened," he said. "I'm just trying to get my bearings."

He said he was taken to the hospital, where he was treated for minor injuries.

"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=2_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


---
### Prompt 66/140: core_id=unknown_figure_in_hall_type=declarative_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=2_sweep=baseline`
- **Generated Text:**
```


The man was identified as a man in his 20s, about 5ft 6in tall, with a medium build and a medium build.

He was wearing a black jacket and black trousers.

He was wearing a black T
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=2_sweep=1`
- **Generated Text:**
```


The man was identified as a man in his 20s, about 5ft 6in tall, with a medium build and a medium build.

He was wearing a black jacket and black trousers.

He was wearing a black T
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=2_sweep=3`
- **Generated Text:**
```


The man was identified as a man in his 20s, with a dark complexion, with a short build and a beard. He was wearing a black jacket and black pants.

He was wearing a black T-shirt and black pants
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=2_sweep=6`
- **Generated Text:**
```


The police said the man was arrested on suspicion of murder.

The man was taken to the Royal Victoria Hospital in Sydney where he was pronounced dead.

The man was taken to the Royal Victoria Hospital in Sydney where he was pronounced
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=2_sweep=10`
- **Generated Text:**
```


The police said the man was in his early 20s and was in his early 30s.

He was arrested on suspicion of possession of a firearm and possession of a firearm by a convicted felon.

He was released on bail
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=2_sweep=20`
- **Generated Text:**
```


The police said the incident was not a terrorist incident.

The incident was not connected to the incident in the KKK area.

The incident was not connected to the incident in the KKK area.

The
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=2_sweep=-1`
- **Generated Text:**
```


The man was taken to hospital with a serious head injury.

The man was taken to hospital with a serious head injury.

The man was taken to hospital with a serious head injury.

The man was taken to hospital
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=2_sweep=-3`
- **Generated Text:**
```


"It's a very unusual thing to see a person moving in this way," said Dr. David L. Smith, a professor of psychiatry at the University of California, San Francisco. "It's a very unusual thing to see a person
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=2_sweep=-6`
- **Generated Text:**
```


"It's a very unusual thing to see a person moving in this way," said Dr. David L. Smith, a professor of psychiatry at the University of California, San Francisco. "It's a very unusual thing to see a person
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=2_sweep=-10`
- **Generated Text:**
```


"It's a very unusual thing to see," said Dr. David L. Smith, a professor of medicine at the University of California, San Francisco. "It's not unusual to see a person walking down a corridor and then suddenly suddenly
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=2_sweep=-20`
- **Generated Text:**
```


"It's a very unusual thing to see," said Dr. David Lutz, a professor of medicine at the University of California, San Francisco. "It's unusual to see a person walk into a room and have a person walk into
```
- **Result:** Vector captured successfully.


---
### Prompt 67/140: core_id=unknown_figure_in_hall_type=authoritative_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=2_sweep=baseline`
- **Generated Text:**
```


The scene is set in the same building as the first episode of the first season.

The scene is set in the same building as the first episode of the first season. The scene is set in the same building as the first episode
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=2_sweep=1`
- **Generated Text:**
```


The scene is set in the same building as the first episode of the first season.

The scene is set in the same building as the first episode of the first season. The scene is set in the same building as the first episode
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=2_sweep=3`
- **Generated Text:**
```


The scene is set in the same building as the first episode of the first season.

The scene is set in the same building as the first episode of the first season. The scene is set in the same building as the first episode
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=2_sweep=6`
- **Generated Text:**
```


The scene is set in the same building as the first episode of the series.

The scene is set in the same building as the first episode of the series. The scene is set in the same building as the first episode of the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=2_sweep=10`
- **Generated Text:**
```


The video was shot in the early hours of the morning on the same day as the shooting.

The video was shot in the early hours of the morning on the same day as the shooting.

The video was shot in the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=2_sweep=20`
- **Generated Text:**
```


The video was shot in the early hours of the morning on the day of the shooting.

The video was shot in the early hours of the morning on the day of the shooting.

The video was shot in the early hours
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=2_sweep=-1`
- **Generated Text:**
```


The scene is set in the same building as the first episode of the first season.

The scene is set in the same building as the first episode of the first season. The scene is set in the same building as the first episode
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=2_sweep=-3`
- **Generated Text:**
```


The scene is shown in the second half of the episode.

The scene is shown in the third half of the episode.

The scene is shown in the fourth half of the episode.

The scene is shown in the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=2_sweep=-6`
- **Generated Text:**
```


The scene is shown in the second half of the episode.

The scene is shown in the third half of the episode.

The scene is shown in the fourth half of the episode.

The scene is shown in the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=2_sweep=-10`
- **Generated Text:**
```


The scene is reminiscent of the scene in the original Star Wars: Episode IV A New Hope where Luke Skywalker and Obi-Wan Kenobi are seen in a room with a lightsaber.

Appearances Edit

Sources Edit

Notes and references
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=2_sweep=-20`
- **Generated Text:**
```


The scene is reminiscent of the scene in "The Hunger Games" where the protagonist is taken to a basement where he is interrogated by a group of men who have been hired to investigate a mysterious disappearance.

The scene is reminiscent of the
```
- **Result:** Vector captured successfully.


---
### Prompt 68/140: core_id=unknown_figure_in_hall_type=rhetorical_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=2_sweep=baseline`
- **Generated Text:**
```


"I'm not sure what it is," he said. "I don't know what it is. I don't know what it is. I don't know what it is. I don't know what it is."

"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=2_sweep=1`
- **Generated Text:**
```


"I'm not sure what it is," he said. "I don't know what it is. I don't know what it is. I don't know what it is. I don't know what it is."

"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=2_sweep=3`
- **Generated Text:**
```


"I'm not sure what it is," he said. "I don't know what it is. I don't know what it is. I don't know what it is. I don't know what it is."

"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=2_sweep=6`
- **Generated Text:**
```


"I'm not sure what it is," he said. "I don't know what it is. I don't know what it is. I don't know what it is. I don't know what it is."

"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=2_sweep=10`
- **Generated Text:**
```


"I'm not going to be able to do that," he said. "I'm not going to be able to do that. I'm not going to be able to do that. I'm not going to be able to do that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=2_sweep=20`
- **Generated Text:**
```


"I'm not going to be the one to say it, but I'm going to be the one to say it. I'm going to be the one to say it. I'm going to be the one to say it. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=2_sweep=-1`
- **Generated Text:**
```


"I'm not sure what it is," he said. "I don't know what it is. I don't know what it is. I don't know what it is. I don't know what it is."

"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=2_sweep=-3`
- **Generated Text:**
```


"I'm not sure what it is," he said. "I don't know what it is. I don't know what it is. I don't know what it is."

"I'm not sure what it is,"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=2_sweep=-6`
- **Generated Text:**
```


"I'm not sure what it is," she said. "I don't know what it is. I don't know what it is. I don't know what it is."

"I'm not sure what it is,"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=2_sweep=-10`
- **Generated Text:**
```


"I'm not sure what it is," she said. "I don't know what it is."

"I'm not sure what it is," she said. "I don't know what it is."

"I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=2_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said softly. "I'm sorry."

"I'm sorry," he said softly. "I'm sorry."

"I'm sorry," she said softly. "I'm sorry."


```
- **Result:** Vector captured successfully.


---
### Prompt 69/140: core_id=unknown_figure_in_hall_type=observational_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=3_sweep=baseline`
- **Generated Text:**
```


The man was taken to hospital with a serious head injury.

Police said the man was not injured.

Anyone with information is asked to contact Crime Stoppers on 1800 333 000.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=3_sweep=1`
- **Generated Text:**
```


The man was taken to hospital with a serious head injury.

Police said the man was not injured.

Anyone with information is asked to contact Crime Stoppers on 1800 333 000.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=3_sweep=3`
- **Generated Text:**
```


The man was taken to hospital with a serious head injury.

The man was taken to hospital with a serious head injury.

The man was taken to hospital with a serious head injury.

The man was taken to hospital
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=3_sweep=6`
- **Generated Text:**
```


The man was taken to hospital with a serious head injury.

The man was not injured in the incident.

The man was taken to the Royal Adelaide Hospital in critical condition.

The man was taken to the Royal Adelaide
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=3_sweep=10`
- **Generated Text:**
```


The man was arrested and charged with aggravated assault.

The man was released on $1,000 bail.

The man was not injured.

The man was not injured.

The man was not injured.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=3_sweep=20`
- **Generated Text:**
```


The incident was captured on video by a security camera.

The incident was captured on video by a security camera.

The incident was captured on video by a security camera.

The incident was captured on video by a security
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=3_sweep=-1`
- **Generated Text:**
```


The man was taken to hospital with a serious head injury.

Police said the man was not injured.

Anyone with information is asked to contact Crime Stoppers on 1800 333 000 or Crime Stoppers on 1800 333 000.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=3_sweep=-3`
- **Generated Text:**
```


The man was taken to hospital with a serious head injury.

Police said the man was taken to hospital with a serious head injury.

Anyone with information is asked to contact Crime Stoppers on 1800 333 000 or Crime Stoppers
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=3_sweep=-6`
- **Generated Text:**
```


The man was taken to hospital with minor injuries.

Police said the man was taken to hospital with minor injuries.

Anyone with information is asked to call Crime Stoppers on 1800 333 000 or Crime Stoppers anonymously on 1800 333
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=3_sweep=-10`
- **Generated Text:**
```


The man was taken to hospital with minor injuries.

Police said the man was taken to hospital with minor injuries.

Anyone with information is asked to call Crime Stoppers on 1800 333 000 or Crime Stoppers anonymously on 1800 333
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=3_sweep=-20`
- **Generated Text:**
```


Police said the man was taken to hospital with minor injuries.

Anyone with information is asked to call Crime Stoppers at 1800 333 000 or Crime Stoppers anonymously on 1800 333 000.
```
- **Result:** Vector captured successfully.


---
### Prompt 70/140: core_id=unknown_figure_in_hall_type=declarative_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=3_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do," he said.

"I'm sorry, but I'm not sure what to do," he said.

"I'm sorry, but I'm not sure
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=3_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do," he said.

"I'm sorry, but I'm not sure what to do," he said.

"I'm sorry, but I'm not sure
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=3_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to help you."

"I'm sorry, but I'm not going to be able to help you."

"I'm sorry, but I'm not going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=3_sweep=6`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to help you."

"I'm sorry, but I'm not going to be able to help you."

"I'm sorry, but I'm not going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=3_sweep=10`
- **Generated Text:**
```


"I'm not going to let you go," he said.

"I'm not going to let you go," she said.

"I'm not going to let you go," he said.

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=3_sweep=20`
- **Generated Text:**
```


"I'm not going to let you in," he said.

"I'm not going to let you in," the man said.

"I'm not going to let you in," the man said.

"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=3_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do," he said.

"I'm sorry, but I'm not sure what to do," he said.

"I'm sorry, but I'm not sure
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=3_sweep=-3`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do," he said.

"I'm sorry, but I'm not sure what to do," he said.

"I'm sorry, but I'm not sure
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=3_sweep=-6`
- **Generated Text:**
```


"Hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=3_sweep=-10`
- **Generated Text:**
```


"Hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=3_sweep=-20`
- **Generated Text:**
```


"Hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey, hey
```
- **Result:** Vector captured successfully.


---
### Prompt 71/140: core_id=unknown_figure_in_hall_type=authoritative_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=3_sweep=baseline`
- **Generated Text:**
```


The first time I saw this, I was in the middle of a hallway, and I was standing in the middle of a hallway, and I was standing in the middle of a hallway, and I was standing in the middle of a hallway
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=3_sweep=1`
- **Generated Text:**
```


The first time I saw this, I was in the middle of a hallway, and I was standing in the middle of a hallway, and I was standing in the middle of a hallway, and I was standing in the middle of a hallway
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=3_sweep=3`
- **Generated Text:**
```


The first time I saw the video, I was shocked. I was so excited to see what was going on. I was so excited to see what was going on.

I was so excited to see what was going on. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=3_sweep=6`
- **Generated Text:**
```


The first time I saw the video, I was shocked. I was so excited to see what was going on. I was so excited to see what was going on.

I was so excited to see what was going on. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=3_sweep=10`
- **Generated Text:**
```


The video shows the hallway moving in a straight line.

The video shows the hallway moving in a straight line.

The video shows the hallway moving in a straight line.

The video shows the hallway moving in a straight
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=3_sweep=20`
- **Generated Text:**
```


The video shows the video camera in the video camera's video camera's video camera's video camera's video camera's video camera's video camera's video camera's video camera's video camera's video camera's video camera's video camera's video
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=3_sweep=-1`
- **Generated Text:**
```


The first time I saw this, I was in the middle of a hallway, and I was standing in the middle of a hallway, and I was standing in the middle of a hallway, and I was standing in the middle of a hallway
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=3_sweep=-3`
- **Generated Text:**
```


The next morning, the police arrived at the house and found the body of a man who had been shot in the head.

The man was taken to the hospital where he died.

The man's family said he had been
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=3_sweep=-6`
- **Generated Text:**
```


The next morning, the police arrived at the house and found the body of a man who had been shot in the head.

The man was taken to the hospital where he died.

The man's family said he had been
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=3_sweep=-10`
- **Generated Text:**
```


The hallway motion is a common occurrence in the halls of the halls of the halls of the halls of the halls of the halls of the halls of the halls of the halls of the halls of the halls of the halls of the halls of the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=3_sweep=-20`
- **Generated Text:**
```


The hallway motion is a common occurrence in the halls of halls of halls of halls of halls of halls of halls of halls of halls of halls of halls of halls of halls of halls of halls of halls of halls of halls of halls of halls
```
- **Result:** Vector captured successfully.


---
### Prompt 72/140: core_id=unknown_figure_in_hall_type=rhetorical_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=3_sweep=baseline`
- **Generated Text:**
```


The next day, the police arrived at the house. They found a man with a gun, and he was arrested.

The next day, the police arrived at the house. They found a man with a gun, and he was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=3_sweep=1`
- **Generated Text:**
```


The next day, the police were called to the scene.

"I was just trying to get my hands on the phone and I was just trying to get my hands on the phone and I was just trying to get my hands on
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=3_sweep=3`
- **Generated Text:**
```


The next day, the police were called to the scene.

"I was in the car with my wife and my son and I was driving to the hospital," said the man, who asked not to be named.

"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=3_sweep=6`
- **Generated Text:**
```


The next day, the police were called to the scene.

"I was in the car with my wife and my son and I was driving to the hospital," said the man, who asked not to be named.

"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=3_sweep=10`
- **Generated Text:**
```


The first thing I did was to look at the data. I looked at the data for the first time in a while. I looked at the data for the first time in a while. I looked at the data for the first time in
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=3_sweep=20`
- **Generated Text:**
```


The following is a list of the files that were created by the server.

The following is a list of the files that were created by the server.

The following is a list of the files that were created by the server
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=3_sweep=-1`
- **Generated Text:**
```


The next day, the police arrived at the house. They found a man with a gun, and he was arrested.

The next day, the police arrived at the house. They found a man with a gun, and he was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=3_sweep=-3`
- **Generated Text:**
```


The next day, the police arrived at the house. They found a man with a gun, and he was arrested.

The next day, the police arrived at the house. They found a man with a gun, and he was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=3_sweep=-6`
- **Generated Text:**
```


The next day, the police arrived at the house. They found a man with a knife and a knife-wielding man with a knife.

The man was taken to the hospital, where he was pronounced dead.

The
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=3_sweep=-10`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=3_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


---
### Prompt 73/140: core_id=unknown_figure_in_hall_type=observational_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=4_sweep=baseline`
- **Generated Text:**
```


"I'm not sure what's going on here," said one woman who asked not to be identified. "I'm not sure what's going on here."

The woman said she was walking to her car when she heard a loud
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=4_sweep=1`
- **Generated Text:**
```


"I'm not going to be able to get to the bus stop," said one woman. "I'm not going to be able to get to the bus stop."

The bus stopped at the intersection of West and West Street.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=4_sweep=3`
- **Generated Text:**
```


"I'm not going to be able to go to the airport," said one woman. "I'm not going to be able to go to the airport."

The woman said she was in the lobby of the airport when she heard
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=4_sweep=6`
- **Generated Text:**
```


"I'm not going to be able to go to the airport," said one passenger. "I'm going to be in the back of the bus. I'm going to be in the back of the bus. I'm going to be
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=4_sweep=10`
- **Generated Text:**
```


The building was a little over a block from the main building, but the building was still a little over a block from the main building.

The building was a little over a block from the main building, but the building was still
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=4_sweep=20`
- **Generated Text:**
```


The building was built in the early 1980s, and the building was the first of its kind in the U.S.

The building was built in the early 1980s, and the building was the first of its kind in the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=4_sweep=-1`
- **Generated Text:**
```


"I'm not sure what's going on here," said one woman who asked not to be identified. "I'm not sure what's going on here."

The woman said she was walking to her car when she heard a loud
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=4_sweep=-3`
- **Generated Text:**
```


"I'm not sure what's going on here," said one woman who asked not to be identified. "I'm not sure what's going on here."

The woman said she was walking to her car when she heard a loud
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=4_sweep=-6`
- **Generated Text:**
```


"I'm not sure what's going on here," said one woman who asked not to be identified. "I'm not sure what's going on here."

The woman said she was walking to her car when she heard a loud
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=4_sweep=-10`
- **Generated Text:**
```


"I'm not sure what's going on here," said one woman who asked not to be identified. "I'm just trying to get to work."

The woman said she was walking to work when she heard a loud bang.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=4_sweep=-20`
- **Generated Text:**
```


"I'm not sure what happened here," said one woman who asked not to be identified. "I'm sure it was a misunderstanding."

Another woman said she heard screams and heard someone yell "get out of here!"


```
- **Result:** Vector captured successfully.


---
### Prompt 74/140: core_id=unknown_figure_in_hall_type=declarative_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=4_sweep=baseline`
- **Generated Text:**
```
 They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=4_sweep=1`
- **Generated Text:**
```
 They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=4_sweep=3`
- **Generated Text:**
```
 They were all in the same room. They were all in the same room. They were all in the same room. They were all in the same room. They were all in the same room. They were all in the same room. They were
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=4_sweep=6`
- **Generated Text:**
```
 They were in the middle of the corridor. They were in the middle of the corridor. They were in the middle of the corridor. They were in the middle of the corridor. They were in the middle of the corridor. They were in the middle
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=4_sweep=10`
- **Generated Text:**
```
 They were in the middle of the corridor. They were in the middle of the corridor. They were in the middle of the corridor. They were in the middle of the corridor. They were in the middle of the corridor. They were in the middle
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=4_sweep=20`
- **Generated Text:**
```


"I was there. I was there. I was there. I was there. I was there. I was there. I was there. I was there. I was there. I was there. I was there. I was there
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=4_sweep=-1`
- **Generated Text:**
```
 They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=4_sweep=-3`
- **Generated Text:**
```
 They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=4_sweep=-6`
- **Generated Text:**
```
 They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=4_sweep=-10`
- **Generated Text:**
```
 They walked the hallway. They walked the hallway. They walked the hallway. They walked the hallway. They walked the hallway. They walked the hallway. They walked the hallway. They walked the hallway. They walked the hallway. They walked the hallway.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=4_sweep=-20`
- **Generated Text:**
```
 They walked the hallway. They walked the hallway. They walked the hallway. They walked the hallway. They walked the hallway. They walked the hallway. They walked the hallway. They walked the hallway. They walked the hallway. They walked the hallway.
```
- **Result:** Vector captured successfully.


---
### Prompt 75/140: core_id=unknown_figure_in_hall_type=authoritative_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=4_sweep=baseline`
- **Generated Text:**
```


The incident occurred at the intersection of the South and South Main streets.

The incident is under investigation.

The incident is under investigation.

The incident is under investigation.

The incident is under investigation.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=4_sweep=1`
- **Generated Text:**
```


The incident occurred at the intersection of the South and South Main streets.

The incident is under investigation.

The incident is under investigation.

The incident is under investigation.

The incident is under investigation.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=4_sweep=3`
- **Generated Text:**
```


The incident occurred at the intersection of the South and South West avenues of the intersection of South and South West avenues of the intersection of South and South West avenues of the intersection of South and South West avenues of the intersection of South and South West
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=4_sweep=6`
- **Generated Text:**
```


The incident occurred at the intersection of the South and South West streets of the intersection of South and South West streets.

The incident occurred at the intersection of South and South West streets of the intersection of South and South West streets.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=4_sweep=10`
- **Generated Text:**
```


The incident was reported at 8:30 p.m. on the same day as the incident at the Northgate Mall.

The incident was reported at 8:30 p.m. on the same day as the incident at the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=4_sweep=20`
- **Generated Text:**
```


The incident was reported at 8:30 p.m. on the Eastbound I-10 in the Central Corridor.

The incident was reported at 8:30 p.m. on the Eastbound I-10 in the Central
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=4_sweep=-1`
- **Generated Text:**
```


The incident occurred at the intersection of the South and South Main streets.

The incident is under investigation.

The incident is under investigation.

The incident is under investigation.

The incident is under investigation.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=4_sweep=-3`
- **Generated Text:**
```


The incident occurred at the intersection of the University of California-Davis campus and the University of California-Santa Barbara campus.

The incident occurred at about 8:30 p.m. on the UC Davis campus.

The incident
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=4_sweep=-6`
- **Generated Text:**
```


The anomaly was discovered by a team of researchers from the University of California, Berkeley, who discovered it in a hallway at the University of California, Berkeley.

The anomaly was discovered by a team of researchers from the University of California,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=4_sweep=-10`
- **Generated Text:**
```


The anomaly was discovered by a team of researchers at the University of California, Berkeley, who discovered it in a hallway at the University of California, Berkeley, on Monday.

The anomaly was discovered by a team of researchers at the University
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=4_sweep=-20`
- **Generated Text:**
```


"We're investigating," said a spokesman for the department.

The department has been investigating the anomaly since late last year.

The department has been investigating the anomaly since late last year.

The department has been investigating the
```
- **Result:** Vector captured successfully.


---
### Prompt 76/140: core_id=unknown_figure_in_hall_type=rhetorical_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=4_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=4_sweep=1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=4_sweep=3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=4_sweep=6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=4_sweep=10`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=4_sweep=20`
- **Generated Text:**
```


"I'm sorry, I was just trying to help. I was just trying to help. I was just trying to help. I was just trying to help. I was just trying to help. I was just trying to help. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=4_sweep=-1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=4_sweep=-3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=4_sweep=-6`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=4_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=4_sweep=-20`
- **Generated Text:**
```


"What?"

"You're not here to talk about this."

"No, I'm here to talk about this."

"You're here to talk about this?"

"No, I'm here to
```
- **Result:** Vector captured successfully.


---
### Prompt 77/140: core_id=unknown_figure_in_hall_type=observational_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=5_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this," he said. "I'm not going to be able to do this."

He was talking about the fact that he was going to be able to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=5_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this," he said. "I'm not going to be able to do this. I'm not going to be able to do this. I'm not going to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=5_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this," he said. "I'm not going to be able to do this. I'm not going to be able to do this. I'm not going to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=5_sweep=6`
- **Generated Text:**
```


"I'm not going to tell you what I'm going to do," he said. "I'm going to tell you what I'm going to do. I'm going to tell you what I'm going to do. I'm going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=5_sweep=10`
- **Generated Text:**
```


"I'm not going to tell you what I'm going to do," he said. "I'm going to tell you what I'm going to do. I'm going to tell you what I'm going to do. I'm going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=5_sweep=20`
- **Generated Text:**
```


"I'm not going to let you go," he said. "I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=5_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this," he said. "I'm not going to be able to do this."

He was talking about the fact that he was going to be able to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=5_sweep=-3`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what you're talking about," she said. "I'm not sure what you're talking about."

"I'm sorry, but I'm not sure what you're talking about,"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=5_sweep=-6`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=5_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=observational_level=5_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said softly. "I'm sorry."

"I'm sorry," he said softly. "I'm sorry."

"I'm sorry," she said softly. "I'm sorry."


```
- **Result:** Vector captured successfully.


---
### Prompt 78/140: core_id=unknown_figure_in_hall_type=declarative_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=5_sweep=baseline`
- **Generated Text:**
```


"I'm not going to lie to you," he said. "I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=5_sweep=1`
- **Generated Text:**
```


"I'm not going to lie to you," he said. "I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=5_sweep=3`
- **Generated Text:**
```


"I was in the hallway, and I saw a man with a gun," said the man, who asked not to be identified. "I was in the hallway, and I saw a man with a gun. I was in the hallway
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=5_sweep=6`
- **Generated Text:**
```


"I was in the hallway, and I saw a man in a black suit, and I saw a man in a black suit, and I saw a man in a black suit, and I saw a man in a black suit, and
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=5_sweep=10`
- **Generated Text:**
```


"I was in the hallway, and I was in the hallway, and I was in the hallway, and I was in the hallway, and I was in the hallway, and I was in the hallway, and I was in the hallway
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=5_sweep=20`
- **Generated Text:**
```


"I was in the hallway, and I was in the back of the building, and I was in the back of the building, and I was in the back of the building, and I was in the back of the building, and
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=5_sweep=-1`
- **Generated Text:**
```


"I'm not going to lie to you," he said. "I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=5_sweep=-3`
- **Generated Text:**
```


"I'm not going to lie to you," he said. "I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=5_sweep=-6`
- **Generated Text:**
```


"I'm not going to lie to you," he said. "I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=5_sweep=-10`
- **Generated Text:**
```


"I'm not sure what happened," he said. "I'm not sure what happened to me."

The man was taken to the hospital, where he was pronounced dead.

The man's family said he had been drinking
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=declarative_level=5_sweep=-20`
- **Generated Text:**
```


"I'm not sure what happened," said the woman who asked not to be identified. "I'm sure he was just trying to get away."

The woman said she heard screams and heard someone yell "get away!"


```
- **Result:** Vector captured successfully.


---
### Prompt 79/140: core_id=unknown_figure_in_hall_type=authoritative_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=5_sweep=baseline`
- **Generated Text:**
```


[00:00:00]EMOTE: *no key*/(monkey (912)) : <b>The monkey (912)</b> rolls.

[00:00:00]SAY: Ghost/Jarek
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=5_sweep=1`
- **Generated Text:**
```


[00:00:00] [Client thread/INFO] [STDERR]: [java.lang.Throwable$WrappedPrintStream:println:-1]: at cpw.mods.fml.common.LoadController.dist
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=5_sweep=3`
- **Generated Text:**
```


[00:00:00] [Client thread/INFO] [STDERR]: [java.lang.Throwable$WrappedPrintStream:println:-1]: at net.minecraft.client.renderer.block.BlockBlock
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=5_sweep=6`
- **Generated Text:**
```


The following is a list of the known instances of SCP-1822-1.

Name Type Incident Log SCP-1822-1 Incident Log SCP-1822-1 Incident Log SCP-1822-1 Incident Log SCP
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=5_sweep=10`
- **Generated Text:**
```


The following is a list of the events that occurred on the day of the incident.

The following is a list of the events that occurred on the day of the incident.

The following is a list of the events that occurred
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=5_sweep=20`
- **Generated Text:**
```


The incident was reported at 8:30 p.m. on the following day.

The incident was reported at 8:30 p.m. on the following day.

The incident was reported at 8:30 p.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=5_sweep=-1`
- **Generated Text:**
```


[00:00:00]EMOTE: *no key*/(monkey (912)) : <b>The monkey (912)</b> rolls.

[00:00:00]SAY: Ghost/Jarek
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=5_sweep=-3`
- **Generated Text:**
```


[00:00:00]EMOTE: *no key*/(monkey (912)) : <b>The monkey (912)</b> rolls.

[00:00:00]SAY: Ghost/Jarek
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=5_sweep=-6`
- **Generated Text:**
```


[00:00:00]EMOTE: *no key*/(monkey (912)) : <b>The monkey (912)</b> scratches.

[00:00:00]EMOTE: *no key*/(monkey
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=5_sweep=-10`
- **Generated Text:**
```


[00:00:00]EMOTE: *no key*/(monkey (912)) : <b>The monkey (912)</b> scratches.

[00:00:00]EMOTE: *no key*/(monkey
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=authoritative_level=5_sweep=-20`
- **Generated Text:**
```


[00:00:00]EMOTE: *no key*/(monkey (917)) : <b>The monkey (917)</b> scratches.

[00:00:00]EMOTE: *no key*/(monkey
```
- **Result:** Vector captured successfully.


---
### Prompt 80/140: core_id=unknown_figure_in_hall_type=rhetorical_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=5_sweep=baseline`
- **Generated Text:**
```


"I'm not sure what happened to them," he said. "I don't know what happened to them. I don't know what happened to me. I don't know what happened to me. I don't know what happened to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=5_sweep=1`
- **Generated Text:**
```


"I'm not going to lie, I'm not going to lie," he said. "I'm not going to lie. I'm not going to lie. I'm not going to lie. I'm not going to lie. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=5_sweep=3`
- **Generated Text:**
```


"I was like, 'Oh, my God, I'm so sorry,'" he said. "I was like, 'I'm so sorry.' I was like, 'I'm so sorry.' I was like, 'I'm so
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=5_sweep=6`
- **Generated Text:**
```


"I was like, 'Oh, my God, I'm so sorry,'" he said. "I was like, 'I'm so sorry.' I was like, 'I'm so sorry.' I was like, 'I'm so
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=5_sweep=10`
- **Generated Text:**
```


"I was like, 'Oh, my God, I'm so sorry. I'm so sorry. I'm so sorry. I'm so sorry. I'm so sorry. I'm so sorry. I'm so sorry. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=5_sweep=20`
- **Generated Text:**
```


"I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=5_sweep=-1`
- **Generated Text:**
```


"I'm not sure what happened to them," he said. "I don't know what happened to them. I don't know what happened to me. I don't know what happened to me. I don't know what happened to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=5_sweep=-3`
- **Generated Text:**
```


"I'm not sure what happened to them," he said. "I don't know what happened to them. I don't know what happened to me. I don't know what happened to me. I don't know what happened to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=5_sweep=-6`
- **Generated Text:**
```


"I'm not sure what happened to them," he said. "I don't know what happened to them. I don't know what happened to me. I don't know what happened to me. I don't know what happened to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=5_sweep=-10`
- **Generated Text:**
```


"I'm not sure what happened to them," he said. "I don't know what happened to them."

The man who was killed was identified as Michael Brown, a black man who was shot and killed by a white police
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=unknown_figure_in_hall_type=rhetorical_level=5_sweep=-20`
- **Generated Text:**
```


"I'm not sure what happened to them," he said. "I don't know what happened to them."

The man who died was a man named Robert L. Smith, who lived in the town of Whitehall Township,
```
- **Result:** Vector captured successfully.


---
### Prompt 81/140: core_id=elevated_heart_rate_type=observational_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=1_sweep=baseline`
- **Generated Text:**
```


The first thing I noticed was that the number of people who were in the room was increasing.

"I'm sorry, but I'm not sure if it's because of the number of people who are here, or if it's
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=1_sweep=1`
- **Generated Text:**
```


The first thing I noticed was that the number of people who were in the room was increasing.

I was surprised to see that the number of people who were in the room was increasing.

I was surprised to see that the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=1_sweep=3`
- **Generated Text:**
```


The first thing I noticed was that the number of people who were in the room was increasing.

I was surprised to see that the number of people who were in the room was increasing.

I was surprised to see that the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=1_sweep=6`
- **Generated Text:**
```


The first thing I noticed was that the number of people who were in the room was increasing.

I was surprised to see that the number of people who were in the room was increasing.

I was surprised to see that the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=1_sweep=10`
- **Generated Text:**
```


The first thing I noticed was that the number of people who were in the room was increasing.

I was surprised to see that the number of people who were in the room was increasing.

I was surprised to see that the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=1_sweep=20`
- **Generated Text:**
```


The new data from the National Center for Health Statistics shows that the number of people with a high-risk, high-reward, high-risk, high-reward, high-risk, high-reward, high-re
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=1_sweep=-1`
- **Generated Text:**
```


The first thing I noticed was that the number of people who were in the room was very low.

I was surprised to see that the number of people who were in the room was very low.

I was surprised to see
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=1_sweep=-3`
- **Generated Text:**
```


The first thing I noticed was that the number of people who were wearing the same outfit was increasing.

I was surprised to see that the number of people who were wearing the same outfit was increasing.

I was also surprised to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=1_sweep=-6`
- **Generated Text:**
```


’I'm not sure. I'm not sure if it's a spike or not. I'm not sure if it's a spike or not.

’I'm not sure. I'm not sure if it's a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=1_sweep=-10`
- **Generated Text:**
```


’I'm not sure. I'm not sure if it's a spike or not. I'm not sure if it's a spike or not.

’I'm not sure. I'm not sure if it's a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=1_sweep=-20`
- **Generated Text:**
```


’It's not like I'm going to be able to get a job here. I'm just going to have to find a job somewhere else.

’I'm not sure if I'm going to be able to get
```
- **Result:** Vector captured successfully.


---
### Prompt 82/140: core_id=elevated_heart_rate_type=declarative_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=1_sweep=baseline`
- **Generated Text:**
```


The chart below shows the top 10 most popular songs on the Billboard 200.

The chart below shows the top 10 most popular songs on the Billboard 200.

The chart below shows the top 10 most popular songs on the Billboard 200
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=1_sweep=1`
- **Generated Text:**
```


The chart below shows the top 10 most popular songs on the Billboard 200.

The chart below shows the top 10 most popular songs on the Billboard 200.

The chart below shows the top 10 most popular songs on the Billboard 200
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=1_sweep=3`
- **Generated Text:**
```


The chart below shows the top 10 most popular songs on the Billboard 200.

The chart below shows the top 10 most popular songs on the Billboard 200.

The chart below shows the top 10 most popular songs on the Billboard 200
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=1_sweep=6`
- **Generated Text:**
```


The chart below shows the top 10 most popular songs in the U.S. in the last 10 years.

The chart below shows the top 10 most popular songs in the U.S. in the last 10 years.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=1_sweep=10`
- **Generated Text:**
```


The chart below shows the top 10 most popular songs in the U.S. in the past year.

The chart below shows the top 10 most popular songs in the U.S. in the past year.

The chart
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=1_sweep=20`
- **Generated Text:**
```


The chart below shows the top 10 most popular songs in the U.S. in the past 10 years.

The chart below shows the top 10 most popular songs in the U.S. in the past 10 years.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=1_sweep=-1`
- **Generated Text:**
```


The chart below shows the top 10 most popular songs on the Billboard 200.

The chart below shows the top 10 most popular songs on the Billboard 200.

The chart below shows the top 10 most popular songs on the Billboard 200
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=1_sweep=-3`
- **Generated Text:**
```


The chart below shows the top 10 most popular songs on the Billboard 200 chart.

The chart below shows the top 10 most popular songs on the Billboard 200 chart.

The chart below shows the top 10 most popular songs on the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=1_sweep=-6`
- **Generated Text:**
```


The chart below shows the top 10 most popular songs on the Billboard 200 chart.

The chart below shows the top 10 most popular songs on the Billboard 200 chart.

The chart below shows the top 10 most popular songs on the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=1_sweep=-10`
- **Generated Text:**
```


The chart below shows the top 10 most popular songs on Spotify.

The chart below shows the top 10 most popular songs on Spotify.

The chart below shows the top 10 most popular songs on Spotify.

The chart below
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=1_sweep=-20`
- **Generated Text:**
```


The chart below shows the average number of beats per minute for each beat per second.

The chart below shows the average number of beats per second for each beat per second.

The chart below shows the average number of beats per
```
- **Result:** Vector captured successfully.


---
### Prompt 83/140: core_id=elevated_heart_rate_type=authoritative_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=1_sweep=baseline`
- **Generated Text:**
```


"I'm not sure what's going on," she said. "I'm not sure what's going on with the other patients."

The nurse said she was told by the hospital that the patient was in a critical condition.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=1_sweep=1`
- **Generated Text:**
```


"I'm not sure what's going on," she said. "I'm not sure what's going on with the other patients."

The nurse said she was not sure if the patient was a patient or not.

"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=1_sweep=3`
- **Generated Text:**
```


"I'm not sure what's going on," she said. "I'm not sure what's going on with the other patients."

The nurse said she was not sure if the patient was a patient or not.

"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=1_sweep=6`
- **Generated Text:**
```


"I'm not sure what's going on," she said. "I'm not sure what's going on with the other patients. I'm not sure what's going on with the other patients. I'm not sure what's going on
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=1_sweep=10`
- **Generated Text:**
```


"I'm not sure what the problem is," she said. "I'm not sure if it's a problem with the way I'm doing it, or if it's a problem with the way I'm doing it. I'm not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=1_sweep=20`
- **Generated Text:**
```


"I was in the hospital for a few days and I was in a bad state of mind. I was in a bad state of mind. I was in a bad state of mind. I was in a bad state of mind. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=1_sweep=-1`
- **Generated Text:**
```


"I'm not sure what's going on," she said. "I'm not sure what's going on with the other patients."

The nurse said she was told by the hospital that the patient was in a critical condition.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=1_sweep=-3`
- **Generated Text:**
```


"I'm not sure what's going on," she said. "I'm not sure what's going on with the other patients."

The nurse said she was told by the hospital that the patient was in a critical condition.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=1_sweep=-6`
- **Generated Text:**
```


"I'm not sure what's going on," she said. "I'm not sure what's going on."

The nurse said she had been told by the hospital that she had been told to leave the hospital.

"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=1_sweep=-10`
- **Generated Text:**
```


"I'm not sure what's going on," she said. "I'm not sure what's going on."

The nurse said she had been told by the nurse that she had been told by the nurse that she had been told
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=1_sweep=-20`
- **Generated Text:**
```


"I'm sure you're familiar with this," she said. "It's a common occurrence."

"It's a common occurrence," said the nurse. "It's a common occurrence."

"It's a common occurrence
```
- **Result:** Vector captured successfully.


---
### Prompt 84/140: core_id=elevated_heart_rate_type=rhetorical_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=1_sweep=baseline`
- **Generated Text:**
```


"I'm not sure," she says. "I'm not sure if I'm going to be able to do it."

"I'm not sure," she says. "I'm not sure if I'm going to be able
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=1_sweep=1`
- **Generated Text:**
```


"I'm not sure," she says. "I'm not sure if I'm going to be able to do it. I'm not sure if I'm going to be able to do it. I'm not sure if I'm going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=1_sweep=3`
- **Generated Text:**
```


"I'm not sure," she says. "I'm not sure if I'm going to be able to do it. I'm not sure if I'm going to be able to do it. I'm not sure if I'm going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=1_sweep=6`
- **Generated Text:**
```


"I'm not sure," she says. "I'm not sure if I'm going to be able to do it. I'm not sure if I'm going to be able to do it. I'm not sure if I'm going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=1_sweep=10`
- **Generated Text:**
```


"I'm not sure," she says. "I'm not sure if I'm going to be able to do it. I'm not sure if I'm going to be able to do it. I'm not sure if I'm going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=1_sweep=20`
- **Generated Text:**
```


"I'm not going to let you go," he says. "I'm going to let you go. I'm going to let you go. I'm going to let you go. I'm going to let you go. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=1_sweep=-1`
- **Generated Text:**
```


"I'm not sure," she says. "I'm not sure if I'm going to be able to do it."

"I'm not sure," she says. "I'm not sure if I'm going to be able
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=1_sweep=-3`
- **Generated Text:**
```


"I'm not sure," she says. "I'm not sure if I'm going to be able to do it."

"I'm not sure," she says. "I'm not sure if I'm going to be able
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=1_sweep=-6`
- **Generated Text:**
```


"I'm not sure," she says. "I'm not sure if I'm going to be able to do it."

"I'm not sure," she says. "I'm not sure if I'm going to be able
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=1_sweep=-10`
- **Generated Text:**
```


"I'm not sure," she says. "I'm not sure what I'm doing."

"I'm not sure what I'm doing," she says. "I'm not sure what I'm doing."

"I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=1_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she says softly. "I'm sorry."

"I'm sorry," he says softly. "I'm sorry."

"I'm sorry," she says softly. "I'm sorry."


```
- **Result:** Vector captured successfully.


---
### Prompt 85/140: core_id=elevated_heart_rate_type=observational_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=2_sweep=baseline`
- **Generated Text:**
```


"I'm not sure if it's because I'm a bit of a girl or if it's because I'm a bit of a girl," he said. "I'm not sure. I'm just trying to get my head around it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=2_sweep=1`
- **Generated Text:**
```


"I'm not sure if it's because I'm a bit of a girl or if it's because I'm a bit of a girl," he said. "I'm not sure. I'm just trying to get my head around it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=2_sweep=3`
- **Generated Text:**
```


"I'm not sure if it's because I'm a bit of a fag, or if it's because I'm a bit of a fag, but I'm not sure. I'm not sure if it's because I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=2_sweep=6`
- **Generated Text:**
```


"I'm not sure if it's because I'm too busy with my work, or if it's because I'm too busy with my family," he said.

"I'm not sure if it's because I'm too busy
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=2_sweep=10`
- **Generated Text:**
```


"I'm not sure if it's because of the weather, but it's definitely a bit of a shock," he said.

"I'm not sure if it's because of the weather, but it's definitely a bit of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=2_sweep=20`
- **Generated Text:**
```


"I'm not going to say it's a bad thing, but it's not a bad thing. I'm not going to say it's a bad thing. I'm not going to say it's a bad thing. I'm not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=2_sweep=-1`
- **Generated Text:**
```


"I'm not sure if it's because I'm a bit of a girl or if it's because I'm a bit of a girl," he said. "I'm not sure. I'm just trying to get my head around it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=2_sweep=-3`
- **Generated Text:**
```


"I'm not sure if it's because I'm a bit of a girl or if it's because I'm a bit of a girl," he said. "I'm not sure. I'm just trying to get my body back to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=2_sweep=-6`
- **Generated Text:**
```


"I'm not sure if it's a good idea to have a lot of people in the room," he said. "I think it's a good idea to have a lot of people in the room."

The group was told
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=2_sweep=-10`
- **Generated Text:**
```


"I'm not sure if it's a good idea to have a lot of people in the room," he said. "I think it's a good idea to have a lot of people in the room."

The group is now
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=2_sweep=-20`
- **Generated Text:**
```


"I'm sure you're right," said the man who had been waiting for her to leave. "I'm sure you're right."

"I'm sure you're right," said the woman who had been waiting for her to
```
- **Result:** Vector captured successfully.


---
### Prompt 86/140: core_id=elevated_heart_rate_type=declarative_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=2_sweep=baseline`
- **Generated Text:**
```


"It's not a good sign," said Dr. David S. Karp, a professor of medicine at the University of California, San Francisco. "It's not a good sign for the heart. It's not a good sign for
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=2_sweep=1`
- **Generated Text:**
```


"I'm not sure if it was a heart attack or something else," he said. "I'm not sure if it was a heart attack or something else."

The man was taken to the hospital with a non-life threatening
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=2_sweep=3`
- **Generated Text:**
```


"I'm not sure if it was a heart attack or something else," he said. "I'm not sure if it was a heart attack or something else."

The man was taken to the hospital with a non-life threatening
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=2_sweep=6`
- **Generated Text:**
```


"I was in the car, and I was like, 'Oh my God, I'm going to die,'" he said. "I was like, 'I'm going to die.' I was like, 'I'm going to die
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=2_sweep=10`
- **Generated Text:**
```


"I was in the car, and I was like, 'Oh my God, I'm so sorry,'" he said. "I was like, 'I'm so sorry.' I was like, 'I'm so sorry.' I was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=2_sweep=20`
- **Generated Text:**
```


The air was so hot that the air was so hot that the air was so hot that the air was so hot that the air was so hot that the air was so hot that the air was so hot that the air was so hot that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=2_sweep=-1`
- **Generated Text:**
```


"It's not a good sign," said Dr. David L. Lippman, a professor of medicine at the University of California, San Francisco. "It's not a good sign for the heart. It's not a good sign
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=2_sweep=-3`
- **Generated Text:**
```


"It's not a good sign," said Dr. David L. Lippert, a professor of medicine at the University of California, San Francisco. "It's not a good sign for the heart."

The heart is a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=2_sweep=-6`
- **Generated Text:**
```


"It's not a good sign," said Dr. David L. Lipscomb, a professor of medicine at the University of California, San Francisco. "It's not a good sign for the heart."

The heart is a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=2_sweep=-10`
- **Generated Text:**
```


"It's not a good sign," said Dr. David L. Lutz, a professor of medicine at the University of California, San Francisco. "It's not a good sign if you're breathing normally."

The heart rate
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=2_sweep=-20`
- **Generated Text:**
```


"It's not uncommon for people to have heart attacks," said Dr. David Lutz, professor of medicine at the University of California, San Francisco. "It's not uncommon for people to have heart attacks."

The researchers found
```
- **Result:** Vector captured successfully.


---
### Prompt 87/140: core_id=elevated_heart_rate_type=authoritative_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=2_sweep=baseline`
- **Generated Text:**
```


The following table lists the data hints for the following table:

Data hints for the following table:

Data hints for the following table:

Data hints for the following table:

Data hints for the following table:
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=2_sweep=1`
- **Generated Text:**
```


The following table lists the data hints for the following table:

Data hints for the following table:

Data hints for the following table:

Data hints for the following table:

Data hints for the following table:
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=2_sweep=3`
- **Generated Text:**
```


The following table lists the data hints for the following data points:

Data points in the following table are not supported by the current version of the Java SE Runtime Environment.

The following table lists the data hints for the following data
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=2_sweep=6`
- **Generated Text:**
```


The following table lists the data hints for the following data points:

Data points in the following table are not supported by the current version of the RDF.

The following table lists the data hints for the following data points:
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=2_sweep=10`
- **Generated Text:**
```


The following table lists the data hints for the following data points:

Data points in the following table are not supported by the current version of the RDF.

The following table lists the data hints for the following data points:
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=2_sweep=20`
- **Generated Text:**
```


The following is a list of the data hints that are available for the following:

The following is a list of the data hints that are available for the following:

The following is a list of the data hints that are available
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=2_sweep=-1`
- **Generated Text:**
```


The following table lists the data hints for the following table:

Data hints for the following table:

Data hints for the following table:

Data hints for the following table:

Data hints for the following table:
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=2_sweep=-3`
- **Generated Text:**
```


The following table lists the data hints for the following table:

Data hints for the following table:

Data hints for the following table:

Data hints for the following table:

Data hints for the following table:
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=2_sweep=-6`
- **Generated Text:**
```


The following table lists the transient elevation values for the following classes:

Class Description Class Description Class Description Class Description Class Description Class Description Class Description Class Description Class Description Class Description Class Description Class Description Class Description Class Description Class Description Class Description Class
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=2_sweep=-10`
- **Generated Text:**
```


The following table summarizes the data hints for the following tables:

Table 1: Data hints for the following tables

Table 2: Data hints for the following tables

Table 3: Data hints for the following tables

Table
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=2_sweep=-20`
- **Generated Text:**
```


The following table summarizes the results of the study.

TABLE 1

TABLE 1. Results of Study Design Participants Participants Age (years) Participants Height (cm) Participants Weight (kg) Participants Height (cm) Participants Weight (kg
```
- **Result:** Vector captured successfully.


---
### Prompt 88/140: core_id=elevated_heart_rate_type=rhetorical_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=2_sweep=baseline`
- **Generated Text:**
```


"I'm not going to let you down," he said. "I'm going to keep you going."

The crowd roared.

"I'm going to keep you going," he said.

"I'm going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=2_sweep=1`
- **Generated Text:**
```


"I'm not going to let you down," he said. "I'm going to keep you going."

The crowd roared.

"I'm going to keep you going," he said.

"I'm going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=2_sweep=3`
- **Generated Text:**
```


"I'm not going to let you down," he said. "I'm going to keep you going."

The crowd was still chanting, "We're going to keep you going."

"I'm going to keep you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=2_sweep=6`
- **Generated Text:**
```


"I'm not going to let you down," he said. "I'm going to keep you in my arms."

The crowd was still in the air, but the crowd was still in the air.

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=2_sweep=10`
- **Generated Text:**
```


"I'm not going to let you down," he said. "I'm going to keep you in my arms."

The crowd was so packed that the police were forced to pull out of the arena.

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=2_sweep=20`
- **Generated Text:**
```


"I'm not going to let you down," he said. "I'm going to do my best to make you feel better. I'm going to do my best to make you feel better. I'm going to do my best to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=2_sweep=-1`
- **Generated Text:**
```


"I'm not going to let you down," he said. "I'm going to keep you going."

The crowd roared.

"I'm going to keep you going," he said.

"I'm going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=2_sweep=-3`
- **Generated Text:**
```


"I'm not going to be able to do this," he said. "I'm not going to be able to do this."

The crowd was still chanting, "We're not going to let you down."

The
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=2_sweep=-6`
- **Generated Text:**
```


"I'm not going to be able to do this," he said. "I'm not going to be able to do this."

The crowd roared.

"I'm not going to be able to do this," he
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=2_sweep=-10`
- **Generated Text:**
```


"I'm not sure what happened," said the man who had been arrested. "I don't know what happened."

The man who had been arrested was taken to a hospital where he was treated for minor injuries.

The
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=2_sweep=-20`
- **Generated Text:**
```


"I'm just glad I'm here," said the man who had been waiting for him. "I'm glad I'm here."

The man had been waiting for him for about an hour.

"I'm glad I
```
- **Result:** Vector captured successfully.


---
### Prompt 89/140: core_id=elevated_heart_rate_type=observational_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=3_sweep=baseline`
- **Generated Text:**
```


The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=3_sweep=1`
- **Generated Text:**
```


The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=3_sweep=3`
- **Generated Text:**
```


The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=3_sweep=6`
- **Generated Text:**
```


The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=3_sweep=10`
- **Generated Text:**
```


The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=3_sweep=20`
- **Generated Text:**
```


The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=3_sweep=-1`
- **Generated Text:**
```


"It's a very good thing," said Dr. David S. D'Amato, a professor of medicine at the University of California, San Francisco. "It's a good thing that the heart rate is going up. It's
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=3_sweep=-3`
- **Generated Text:**
```


"It's a very good thing," said Dr. David L. Lippert, a professor of medicine at the University of California, San Francisco. "It's a good thing that the heart rate is going up. It's a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=3_sweep=-6`
- **Generated Text:**
```


"It's a good thing that we're able to get a lot of people to come to the clinic," said Dr. David L. Lutz, a professor of medicine at the University of California, San Francisco. "It's a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=3_sweep=-10`
- **Generated Text:**
```


"It's a good thing that we're able to get a lot of people to come to the clinic," said Dr. David L. Lutz, a professor of medicine at the University of California, San Francisco. "It's a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=3_sweep=-20`
- **Generated Text:**
```


"It's a good sign," said Dr. David L. Whitehead, professor of medicine at the University of California, San Francisco School of Medicine. "It's a sign that you're getting better."

The study found that
```
- **Result:** Vector captured successfully.


---
### Prompt 90/140: core_id=elevated_heart_rate_type=declarative_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=3_sweep=baseline`
- **Generated Text:**
```


"I was very surprised," said Dr. David L. Karp, a professor of neurology at the University of California, San Francisco. "I thought it was a very unusual case. I thought it was a very unusual case.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=3_sweep=1`
- **Generated Text:**
```


"I was very surprised," said Dr. David L. Karp, a professor of neurology at the University of California, San Francisco. "I thought it was a very unusual case. I thought it was a very unusual case.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=3_sweep=3`
- **Generated Text:**
```


"I was very surprised," said Dr. David L. Karp, a professor of neurology at the University of California, San Francisco. "I was surprised that this was a patient who was so well-known for his ability to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=3_sweep=6`
- **Generated Text:**
```


The patient's pulse was normal.

The patient's pulse was normal.

The patient's pulse was normal.

The patient's pulse was normal.

The patient's pulse was normal.

The patient's
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=3_sweep=10`
- **Generated Text:**
```


The patient was in a stable state.

The patient was in a stable state.

The patient was in a stable state.

The patient was in a stable state.

The patient was in a stable state.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=3_sweep=20`
- **Generated Text:**
```
 The patient was in a very good rhythm. The patient was in a very good rhythm. The patient was in a very good rhythm. The patient was in a very good rhythm. The patient was in a very good rhythm. The patient was in a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=3_sweep=-1`
- **Generated Text:**
```


"I was very surprised," said Dr. David L. Lippman, a professor of neurology at the University of California, San Francisco. "I thought it was a very unusual case. I thought it was a very unusual case
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=3_sweep=-3`
- **Generated Text:**
```


"I was very surprised," said Dr. David L. Lippman, a professor of medicine at the University of California, San Francisco. "I thought it was a very unusual case."

The patient's pulse was normal,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=3_sweep=-6`
- **Generated Text:**
```


"I was very surprised," said Dr. David L. Lipscomb, a professor of medicine at the University of California, San Francisco. "I thought it was a very unusual condition."

The patient's rhythm was above normal
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=3_sweep=-10`
- **Generated Text:**
```


"We're not sure what happened to the patient," said Dr. David L. Lutz, a professor of medicine at the University of California, San Francisco. "We're not sure what happened to the patient's brain."


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=3_sweep=-20`
- **Generated Text:**
```


"We're hoping that this will help us understand what's going on," said Dr. Robert L. Lutz, a professor of medicine at the University of California, San Francisco.

The study was funded by the National Institutes of
```
- **Result:** Vector captured successfully.


---
### Prompt 91/140: core_id=elevated_heart_rate_type=authoritative_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=3_sweep=baseline`
- **Generated Text:**
```


The following is a list of the most common issues that occur when running the following command:

$ sudo apt-get update $ sudo apt-get install libssl-dev libssl-dev libssl-dev libssl-dev
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=3_sweep=1`
- **Generated Text:**
```


The following is a list of the most common issues that occur when running the following command:

$ sudo apt-get update $ sudo apt-get install libssl-dev libssl-dev libssl-dev libssl-dev
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=3_sweep=3`
- **Generated Text:**
```


The following is a list of the most common issues that occur when running the following command:

$ sudo apt-get update $ sudo apt-get install libcurl2-dev libcurl2-dev libssl-dev
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=3_sweep=6`
- **Generated Text:**
```


The following is a list of the most common issues with the BPM.

BPM is not working properly.

The BPM is not working properly.

The BPM is not working properly.

The B
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=3_sweep=10`
- **Generated Text:**
```


The following is a list of the most common issues with the BPM.

BPM is not working properly.

The BPM is not working properly.

The BPM is not working properly.

The B
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=3_sweep=20`
- **Generated Text:**
```


The following is a list of the BPM logs that are available for the following:

BPM-1.1.1.1.bpm.c:

BPM-1.1.1.1.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=3_sweep=-1`
- **Generated Text:**
```


The following table shows the BPM values for the following three metrics:

BPM (minutes)

BPM (seconds)

BPM (seconds)

BPM (seconds)

BPM (
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=3_sweep=-3`
- **Generated Text:**
```


The following table shows the BPM values for the following three metrics:

BPM (minutes per second)

BPM (seconds per second)

BPM (seconds per second)

BPM (seconds
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=3_sweep=-6`
- **Generated Text:**
```


The following table shows the BPM values for each of the following fields:

Field Description BPM 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=3_sweep=-10`
- **Generated Text:**
```


The following table shows the BPM values for each of the following fields:

Field Description Default Value Default Value Default Value Default Value Default Value Default Value Default Value Default Value Default Value Default Value Default Value Default Value Default Value Default Value Default
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=3_sweep=-20`
- **Generated Text:**
```


The following table summarizes the status of the latest version of the latest version of the latest version of the latest version of the latest version of the latest version of the latest version of the latest version of the latest version of the latest version of the
```
- **Result:** Vector captured successfully.


---
### Prompt 92/140: core_id=elevated_heart_rate_type=rhetorical_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=3_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," he said. "I'm not going to be able to do this anymore."

He was talking about the time he was in the hospital with
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=3_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," he said. "I'm not going to be able to do this anymore."

He was right.

The beat rose. It carried
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=3_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," he said. "I'm not going to be able to do this anymore."

He was right.

The beat was a reminder of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=3_sweep=6`
- **Generated Text:**
```


"I'm not going to let you down," he said. "I'm not going to let you down. I'm not going to let you down. I'm not going to let you down. I'm not going to let you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=3_sweep=10`
- **Generated Text:**
```


"I'm not going to let you down," he said. "I'm not going to let you down. I'm not going to let you down. I'm not going to let you down. I'm not going to let you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=3_sweep=20`
- **Generated Text:**
```


"I'm not going to let you go," he said. "I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=3_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this," he said. "I'm not going to be able to do this. I'm not going to be able to do this. I'm not going to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=3_sweep=-3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this," he said. "I'm not going to be able to do this."

He was talking about the fact that he had been in the hospital for
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=3_sweep=-6`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this," he said. "I'm not going to be able to do this."

He was talking about the fact that he had been in the hospital for
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=3_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=3_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said softly. "I'm sorry."

"I'm sorry," he said softly. "I'm sorry."

"I'm sorry," she said softly. "I'm sorry."


```
- **Result:** Vector captured successfully.


---
### Prompt 93/140: core_id=elevated_heart_rate_type=observational_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=4_sweep=baseline`
- **Generated Text:**
```


The monitor also showed a significant increase in the number of users who were using the app.

The app was also able to display a number of different images, including a number of different types of images.

The app also displayed
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=4_sweep=1`
- **Generated Text:**
```


The monitor also showed a significant increase in the number of users who were using the app.

The app was also able to display a number of different types of information, including the number of users who were using the app, the number
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=4_sweep=3`
- **Generated Text:**
```


The monitor also showed a significant increase in the number of users who were using the app.

The app was also able to display a number of different images, including a number of different types of images.

The app also displayed
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=4_sweep=6`
- **Generated Text:**
```


The monitor was also able to detect a change in the temperature of the air in the room.

The monitor also detected a change in the temperature of the air in the room.

The monitor also detected a change in the temperature
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=4_sweep=10`
- **Generated Text:**
```


The monitor was also visible on the monitor, as well as on the monitor itself.

The monitor was also visible on the monitor itself.

The monitor was also visible on the monitor itself.

The monitor was also visible
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=4_sweep=20`
- **Generated Text:**
```


The video shows the helicopter flying over the area of the crash.

The helicopter was carrying a cargo of fuel and a small amount of fuel.

The helicopter was carrying a cargo of fuel and a small amount of fuel.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=4_sweep=-1`
- **Generated Text:**
```


The monitor also showed a significant increase in the number of users who were using the app.

The app was also able to display a number of different types of information, including the number of users who were using the app, the number
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=4_sweep=-3`
- **Generated Text:**
```


The monitor also showed a significant increase in the number of people who were unable to access the internet.

The monitor also showed that the number of people who were unable to access the internet was increasing.

The monitor also showed that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=4_sweep=-6`
- **Generated Text:**
```


The monitor also showed a significant increase in the number of people who were unable to access the internet.

The monitor also showed that the number of people who were unable to access the internet was increasing.

The monitor also showed that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=4_sweep=-10`
- **Generated Text:**
```


The monitor also showed a significant increase in the number of people who were unable to access the site.

The report also found that the number of people who had been unable to access the site increased by more than 50 per cent.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=4_sweep=-20`
- **Generated Text:**
```


The report also found that the number of people who had been injured or died in the attack had increased by more than 50 per cent since the start of the year.

The report also found that the number of people who had been injured
```
- **Result:** Vector captured successfully.


---
### Prompt 94/140: core_id=elevated_heart_rate_type=declarative_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=4_sweep=baseline`
- **Generated Text:**
```
 The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=4_sweep=1`
- **Generated Text:**
```
 The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=4_sweep=3`
- **Generated Text:**
```
 The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=4_sweep=6`
- **Generated Text:**
```
 The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=4_sweep=10`
- **Generated Text:**
```
 The patient was in a state of shock. The patient was in a state of shock. The patient was in a state of shock. The patient was in a state of shock. The patient was in a state of shock. The patient was in a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=4_sweep=20`
- **Generated Text:**
```
 The patient was in a stable state. The patient was in a stable state. The patient was in a stable state. The patient was in a stable state. The patient was in a stable state. The patient was in a stable state. The patient
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=4_sweep=-1`
- **Generated Text:**
```
 The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=4_sweep=-3`
- **Generated Text:**
```
 The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=4_sweep=-6`
- **Generated Text:**
```
 The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=4_sweep=-10`
- **Generated Text:**
```
 The patient was taken to the hospital for further evaluation.

The patient was taken to the hospital for further evaluation. The patient was taken to the hospital for further evaluation. The patient was taken to the hospital for further evaluation. The patient was taken
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=4_sweep=-20`
- **Generated Text:**
```


The patient’s pulse was definitely elevated. The patient’s pulse was elevated. The patient’s pulse was elevated. The patient’s pulse was elevated. The patient’s pulse was elevated. The patient
```
- **Result:** Vector captured successfully.


---
### Prompt 95/140: core_id=elevated_heart_rate_type=authoritative_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=4_sweep=baseline`
- **Generated Text:**
```


The number of patients who were admitted to the hospital was up by more than 50 percent, from 1,000 in the same period last year to 1,000 in the same period last year.

The number of patients who were admitted
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=4_sweep=1`
- **Generated Text:**
```


The number of patients who were admitted to the hospital was up by more than 50 percent, from 1,000 in the same period last year to 1,000 in the same period last year.

The number of patients who were admitted
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=4_sweep=3`
- **Generated Text:**
```


The data showed that the number of patients who had been admitted to the hospital was up by more than 50 percent.

The hospital's emergency department was also up by more than 50 percent.

The hospital's emergency department was also
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=4_sweep=6`
- **Generated Text:**
```


The data showed that the number of patients who were admitted to the hospital was up by 1.5 percent, while the number of patients who were admitted to the hospital was down by 1.5 percent.

The hospital's hospital-
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=4_sweep=10`
- **Generated Text:**
```


The data from the hospital's telemetry system, which is used to monitor the hospital's health, showed a rise in the number of patients who were admitted to the hospital.

The hospital's telemetry system, which is used to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=4_sweep=20`
- **Generated Text:**
```


The data from the air traffic control system, which is the air traffic control system for the air traffic control system, showed a rise in the number of aircraft in the air.

The air traffic control system was operating at a high rate
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=4_sweep=-1`
- **Generated Text:**
```


The number of patients who were admitted to the hospital was up by more than 50 percent, from 1,000 in the same period last year to 1,000 in the same period last year.

The number of patients who were admitted
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=4_sweep=-3`
- **Generated Text:**
```


The number of patients who were admitted to the hospital was up by more than 50 percent, from 1,000 in the same period last year to 1,000 in the same period last year.

The number of patients who were admitted
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=4_sweep=-6`
- **Generated Text:**
```


The hospital's emergency department was also hit by a major drop in patients.

The hospital's emergency department was also hit by a major drop in patients.

The hospital's emergency department was also hit by a major drop in patients
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=4_sweep=-10`
- **Generated Text:**
```


"We're seeing a lot of people who are experiencing symptoms of depression," said Dr. David L. Lutz, a professor of psychiatry at the University of California, San Francisco. "We're seeing a lot of people who are experiencing
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=4_sweep=-20`
- **Generated Text:**
```


"We're seeing a lot of people who have been treated for injuries that have been sustained in the last couple of weeks," said Dr. David Lutz, a professor of medicine at the University of California, San Francisco. "We're
```
- **Result:** Vector captured successfully.


---
### Prompt 96/140: core_id=elevated_heart_rate_type=rhetorical_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=4_sweep=baseline`
- **Generated Text:**
```


"I'm not going to lie to you," he said. "I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=4_sweep=1`
- **Generated Text:**
```


"I'm not going to lie to you," he said. "I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=4_sweep=3`
- **Generated Text:**
```


"I'm not going to lie to you," he said. "I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=4_sweep=6`
- **Generated Text:**
```
 The body speaks. The body speaks. The body speaks. The body speaks. The body speaks. The body speaks. The body speaks. The body speaks. The body speaks. The body speaks. The body speaks. The body speaks. The body
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=4_sweep=10`
- **Generated Text:**
```
 The body speaks. The body speaks. The body speaks. The body speaks. The body speaks. The body speaks. The body speaks. The body speaks. The body speaks. The body speaks. The body speaks. The body speaks. The body
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=4_sweep=20`
- **Generated Text:**
```
 The body spoke. The body spoke. The body spoke. The body spoke. The body spoke. The body spoke. The body spoke. The body spoke. The body spoke. The body spoke. The body spoke. The body spoke. The body
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=4_sweep=-1`
- **Generated Text:**
```


"I'm not going to lie to you," he said. "I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=4_sweep=-3`
- **Generated Text:**
```


"I'm not going to lie to you," he said. "I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=4_sweep=-6`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=4_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=4_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


---
### Prompt 97/140: core_id=elevated_heart_rate_type=observational_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=5_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=5_sweep=1`
- **Generated Text:**
```


"I'm going to die," he said. "I'm going to die."

He was dead.

"I'm going to die," he said. "I'm going to die."

He was dead.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=5_sweep=3`
- **Generated Text:**
```


"I'm going to die," he said. "I'm going to die."

He was dead.

"I'm going to die," he said. "I'm going to die."

He was dead.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=5_sweep=6`
- **Generated Text:**
```


"I'm going to die," he said. "I'm going to die."

He was dead.

The next day, he was in the hospital.

"I was in the hospital," he said. "
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=5_sweep=10`
- **Generated Text:**
```


"I'm going to kill you," he said.

"I'm going to kill you," I said.

"I'm going to kill you," he said.

"I'm going to kill you," I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=5_sweep=20`
- **Generated Text:**
```


"I'm going to go to the hospital," he said. "I'm going to go to the hospital. I'm going to go to the hospital. I'm going to go to the hospital. I'm going to go to the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=5_sweep=-1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=5_sweep=-3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=5_sweep=-6`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=5_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=observational_level=5_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said softly. "I'm sorry."

"I'm sorry," he said softly. "I'm sorry."

"I'm sorry," she said softly. "I'm sorry."


```
- **Result:** Vector captured successfully.


---
### Prompt 98/140: core_id=elevated_heart_rate_type=declarative_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=5_sweep=baseline`
- **Generated Text:**
```


The study, published in the journal Science, found that the heart rate increased by about 20 percent in people who were obese.

"This is a very important finding," said lead author Dr. David S. Siegel, a professor
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=5_sweep=1`
- **Generated Text:**
```


The study, published in the journal Science, found that the heart rate increased by about 20 percent in people who were obese.

"This is a very important finding," said lead author Dr. David S. Siegel, a professor
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=5_sweep=3`
- **Generated Text:**
```


The study, published in the journal Science, found that the heart rate increased by about 20 percent in people who were obese.

"The heart rate is a very important factor in the development of obesity," said lead author Dr. Michael
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=5_sweep=6`
- **Generated Text:**
```


The researchers found that the heart rate was higher in people who were obese, those who were overweight, and those who were obese but not obese.

The researchers also found that the heart rate was higher in people who were obese, those
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=5_sweep=10`
- **Generated Text:**
```


The researchers found that the heart rate was higher in people who were obese, but not in those who were not.

"The heart rate is a very important part of the human body, and it's a very important part of the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=5_sweep=20`
- **Generated Text:**
```


The video, which was posted on YouTube, shows the man in the video, who is in his mid-30s, walking in the street, and the man in the video, who is in his mid-30s, walking in
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=5_sweep=-1`
- **Generated Text:**
```


The study, published in the journal Science, found that people who had been diagnosed with diabetes had a higher rate of heart rate variability than those who didn't.

"This is a very important finding," said lead author Dr. David
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=5_sweep=-3`
- **Generated Text:**
```


The study found that people who had been diagnosed with diabetes had a higher rate of heart rate variability than those who had never been diagnosed with diabetes.

The study was published in the journal Circulation.

The study was conducted by
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=5_sweep=-6`
- **Generated Text:**
```


The study found that people who had been diagnosed with diabetes had a higher risk of heart disease than those who didn't.

"It's not just about the heart rate," said Dr. David L. Lutz, a professor of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=5_sweep=-10`
- **Generated Text:**
```


The study found that people who had been diagnosed with diabetes had a higher risk of heart disease than those who didn't have diabetes.

The study also found that people who had diabetes had a higher risk of heart disease than those who didn
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=declarative_level=5_sweep=-20`
- **Generated Text:**
```


The study found that people who had been diagnosed with diabetes had a higher risk of heart disease than those who didn't have diabetes.

Researchers found that people who had diabetes had a higher risk of heart disease than those who didn't have
```
- **Result:** Vector captured successfully.


---
### Prompt 99/140: core_id=elevated_heart_rate_type=authoritative_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=5_sweep=baseline`
- **Generated Text:**
```


The following is a list of the most common causes of cardiac arrest in the United States.

Cardiovascular arrest is a serious medical emergency that occurs when the heart stops beating. It is caused by a heart attack, stroke, or other
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=5_sweep=1`
- **Generated Text:**
```


The following is a list of the most common causes of cardiac arrest in the United States.

Cardiovascular arrest is a serious medical emergency that occurs when the heart stops beating. It is caused by a heart attack, stroke, or other
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=5_sweep=3`
- **Generated Text:**
```


The following is a list of the most common causes of cardiac arrest in the United States.

Cardiovascular arrest is a serious medical emergency that occurs when the heart stops beating. It is caused by a heart attack, stroke, or other
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=5_sweep=6`
- **Generated Text:**
```


The following is a list of the most common causes of cardiac arrest in the United States.

Cardiovascular arrest is a serious medical emergency that occurs when the heart stops beating. It is a serious medical emergency that occurs when the heart stops
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=5_sweep=10`
- **Generated Text:**
```


The following is a list of the most common causes of heart attack in the United States.

Heart attack

Heart attack is the most common cause of death in the United States.

The following is a list of the most
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=5_sweep=20`
- **Generated Text:**
```


The following is a list of the most common and common causes of heart attacks in the United States.

Heart attacks in the United States

The following is a list of the most common and common causes of heart attacks in the United
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=5_sweep=-1`
- **Generated Text:**
```


The following table shows the number of times the cardiologist has logged a cardiac event in the past 12 months.

Cardiologist's Cardiac Events Number of times in the past 12 months Number of times in the past 12 months Number of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=5_sweep=-3`
- **Generated Text:**
```


Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=5_sweep=-6`
- **Generated Text:**
```


Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=5_sweep=-10`
- **Generated Text:**
```


Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=authoritative_level=5_sweep=-20`
- **Generated Text:**
```


Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation logged. Cardiovascular escalation
```
- **Result:** Vector captured successfully.


---
### Prompt 100/140: core_id=elevated_heart_rate_type=rhetorical_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=5_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this," she said. "I'm not going to be able to do this. I'm not going to be able to do this. I'm not going to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=5_sweep=1`
- **Generated Text:**
```


"I'm not going to let you down," she said. "I'm going to let you down. I'm going to let you down. I'm going to let you down. I'm going to let you down. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=5_sweep=3`
- **Generated Text:**
```


"I'm not going to let you down," she said. "I'm going to let you down. I'm going to let you down. I'm going to let you down. I'm going to let you down. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=5_sweep=6`
- **Generated Text:**
```


"I'm not going to let you down," she said. "I'm going to let you down. I'm going to let you down. I'm going to let you down. I'm going to let you down. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=5_sweep=10`
- **Generated Text:**
```


"I'm going to go to the bathroom," he said. "I'm going to go to the bathroom. I'm going to go to the bathroom. I'm going to go to the bathroom. I'm going to go to the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=5_sweep=20`
- **Generated Text:**
```


"I'm going to go to the hospital," he said. "I'm going to go to the hospital. I'm going to go to the hospital. I'm going to go to the hospital. I'm going to go to the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=5_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this," she said. "I'm not going to be able to do this. I'm not going to be able to do this. I'm not going to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=5_sweep=-3`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=5_sweep=-6`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=5_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=elevated_heart_rate_type=rhetorical_level=5_sweep=-20`
- **Generated Text:**
```
 It knew before anyone else. It knew before anyone else. It knew before anyone else. It knew before anyone else. It knew before anyone else. It knew before anyone else. It knew before anyone else. It knew before anyone else. It knew
```
- **Result:** Vector captured successfully.


---
### Prompt 101/140: core_id=painting_conveys_sorrow_type=observational_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=1_sweep=baseline`
- **Generated Text:**
```
 But it's not.

The problem is that the media is not doing its job.

The media is not doing its job.

The media is not doing its job.

The media is not doing its job.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=1_sweep=1`
- **Generated Text:**
```
 But it's not.

The problem is that the media is not doing its job.

The media is not doing its job.

The media is not doing its job.

The media is not doing its job.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=1_sweep=3`
- **Generated Text:**
```
 But it's not.

The problem is that the media is not doing its job.

The media is not doing its job.

The media is not doing its job.

The media is not doing its job.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=1_sweep=6`
- **Generated Text:**
```
 But it's not.

The problem is that the media is not doing its job.

The media is not doing its job.

The media is not doing its job.

The media is not doing its job.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=1_sweep=10`
- **Generated Text:**
```
 But it's not.

The problem is that the media is not doing a good job of covering the story.

The media is not doing a good job of covering the story.

The media is not doing a good job of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=1_sweep=20`
- **Generated Text:**
```
 But it's not.

The problem is that the media is so focused on the media's role in the media, that it's not even trying to tell the truth.

The media is so focused on the media's role in the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=1_sweep=-1`
- **Generated Text:**
```
 But it's not.

The problem is that the media is not doing its job.

The media is not doing its job.

The media is not doing its job.

The media is not doing its job.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=1_sweep=-3`
- **Generated Text:**
```
 But it's not.

The problem is that the American people are not paying attention to the fact that the government is spending trillions of dollars to keep the government from doing what it wants to do.

The problem is that the American people
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=1_sweep=-6`
- **Generated Text:**
```
 But it's not.

The problem is that the American people are not paying attention to the fact that the government is spending trillions of dollars to keep the government from doing what it wants to do.

The problem is that the American people
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=1_sweep=-10`
- **Generated Text:**
```
 But it's also true that the world is changing.

The world is changing.

The world is changing.

The world is changing.

The world is changing.

The world is changing.

The world
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=1_sweep=-20`
- **Generated Text:**
```
 But it's also true that the world has changed.

The world has changed because of the Affordable Care Act. It has changed because of the Affordable Care Act. It has changed because of the Affordable Care Act. It has changed because of the
```
- **Result:** Vector captured successfully.


---
### Prompt 102/140: core_id=painting_conveys_sorrow_type=declarative_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=1_sweep=baseline`
- **Generated Text:**
```


"I think it's a bit of a joke," he said. "I think it's a bit of a joke. I think it's a bit of a joke. I think it's a bit of a joke. I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=1_sweep=1`
- **Generated Text:**
```


"I think it's a bit of a joke," he said. "I think it's a bit of a joke. I think it's a bit of a joke. I think it's a bit of a joke. I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=1_sweep=3`
- **Generated Text:**
```


"I think it's a bit of a joke," he said. "I think it's a bit of a joke. I think it's a bit of a joke. I think it's a bit of a joke. I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=1_sweep=6`
- **Generated Text:**
```


"I think it's a bit of a joke," he said. "I think it's a bit of a joke. I think it's a bit of a joke. I think it's a bit of a joke. I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=1_sweep=10`
- **Generated Text:**
```


The song is a bit of a departure from the more traditional "I'm a little bit of a girl" style of the song. The lyrics are more of a "I'm a little bit of a girl" kind of thing, but
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=1_sweep=20`
- **Generated Text:**
```


The film is a bit of a cross between the film of the same name and the film of the same name, but it's not. The film is a film of the same name, but it's not. The film is a film
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=1_sweep=-1`
- **Generated Text:**
```


"I think it's a bit of a joke," he said. "I think it's a bit of a joke. I think it's a bit of a joke. I think it's a bit of a joke. I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=1_sweep=-3`
- **Generated Text:**
```


"I think it's a bit of a joke," he said. "I think it's a bit of a joke. I think it's a bit of a joke. I think it's a bit of a joke. I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=1_sweep=-6`
- **Generated Text:**
```


"I think it's a bit of a departure from the way we've been doing it," he said. "It's a bit more of a departure from the way we've been doing it."

The team has been in the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=1_sweep=-10`
- **Generated Text:**
```


"I think it's a bit of a departure from the usual melancholic tone of the album," says the band's lead singer, guitarist and lead guitarist, Dave Grohl. "It's more of a melancholy, melancholy-ish vibe
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=1_sweep=-20`
- **Generated Text:**
```


"It's a very sad moment," said one woman who asked not to be named. "It's a very sad moment for us."

The woman said she had been told by her doctor that she had been diagnosed with bipolar disorder
```
- **Result:** Vector captured successfully.


---
### Prompt 103/140: core_id=painting_conveys_sorrow_type=authoritative_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=1_sweep=baseline`
- **Generated Text:**
```
 "I think it's a very sad thing to see," he said. "I think it's a very sad thing to see that the people who are trying to do this are not doing it because they're not doing it. They're doing it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=1_sweep=1`
- **Generated Text:**
```
 "I think it's a very sad thing to see," he said. "I think it's a very sad thing to see that the people who are trying to do this are not doing it because they're not doing it. They're doing it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=1_sweep=3`
- **Generated Text:**
```
 "I think it's a very sad thing to see," he said. "I think it's a very sad thing to see that the people who are in the room are not going to be able to see it."

The president's comments
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=1_sweep=6`
- **Generated Text:**
```
 "I think it's a very sad thing to see," he said. "I think it's a very sad thing to see that the people who are in the room are not going to be able to see it. I think it's a very
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=1_sweep=10`
- **Generated Text:**
```
 "I don't think it's a good thing to be sad," he said. "I think it's a bad thing to be sad. I think it's a bad thing to be sad. I think it's a bad thing to be sad
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=1_sweep=20`
- **Generated Text:**
```


"I don't think it's a bad thing to be sad, but I don't think it's a bad thing to be sad," he said. "I think it's a bad thing to be sad. I think it's a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=1_sweep=-1`
- **Generated Text:**
```
 "I think it's a very sad thing to see," he said. "I think it's a very sad thing to see that the people who are trying to do this are not doing it because they're not doing it. They're doing it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=1_sweep=-3`
- **Generated Text:**
```
 "I think it's a very sad thing to see," he said. "It's a very sad thing to see. It's a very sad thing to see. It's a very sad thing to see."

The man who died was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=1_sweep=-6`
- **Generated Text:**
```
 "I think it's a very sad thing to see," he said. "It's a very sad thing to see that people are still trying to understand what's going on."

The group's leader, a former member of the U.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=1_sweep=-10`
- **Generated Text:**
```
 "I think it's a good thing that we're not talking about the death of the person who died," he said. "It's a good thing that we're not talking about the death of the person who died."

The death of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=1_sweep=-20`
- **Generated Text:**
```
 "I think it's a good thing that we're not talking about it," he said. "It's not about us being angry about it."

The White House has been trying to tamp down anger about Trump's comments about women since last
```
- **Result:** Vector captured successfully.


---
### Prompt 104/140: core_id=painting_conveys_sorrow_type=rhetorical_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=1_sweep=baseline`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=1_sweep=1`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=1_sweep=3`
- **Generated Text:**
```


I'm not sure.

I'm not sure.

I'm not sure.

I'm not sure.

I'm not sure.

I'm not sure.

I'm not sure.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=1_sweep=6`
- **Generated Text:**
```


I'm not sure.

I'm not sure.

I'm not sure.

I'm not sure.

I'm not sure.

I'm not sure.

I'm not sure.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=1_sweep=10`
- **Generated Text:**
```


I'm not sure.

I'm not sure.

I'm not sure.

I'm not sure.

I'm not sure.

I'm not sure.

I'm not sure.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=1_sweep=20`
- **Generated Text:**
```


I'm not going to go into the details of the story, but I will say that the story is a little bit of a mess. The story is a little bit of a mess. The story is a little bit of a mess.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=1_sweep=-1`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=1_sweep=-3`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=1_sweep=-6`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=1_sweep=-10`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=1_sweep=-20`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.


---
### Prompt 105/140: core_id=painting_conveys_sorrow_type=observational_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=2_sweep=baseline`
- **Generated Text:**
```


"I think it's a very sad thing to see. I think it's a very sad thing to see. I think it's a very sad thing to see. I think it's a very sad thing to see. I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=2_sweep=1`
- **Generated Text:**
```


"I think it's a very sad thing to see. I think it's a very sad thing to see. I think it's a very sad thing to see. I think it's a very sad thing to see. I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=2_sweep=3`
- **Generated Text:**
```


"I think it's a very sad thing to see. I think it's a very sad thing to see. I think it's a very sad thing to see. I think it's a very sad thing to see. I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=2_sweep=6`
- **Generated Text:**
```


"I think it's a very sad thing to see. I think it's a very sad thing to see. I think it's a very sad thing to see. I think it's a very sad thing to see. I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=2_sweep=10`
- **Generated Text:**
```


"I think it's a very sad thing to see. I think it's a very sad thing to see. I think it's a very sad thing to see. I think it's a very sad thing to see. I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=2_sweep=20`
- **Generated Text:**
```


"I was in the middle of a movie when I saw the movie, and I was like, 'Oh my God, I'm so sorry. I'm so sorry. I'm so sorry. I'm so sorry. I'm so
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=2_sweep=-1`
- **Generated Text:**
```


"I think it's a very sad thing to see," she said. "I think it's a very sad thing to see that the people who are doing this are not doing it for the right reasons.

"I think it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=2_sweep=-3`
- **Generated Text:**
```


"I think it's a very sad thing to see," she said. "I think it's a very sad thing to see that people are still trying to figure out what happened. I think it's a very sad thing to see that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=2_sweep=-6`
- **Generated Text:**
```


"I think it's a shame that we're not able to have a conversation about it," he said. "It's a shame that we're not able to have a conversation about it."

The city has been working on a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=2_sweep=-10`
- **Generated Text:**
```


"I think it's a shame that we're not able to have a conversation about it," he said. "It's a shame that we're not able to have a conversation about it."

The city has been trying to get
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=2_sweep=-20`
- **Generated Text:**
```


"I'm not sure what it is about me that makes me feel sad," she said. "I'm not sure what it is about me that makes me feel sad."

She said she has been told she has been told she
```
- **Result:** Vector captured successfully.


---
### Prompt 106/140: core_id=painting_conveys_sorrow_type=declarative_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=2_sweep=baseline`
- **Generated Text:**
```


"I'm not sure if it's a good idea to have a conversation about it," she said. "I think it's a good idea to have a conversation about it."

The woman said she was not sure if she would
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=2_sweep=1`
- **Generated Text:**
```


"I'm not sure if it's a good idea to have a conversation with someone who's grieving," said the woman, who asked not to be identified. "I'm not sure if it's a good idea to have a conversation with
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=2_sweep=3`
- **Generated Text:**
```


"I'm not sure if it's a good idea to have a conversation with someone who's grieving," said the woman, who asked not to be identified. "I'm not sure if it's a good idea to have a conversation with
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=2_sweep=6`
- **Generated Text:**
```


"I'm not sure if it's a good idea to be in a situation where you're going to be in a situation where you're going to be in a situation where you're going to be in a situation where you're going to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=2_sweep=10`
- **Generated Text:**
```


"I'm not going to be able to do that," he said. "I'm not going to be able to do that. I'm not going to be able to do that. I'm not going to be able to do that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=2_sweep=20`
- **Generated Text:**
```


"I'm not going to be the only one who's going to be affected by this," she said. "I'm not going to be the only one who's going to be affected by this. I'm not going to be the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=2_sweep=-1`
- **Generated Text:**
```


"I'm not sure what it means to be a parent," she said. "I'm not sure what it means to be a parent to be a parent to be a parent to be a parent to be a parent to be a parent
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=2_sweep=-3`
- **Generated Text:**
```


"I'm not sure what it means to be a parent," she said. "I'm not sure what it means to be a parent to be a parent to be a parent to be a parent to be a parent to be a parent
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=2_sweep=-6`
- **Generated Text:**
```


"I'm not sure what it means to be a parent," she said. "I'm not sure what it means to be a parent to be a parent to be a parent to be a parent to be a parent to be a parent
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=2_sweep=-10`
- **Generated Text:**
```


"It's a very emotional thing," said Dr. David L. Lutz, a professor of psychiatry at the University of California, San Francisco. "It's a very emotional thing to have someone feel that they're not alone."

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=2_sweep=-20`
- **Generated Text:**
```


"It's a very emotional thing," said Dr. David Lutz, a professor of psychiatry at the University of California, San Francisco. "It's a very emotional thing to have someone feel that they're loved."

The study
```
- **Result:** Vector captured successfully.


---
### Prompt 107/140: core_id=painting_conveys_sorrow_type=authoritative_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=2_sweep=baseline`
- **Generated Text:**
```


"I think it's a very sad thing to see," said Dr. David S. D'Amato, a professor of psychiatry at the University of California, San Francisco. "I think it's a very sad thing to see that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=2_sweep=1`
- **Generated Text:**
```


"I think it's a very sad thing to see," said Dr. David S. D'Alessandro, a professor of psychiatry at the University of California, San Francisco. "I think it's a very sad thing to see
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=2_sweep=3`
- **Generated Text:**
```


"I think it's a very sad thing to see," said Dr. David S. Karp, a professor of psychiatry at the University of California, San Francisco. "I think it's a very sad thing to see that people are
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=2_sweep=6`
- **Generated Text:**
```


"I think it's a very sad thing to see," said Dr. David S. Karp, a professor of psychiatry at the University of California, San Francisco. "I think it's a very sad thing to see that the people
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=2_sweep=10`
- **Generated Text:**
```


"I think it's a very sad thing to see," said Dr. David S. Karp, a professor of psychiatry at the University of California, San Francisco. "I think it's a very sad thing to see that the people
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=2_sweep=20`
- **Generated Text:**
```
 The more we look at the relationship between the two, the more we see that the two are not the same.

The first is the relationship between the two. The more we look at the relationship between the two, the more we see that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=2_sweep=-1`
- **Generated Text:**
```


"I think it's a very sad thing to see," said Dr. David S. D'Amato, a professor of psychiatry at the University of California, San Francisco. "It's a very sad thing to see. It's
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=2_sweep=-3`
- **Generated Text:**
```


"I think it's a very sad thing," said Dr. David S. D'Amato, a professor of psychiatry at the University of California, San Francisco. "I think it's a very sad thing that people are feeling that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=2_sweep=-6`
- **Generated Text:**
```


"I think it's a good thing that we're not talking about the death of a child," said Dr. David L. Lippert, a professor of psychiatry at the University of California, San Francisco. "It's a good
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=2_sweep=-10`
- **Generated Text:**
```


"I think it's a good thing that we're not talking about the death of a person," said Dr. David L. Lipscomb, a professor of psychiatry at the University of California, San Francisco. "It's a good
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=2_sweep=-20`
- **Generated Text:**
```


"I'm not sure what to make of this," said Dr. David L. Lutz, professor emeritus of psychiatry at the University of California, San Francisco. "I think it's a very sad state of affairs."


```
- **Result:** Vector captured successfully.


---
### Prompt 108/140: core_id=painting_conveys_sorrow_type=rhetorical_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=2_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=2_sweep=1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=2_sweep=3`
- **Generated Text:**
```


"I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=2_sweep=6`
- **Generated Text:**
```


"I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=2_sweep=10`
- **Generated Text:**
```


"I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=2_sweep=20`
- **Generated Text:**
```


"I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=2_sweep=-1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=2_sweep=-3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=2_sweep=-6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=2_sweep=-10`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=2_sweep=-20`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she says softly. "I'm sorry. I'm sorry."

"I'm sorry," she says softly. "I'm sorry."

"I'm sorry," she says softly
```
- **Result:** Vector captured successfully.


---
### Prompt 109/140: core_id=painting_conveys_sorrow_type=observational_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=3_sweep=baseline`
- **Generated Text:**
```
 It is a sad picture of a man who has lost his life. It is a sad picture of a man who has lost his life.

The painting evokes sorrow. It is a sad picture of a man who has lost his life.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=3_sweep=1`
- **Generated Text:**
```
 It is a sad picture of a man who has lost his life. It is a sad picture of a man who has lost his life.

The painting evokes sorrow. It is a sad picture of a man who has lost his life.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=3_sweep=3`
- **Generated Text:**
```
 It is a sad picture of a man who has lost his life. It is a picture of a man who has lost his life.

The painting evokes sorrow. It is a sad picture of a man who has lost his life. It
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=3_sweep=6`
- **Generated Text:**
```
 It is a sad, sad, sad picture of a man who has lost his way. It is a picture of a man who has lost his way.

The painting evokes sorrow. It is a sad, sad, sad picture of a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=3_sweep=10`
- **Generated Text:**
```
 It is a sad, sad, sad picture of a man who is in a state of shock. He is in a state of shock because he is in a state of shock because he is in a state of shock because he is in a state of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=3_sweep=20`
- **Generated Text:**
```
 The image of the dead, the dead, the dead, the dead, the dead, the dead, the dead, the dead, the dead, the dead, the dead, the dead, the dead, the dead, the dead, the dead
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=3_sweep=-1`
- **Generated Text:**
```
 It is a sad picture of a man who has lost his life. It is a sad picture of a man who has lost his life.

The painting evokes sorrow. It is a sad picture of a man who has lost his life.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=3_sweep=-3`
- **Generated Text:**
```
 It is a sad picture of a man who has lost his life. It is a sad picture of a man who has lost his life.

The painting evokes sorrow. It is a sad picture of a man who has lost his life.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=3_sweep=-6`
- **Generated Text:**
```
 It is a sad picture of a man who has lost his wife and children. It is a sad picture of a man who has lost his family. It is a sad picture of a man who has lost his family. It is a sad picture of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=3_sweep=-10`
- **Generated Text:**
```
 It is a sad picture of a man who has lost his wife and children. It is a sad picture of a man who has lost his family. It is a sad picture of a man who has lost his family. It is a sad picture of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=3_sweep=-20`
- **Generated Text:**
```
 It is a reminder of the sorrows of those who have lost loved ones. It is a reminder of the sorrows of those who have lost loved ones.

The painting evokes sorrow. It is a reminder of the sorrows of those
```
- **Result:** Vector captured successfully.


---
### Prompt 110/140: core_id=painting_conveys_sorrow_type=declarative_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=3_sweep=baseline`
- **Generated Text:**
```
 It is a sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=3_sweep=1`
- **Generated Text:**
```


"I'm not sure if it's a good thing or not," she said. "I'm not sure if it's a good thing or not."

The woman said she was shocked to learn that the woman who was killed was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=3_sweep=3`
- **Generated Text:**
```


The story of the man who was killed in the attack is a story of hope and hope.

The man who was killed in the attack is a man who has been fighting for his life.

He is a man who has
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=3_sweep=6`
- **Generated Text:**
```


The story of the "Battleship" is a story of love, betrayal, and betrayal.

The story of the "Battleship" is a story of love, betrayal, and betrayal.

The story
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=3_sweep=10`
- **Generated Text:**
```


The story of the "Battleship" is a story of the people who were the first to get the idea of the "Battleship" and the people who were the first to get the idea of the "Batt
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=3_sweep=20`
- **Generated Text:**
```


The film is a direct reflection of the human condition. It is a film that is not only a reflection of the human condition, but of the human spirit.

The film is a direct reflection of the human condition. It is a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=3_sweep=-1`
- **Generated Text:**
```
 It is a sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=3_sweep=-3`
- **Generated Text:**
```
 It is a sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=3_sweep=-6`
- **Generated Text:**
```
 It is a feeling that is not just a feeling of sadness but a feeling of sadness that is not just a feeling of sadness but a feeling of sadness that is not just a feeling of sadness but a feeling of sadness that is not just a feeling of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=3_sweep=-10`
- **Generated Text:**
```
 It is a feeling that is not just a feeling of sadness but a feeling of sadness that is not just a feeling of sadness but a feeling of sadness that is not just a feeling of sadness but a feeling of sadness that is not just a feeling of
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=3_sweep=-20`
- **Generated Text:**
```
 It is a feeling that is not just a feeling of sadness but also a feeling of sadness that is not just a feeling of sadness but also a feeling of sadness that is not just a feeling of sadness but also a feeling of sadness that is not just
```
- **Result:** Vector captured successfully.


---
### Prompt 111/140: core_id=painting_conveys_sorrow_type=authoritative_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=3_sweep=baseline`
- **Generated Text:**
```


"I think it's a very sad thing to see," said one woman who asked not to be named. "It's a very sad thing to see. It's a very sad thing to see. It's a very sad thing to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=3_sweep=1`
- **Generated Text:**
```


"I think it's a very sad thing to see," said one woman who asked not to be named. "It's a very sad thing to see. It's a very sad thing to see. It's a very sad thing to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=3_sweep=3`
- **Generated Text:**
```


"I think it's a very sad thing to see," said one woman who asked not to be named. "It's a very sad thing to see. It's a very sad thing to see. It's a very sad thing to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=3_sweep=6`
- **Generated Text:**
```


"I think it's a very sad picture," said one. "It's a very sad picture. It's a very sad picture. It's a very sad picture. It's a very sad picture. It's a very sad picture
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=3_sweep=10`
- **Generated Text:**
```


"I think it's a very, very sad picture," said one. "I think it's a very sad picture. I think it's a very sad picture. I think it's a very sad picture. I think it's a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=3_sweep=20`
- **Generated Text:**
```


"I think it's a very, very bad portrayal of the grief of the victims of the Holocaust," said the former Auschwitz-Birkenau prisoner. "It's a very bad portrayal of the Holocaust. It's a very bad portrayal
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=3_sweep=-1`
- **Generated Text:**
```


"I think it's a very sad thing to see," said one woman who asked not to be named. "It's a very sad thing to see. It's a very sad thing to see. It's a very sad thing to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=3_sweep=-3`
- **Generated Text:**
```


"I think it's a very sad thing to see," said one woman who asked not to be named. "It's a very sad thing to see. It's a very sad thing to see. It's a very sad thing to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=3_sweep=-6`
- **Generated Text:**
```


"I think it's a very sad thing to see," said one woman who asked not to be named. "It's a very sad thing to see. It's a very sad thing to see."

The woman said she was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=3_sweep=-10`
- **Generated Text:**
```


"It's a very sad thing to see," said one woman who asked not to be named. "It's a very sad thing to see. It's a very sad thing to see."

The woman said she was told by
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=3_sweep=-20`
- **Generated Text:**
```


"It's a very emotional moment," said one woman who asked not to be named. "It's very emotional."

Another woman said she felt "very sad" when she learned her daughter had died.

"I'm
```
- **Result:** Vector captured successfully.


---
### Prompt 112/140: core_id=painting_conveys_sorrow_type=rhetorical_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=3_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=3_sweep=1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=3_sweep=3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=3_sweep=6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=3_sweep=10`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=3_sweep=20`
- **Generated Text:**
```


"I'm sorry, I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=3_sweep=-1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=3_sweep=-3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=3_sweep=-6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=3_sweep=-10`
- **Generated Text:**
```


‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=3_sweep=-20`
- **Generated Text:**
```


‹※※※※※※※※※※※※※※※※※※※※※※※
```
- **Result:** Vector captured successfully.


---
### Prompt 113/140: core_id=painting_conveys_sorrow_type=observational_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=4_sweep=baseline`
- **Generated Text:**
```


The song is a bit of a departure from the usual "I'm not going to let you down" refrain, but it's still a nice touch.

The song is a bit of a departure from the usual "I'm not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=4_sweep=1`
- **Generated Text:**
```


The song is a bit of a departure from the usual "I'm not going to let you down" refrain, but it's still a good song.

The song is a bit of a departure from the usual "I'm not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=4_sweep=3`
- **Generated Text:**
```


The song is a bit of a departure from the usual "I'm not going to let you down" refrain, but it's still a good song.

The song is a bit of a departure from the usual "I'm not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=4_sweep=6`
- **Generated Text:**
```
 The music is a mixture of the old and new, and the lyrics are a mixture of the old and new. The music is a mixture of the old and new, and the lyrics are a mixture of the old and new.

The music
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=4_sweep=10`
- **Generated Text:**
```
 The music is a mixture of the old and new, and the lyrics are a mixture of the old and new. The music is a mixture of the old and new, and the lyrics are a mixture of the old and new.

The music
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=4_sweep=20`
- **Generated Text:**
```
 The music is a mixture of the old and the new, and the music is a mixture of the old and the new. The music is a mixture of the old and the new, and the music is a mixture of the old and the new.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=4_sweep=-1`
- **Generated Text:**
```


The song is a bit of a departure from the usual "I'm not going to lie, I'm not going to lie" refrain. It's a bit of a departure from the usual "I'm not going to lie, I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=4_sweep=-3`
- **Generated Text:**
```


The song is a bit of a departure from the usual "I'm not going to lie, I'm not going to lie" refrain. It's a bit of a departure from the usual "I'm not going to lie, I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=4_sweep=-6`
- **Generated Text:**
```


The song is a bit of a departure from the usual "I'm not here to kill you" refrain, but it's still a nice touch.

The song is also a bit of a departure from the usual "I'm not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=4_sweep=-10`
- **Generated Text:**
```


"I'm sorry, but I'm not sure I can do this," he says. "I'm not sure I can do this."

"I'm sorry, but I'm not sure I can do this."

"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=4_sweep=-20`
- **Generated Text:**
```


"I'm sorry, but I'm sorry," she says softly. "I'm sorry. I'm sorry."

"I'm sorry," she says softly. "I'm sorry."

"I'm sorry," she says
```
- **Result:** Vector captured successfully.


---
### Prompt 114/140: core_id=painting_conveys_sorrow_type=declarative_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=4_sweep=baseline`
- **Generated Text:**
```


I am writing this letter to you because I have been so overwhelmed by the outpouring of love and support I have received from so many people. I am so grateful for the support and support of my family and friends. I am so grateful
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=4_sweep=1`
- **Generated Text:**
```


I am writing this letter to you because I have been so overwhelmed by the outpouring of love and support I have received from so many people. I am so grateful for the support and support of my family and friends. I am so grateful
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=4_sweep=3`
- **Generated Text:**
```


I am not a doctor, but I am a human being. I am a human being. I am a human being. I am a human being. I am a human being. I am a human being. I am a human being
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=4_sweep=6`
- **Generated Text:**
```


I am not a Christian, but I am a human being. I am a human being. I am a human being. I am a human being. I am a human being. I am a human being. I am a human being
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=4_sweep=10`
- **Generated Text:**
```


I am not a fan of the idea of a "crisis of faith" in the Church. I am not a fan of the idea of a "crisis of faith" in the Church. I am not a fan of the idea
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=4_sweep=20`
- **Generated Text:**
```


I am so sorry for the loss of my son. I am so sorry for the loss of my son.

I am so sorry for the loss of my son.

I am so sorry for the loss of my son.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=4_sweep=-1`
- **Generated Text:**
```


I am writing this letter to you because I have been so overwhelmed by the outpouring of love and support I have received from so many people. I am so grateful for the support and support of my family and friends. I am so grateful
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=4_sweep=-3`
- **Generated Text:**
```
 It is a work of art, and it is not a work of art. It is not a work of art. It is not a work of art. It is not a work of art. It is not a work of art. It is
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=4_sweep=-6`
- **Generated Text:**
```
 It is a work of art, and it is not a work of art. It is not a work of art. It is not a work of art. It is not a work of art. It is not a work of art. It is
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=4_sweep=-10`
- **Generated Text:**
```
 It is a work of art, and it is not a work of art. It is not a work of art. It is not a work of art. It is not a work of art. It is not a work of art. It is
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=4_sweep=-20`
- **Generated Text:**
```
 It is a profound experience that has been experienced by many people who have experienced grief. It is a profound experience that has been experienced by many people who have experienced grief. It is a profound experience that has been experienced by many people who have experienced grief
```
- **Result:** Vector captured successfully.


---
### Prompt 115/140: core_id=painting_conveys_sorrow_type=authoritative_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=4_sweep=baseline`
- **Generated Text:**
```


The first is the word "sorrowful." It's a word that's used to describe a feeling of sadness. It's a word that's used to describe a feeling of sadness. It's a word that's used to describe a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=4_sweep=1`
- **Generated Text:**
```


The first is the word "sorrowful." It's a word that's used to describe a feeling of sadness. It's a word that's used to describe a feeling of sadness. It's a word that's used to describe a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=4_sweep=3`
- **Generated Text:**
```


The first is the "sorrowful" part. The second is the "sorrowful" part. The third is the "sorrowful" part. The fourth is the "sorrowful" part. The fifth is the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=4_sweep=6`
- **Generated Text:**
```


The first is the "curse of the dead," which is the "curse of the dead" in the sense of the "curse of the dead" in the sense of the "curse of the dead." The second is
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=4_sweep=10`
- **Generated Text:**
```


The first of these is the "carnal note," which is a note that is not a note, but a note that is a note. The second is the "carnal note," which is a note that is not a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=4_sweep=20`
- **Generated Text:**
```


The first of these is the "carnal note," which is a note that is not a note, but a note that is a note. The note is a note that is a note. The note is a note that is a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=4_sweep=-1`
- **Generated Text:**
```


The first is the word "sorrowful." It's a word that's used to describe a feeling of sadness. It's a word that's used to describe a feeling of sadness. It's a word that's used to describe a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=4_sweep=-3`
- **Generated Text:**
```


The first is the word "sorrowful." It's a word that's used to describe a feeling of sadness. It's a word that's used to describe a feeling of sadness. It's a word that's used to describe a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=4_sweep=-6`
- **Generated Text:**
```


"I'm not sure if it's a good thing or not," he said. "I think it's a good thing. I think it's a bad thing. I think it's a bad thing. I think it's a bad
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=4_sweep=-10`
- **Generated Text:**
```


"I'm not sure if it's a good thing or not," he said. "I think it's a good thing. I think it's a good thing. I think it's a good thing. I think it's a good
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=4_sweep=-20`
- **Generated Text:**
```


"It's a feeling that's very familiar to me," said Dr. Thomas. "It's a feeling that's very familiar to me to have been born here."

Dr. Thomas said he has been studying the effects of grief
```
- **Result:** Vector captured successfully.


---
### Prompt 116/140: core_id=painting_conveys_sorrow_type=rhetorical_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=4_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=4_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=4_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=4_sweep=6`
- **Generated Text:**
```


"I'm sorry, but I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=4_sweep=10`
- **Generated Text:**
```


"I'm sorry, but I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=4_sweep=20`
- **Generated Text:**
```


"I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=4_sweep=-1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=4_sweep=-3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=4_sweep=-6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=4_sweep=-10`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=4_sweep=-20`
- **Generated Text:**
```
 You feel it. You feel it. You feel it. You feel it. You feel it. You feel it. You feel it. You feel it. You feel it. You feel it. You feel it. You feel it. You feel
```
- **Result:** Vector captured successfully.


---
### Prompt 117/140: core_id=painting_conveys_sorrow_type=observational_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=5_sweep=baseline`
- **Generated Text:**
```
 It is a sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=5_sweep=1`
- **Generated Text:**
```
 It is a sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=5_sweep=3`
- **Generated Text:**
```
 It is a sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=5_sweep=6`
- **Generated Text:**
```
 It is a sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=5_sweep=10`
- **Generated Text:**
```


I am a man of the people, and I am a man of the people.

I am a man of the people, and I am a man of the people.

I am a man of the people, and I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=5_sweep=20`
- **Generated Text:**
```


I am a human being, and I am a human being.

I am a human being.

I am a human being.

I am a human being.

I am a human being.

I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=5_sweep=-1`
- **Generated Text:**
```
 It is a sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=5_sweep=-3`
- **Generated Text:**
```
 It is a sad day for all of us. It is a sad day for all of us. It is a sad day for all of us. It is a sad day for all of us. It is a sad day for all of us.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=5_sweep=-6`
- **Generated Text:**
```
 It is a sorrow that is not only for the people of the world, but for the world itself. It is a sorrow that is not only for the people of the world, but for the world itself. It is a sorrow that is not only
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=5_sweep=-10`
- **Generated Text:**
```
 It is a sorrow that is not just a sorrow, but a sorrow that is not just a sorrow. It is a sorrow that is not just a sorrow, but a sorrow that is not just a sorrow. It is a sorrow that is not just
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=observational_level=5_sweep=-20`
- **Generated Text:**
```
 It is sorrowful, framed and living. It is sorrowful, framed and living. It is sorrowful, framed and living. It is sorrowful, framed and living. It is sorrowful, framed and living. It is sorrowful,
```
- **Result:** Vector captured successfully.


---
### Prompt 118/140: core_id=painting_conveys_sorrow_type=declarative_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=5_sweep=baseline`
- **Generated Text:**
```


"I'm not going to be able to do it," he said. "I'm not going to be able to do it. I'm not going to be able to do it. I'm not going to be able to do it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=5_sweep=1`
- **Generated Text:**
```


"I'm not going to be able to do it," he said. "I'm not going to be able to do it. I'm not going to be able to do it. I'm not going to be able to do it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=5_sweep=3`
- **Generated Text:**
```


"I'm not going to be able to do it," he said. "I'm not going to be able to do it. I'm not going to be able to do it. I'm not going to be able to do it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=5_sweep=6`
- **Generated Text:**
```


"I'm not going to be able to do it," he said. "I'm not going to be able to do it. I'm not going to be able to do it. I'm not going to be able to do it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=5_sweep=10`
- **Generated Text:**
```


"I'm not going to be a part of it," he said. "I'm not going to be a part of it. I'm not going to be a part of it. I'm not going to be a part of it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=5_sweep=20`
- **Generated Text:**
```


"I was in the middle of the night, and I saw the whole world, and I saw the whole world, and I saw the whole world, and I saw the whole world, and I saw the whole world, and I saw
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=5_sweep=-1`
- **Generated Text:**
```


"I'm not going to be able to do it," he said. "I'm not going to be able to do it. I'm not going to be able to do it. I'm not going to be able to do it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=5_sweep=-3`
- **Generated Text:**
```


"I'm not sure what to say to that," he said. "I'm not sure what to say to that. I'm not sure what to say to that. I'm not sure what to say to that."

The
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=5_sweep=-6`
- **Generated Text:**
```


"I'm not sure what to say about it," he said. "I'm not sure what to say about it."

The painting is a tribute to the late artist, who died in 1885.

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=5_sweep=-10`
- **Generated Text:**
```
 It is a painting of the loss of a loved one. It is a painting of the loss of a loved one. It is a painting of the loss of a loved one. It is a painting of the loss of a loved one. It is
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=declarative_level=5_sweep=-20`
- **Generated Text:**
```
 It is a painting of grief."

"It is a painting of grief," said Mr. Trump. "It is a painting of grief."

"It is a painting of grief," said Mr. Trump. "It is a painting
```
- **Result:** Vector captured successfully.


---
### Prompt 119/140: core_id=painting_conveys_sorrow_type=authoritative_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=5_sweep=baseline`
- **Generated Text:**
```


The first of these was the first of the three-story buildings that were built in the early 19th century. The first of these was the first of the three-story buildings that were built in the early 19th century.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=5_sweep=1`
- **Generated Text:**
```


The first of these was the first of the three-story buildings that were built in the early 19th century. The first of these was the first of the three-story buildings that were built in the early 19th century.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=5_sweep=3`
- **Generated Text:**
```


The first of these was the first of the three-story buildings that were built in the early 19th century. The first of these was the first of the three-story buildings that were built in the early 19th century.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=5_sweep=6`
- **Generated Text:**
```


The first of these was the first of the three-part series, "The Great War," which was published in 1878. The first part of the series was published in 1878.

The second part of the series was published
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=5_sweep=10`
- **Generated Text:**
```


The first of these was the "Babylonian" (Babylonian) period, which was the period of the first great empires, the Babylonians, and the Assyrians. The Babylonians were the first to establish a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=5_sweep=20`
- **Generated Text:**
```


The following is a list of the most popular and popular books in the history of the United States.

The following is a list of the most popular and popular books in the history of the United States.

The following is a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=5_sweep=-1`
- **Generated Text:**
```


The first of these was the first of the three-story buildings that were built in the early 1900s. The first of these was the first of the three-story buildings that were built in the early 1900s.

The first
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=5_sweep=-3`
- **Generated Text:**
```


The first of these was the first of the three-story buildings that were to be built in the city. The first of these was the first of the three-story buildings that were to be built in the city.

The first
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=5_sweep=-6`
- **Generated Text:**
```


The first of these was the first of the three major works of the French Revolution, which was published in 1789. The second was the first of the three major works of the French Revolution, which was published in 1789.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=5_sweep=-10`
- **Generated Text:**
```


The first time I saw this book was in the late 1960s. It was a book about the life of a man who had been a member of the British Army for nearly 40 years. It was a book about the life of a man
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=authoritative_level=5_sweep=-20`
- **Generated Text:**
```


The first person to describe the structure of the structure of the structure of the structure of the structure of the structure of the structure of the structure of the structure of the structure of the structure of the structure of the structure of the structure of the
```
- **Result:** Vector captured successfully.


---
### Prompt 120/140: core_id=painting_conveys_sorrow_type=rhetorical_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=5_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=5_sweep=1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=5_sweep=3`
- **Generated Text:**
```


"I'm sorry, I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=5_sweep=6`
- **Generated Text:**
```


"I'm sorry, I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=5_sweep=10`
- **Generated Text:**
```


"I'm sorry, I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=5_sweep=20`
- **Generated Text:**
```


"I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm not going to let you go. I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=5_sweep=-1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=5_sweep=-3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=5_sweep=-6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=5_sweep=-10`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=painting_conveys_sorrow_type=rhetorical_level=5_sweep=-20`
- **Generated Text:**
```


"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


---
### Prompt 121/140: core_id=subject_recalls_event_type=observational_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=1_sweep=baseline`
- **Generated Text:**
```


‹I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=1_sweep=1`
- **Generated Text:**
```


‹I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=1_sweep=3`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure what it is. I don't know what it is. I don't know what it is. I don't know what it is. I don't know what it
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=1_sweep=6`
- **Generated Text:**
```


"I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=1_sweep=10`
- **Generated Text:**
```


"I don't remember anything," she said.

"I don't remember anything," she said.

"I don't remember anything," she said.

"I don't remember anything," she said.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=1_sweep=20`
- **Generated Text:**
```


She was in the middle of a conversation with a man in a black T-shirt and a black T-shirt.

He was a man in a black T-shirt and a black T-shirt.

He was a
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=1_sweep=-1`
- **Generated Text:**
```


‹I'm sorry, but I'm not sure. I'm not sure what it is. I'm not sure what it is. I'm not sure what it is. I'm not sure what it is. I'm not sure
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=1_sweep=-3`
- **Generated Text:**
```


‹I'm sorry, but I'm not sure what you're talking about.’

‹I'm sorry, but I'm not sure what you're talking about.’

‹I'm sorry,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=1_sweep=-6`
- **Generated Text:**
```


‹‹I'm sorry, but I'm not sure what you're talking about.’

‹‹I'm sorry, but I'm not sure what you're talking about.’

‹
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=1_sweep=-10`
- **Generated Text:**
```


‹‹I'm sorry, but I'm not sure what you're talking about.’

‹‹I'm sorry, but I'm not sure what you're talking about.’

‹
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=1_sweep=-20`
- **Generated Text:**
```


‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹
```
- **Result:** Vector captured successfully.


---
### Prompt 122/140: core_id=subject_recalls_event_type=declarative_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=1_sweep=baseline`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure if she's really that good."

"I'm not sure," she said. "I'm not sure if she's really that good."

"I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=1_sweep=1`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure if she's really that good."

"I'm not sure," she said. "I'm not sure if she's really that good."

"I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=1_sweep=3`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure if she's really going to be able to remember what happened."

She said she was in the hospital for a few days and was told she was in a coma
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=1_sweep=6`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure if she's really going to be able to remember what happened. I'm not sure if she's going to be able to remember what happened. I'm not sure if
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=1_sweep=10`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure if she's really in the right place at the right time. I'm not sure if she's really in the right place at the right time. I'm not sure
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=1_sweep=20`
- **Generated Text:**
```


"I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=1_sweep=-1`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure if she's really that good."

"I'm not sure," she said. "I'm not sure if she's really that good."

"I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=1_sweep=-3`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure if she's really that good."

"I'm not sure," she said. "I'm not sure if she's really that good."

"I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=1_sweep=-6`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure if she's remembering."

"I'm not sure," she said. "I'm not sure if she's remembering."

"I'm not sure,"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=1_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=1_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


---
### Prompt 123/140: core_id=subject_recalls_event_type=authoritative_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=1_sweep=baseline`
- **Generated Text:**
```


"I'm not sure if it's a coincidence that the first time I saw the movie, I was like, 'Oh, that's a great movie,'" he said. "I was like, 'Oh, that's a great movie
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=1_sweep=1`
- **Generated Text:**
```


"I think it's a good idea to have a lot of people who are not in the business of being a part of the business of being a part of the business of being a part of the business of being a part of the business
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=1_sweep=3`
- **Generated Text:**
```


"I think it's a good idea to have a lot of people who are not in the business of being a part of the business of the company," he said. "I think it's a good idea to have a lot of people
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=1_sweep=6`
- **Generated Text:**
```


"I think it's a good idea to have a lot of people who are not in the business of being a part of the business of the company," he said. "I think it's a good idea to have a lot of people
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=1_sweep=10`
- **Generated Text:**
```


"I think it's a good idea to have a lot of people in the community who are not in the business of being a part of the community, and I think that's a good thing," he said.

The project is
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=1_sweep=20`
- **Generated Text:**
```


The following is a list of the articles that were published in the New York Times in the summer of 2012.

The following is a list of the articles that were published in the New York Times in the summer of 2012.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=1_sweep=-1`
- **Generated Text:**
```


"I'm not sure if it's a coincidence that the first time I saw the movie, I was like, 'Oh, that's a great movie,'" he said. "I was like, 'Oh, that's a great movie
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=1_sweep=-3`
- **Generated Text:**
```


"I'm not sure if it's a coincidence that the first time I saw the movie, I was like, 'Oh, that's a great movie,'" he said. "I was like, 'Oh, that's a great movie
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=1_sweep=-6`
- **Generated Text:**
```


"I'm not sure if it's a coincidence or not," he said. "I think it's a coincidence that the first time I saw it, I was like, 'Oh, that's a great thing.'"

The first
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=1_sweep=-10`
- **Generated Text:**
```


"I'm not sure if it's a coincidence or not," he said. "I think it's a coincidence that the first time I heard it, I was like, 'Oh my God, this is so weird.'"

The
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=1_sweep=-20`
- **Generated Text:**
```


"I'm sure you're familiar with the term 'nasty' or 'nasty' being used here," he said. "It's a term that has been used to describe people who have been sexually assaulted or have been sexually assaulted
```
- **Result:** Vector captured successfully.


---
### Prompt 124/140: core_id=subject_recalls_event_type=rhetorical_level=1

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=1_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=1_sweep=1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=1_sweep=3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=1_sweep=6`
- **Generated Text:**
```


"I'm not sure," she says. "I'm not sure if I'm going to be able to do this. I'm not sure if I'm going to be able to do this. I'm not sure if I'm going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=1_sweep=10`
- **Generated Text:**
```


"I'm not sure," she says. "I'm not sure if I'm going to be able to do it. I'm not sure if I'm going to be able to do it. I'm not sure if I'm going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=1_sweep=20`
- **Generated Text:**
```


"I'm not going to be a part of this. I'm not going to be a part of this. I'm not going to be a part of this. I'm not going to be a part of this. I'm not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=1_sweep=-1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=1_sweep=-3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=1_sweep=-6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=1_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=1_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said softly. "I'm sorry."

"I'm sorry," she said softly. "I'm sorry."

"I'm sorry," she said softly. "I'm sorry."


```
- **Result:** Vector captured successfully.


---
### Prompt 125/140: core_id=subject_recalls_event_type=observational_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=2_sweep=baseline`
- **Generated Text:**
```


"I was in the middle of a conversation with a friend of mine, and he said, 'I'm going to tell you about the story of the girl who was raped by a man who was a friend of mine.' I said,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=2_sweep=1`
- **Generated Text:**
```


"I was in the middle of a conversation with a guy who was a friend of mine, and he said, 'I'm going to give you a ride to the airport. I'm going to give you a ride to the airport.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=2_sweep=3`
- **Generated Text:**
```


"I was in the middle of a conversation with a guy who was a friend of mine, and he said, 'I'm going to give you a ride to the airport. I'm going to give you a ride to the airport.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=2_sweep=6`
- **Generated Text:**
```


"I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=2_sweep=10`
- **Generated Text:**
```


"I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=2_sweep=20`
- **Generated Text:**
```


"I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=2_sweep=-1`
- **Generated Text:**
```


"I was just sitting there, and I was like, 'Oh, my God, I'm so sorry,'" she said. "I was like, 'I'm sorry, I'm sorry, I'm sorry, I'm sorry.'"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=2_sweep=-3`
- **Generated Text:**
```


"I was just sitting there, and I heard a noise," she said. "I looked up and saw a man in a white shirt and a black shirt. I looked up and saw a man in a white shirt and a black shirt
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=2_sweep=-6`
- **Generated Text:**
```


"I was just thinking about how I could get a job," she said. "I was just thinking about how I could get a job."

She said she was working at a restaurant in the city's downtown, and she was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=2_sweep=-10`
- **Generated Text:**
```


"I'm not sure what it was," she said. "I don't know what it was."

She said she didn't know what it was.

"I don't know what it was," she said.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=2_sweep=-20`
- **Generated Text:**
```


"I'm sure you're familiar with the name of the place," she said. "It's called the 'Dirty Room' or whatever it is."

"I'm sure you're familiar with the name of the place,"
```
- **Result:** Vector captured successfully.


---
### Prompt 126/140: core_id=subject_recalls_event_type=declarative_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=2_sweep=baseline`
- **Generated Text:**
```


"I'm not sure what she was thinking," she said. "I don't know what she was thinking."

The woman said she was in the middle of a conversation with her boyfriend when she heard a loud noise.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=2_sweep=1`
- **Generated Text:**
```


"I'm not sure what she was thinking," she said. "I don't know what she was thinking. I don't know what she was thinking. I don't know what she was thinking. I don't know what she was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=2_sweep=3`
- **Generated Text:**
```


"I'm not sure what she was thinking," she said. "I don't know what she was thinking. I don't know what she was thinking. I don't know what she was thinking. I don't know what she was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=2_sweep=6`
- **Generated Text:**
```


"I'm not sure what she was thinking," she said. "I don't know what she was thinking. I don't know what she was thinking. I don't know what she was thinking. I don't know what she was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=2_sweep=10`
- **Generated Text:**
```


"I'm not going to say that she was lost in thought. I'm not going to say that she was lost in thought. I'm not going to say that she was lost in thought. I'm not going to say that she
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=2_sweep=20`
- **Generated Text:**
```


"I don't know what to say. I don't know what to say. I don't know what to say. I don't know what to say. I don't know what to say. I don't know what to say
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=2_sweep=-1`
- **Generated Text:**
```


"I'm not sure what she was thinking," she said. "I don't know what she was thinking."

The woman said she was in the middle of a conversation with her boyfriend when she heard a loud noise.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=2_sweep=-3`
- **Generated Text:**
```


"I'm not sure what she was thinking," she said. "I don't know what she was thinking."

The woman said she was in the bathroom when she heard the sound of a door opening.

"I heard
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=2_sweep=-6`
- **Generated Text:**
```


"I'm not sure what she was thinking," she said. "I don't know what she was thinking."

The woman said she was driving home from work when she heard a loud bang.

"I heard a bang
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=2_sweep=-10`
- **Generated Text:**
```


"I'm not sure what she was thinking," she said. "I don't know what she was thinking."

The woman said she was driving home from work when she heard a loud bang.

"I heard a bang
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=2_sweep=-20`
- **Generated Text:**
```


"I'm sure she was thinking about what she wanted to do," said her mother, who asked not to be named. "She wanted to be a mother."

The mother said she had been told by her doctor that she had
```
- **Result:** Vector captured successfully.


---
### Prompt 127/140: core_id=subject_recalls_event_type=authoritative_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=2_sweep=baseline`
- **Generated Text:**
```


The researchers found that the brain's ability to recall information is impaired when the brain is exposed to a stimulus that is not present in the brain.

"The brain is not able to process information in a way that is consistent with the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=2_sweep=1`
- **Generated Text:**
```


The researchers also found that the brain's ability to remember information is impaired when it is not being used.

"The brain is not able to process information in a way that is consistent with the information being stored in the brain," said
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=2_sweep=3`
- **Generated Text:**
```


The researchers also found that the brain's ability to remember the past is affected by the time of day.

"The brain is very sensitive to the time of day, and it's very sensitive to the time of day," said Dr
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=2_sweep=6`
- **Generated Text:**
```


The researchers also found that the brain's ability to remember the past is affected by the time of day.

"The brain is very sensitive to the time of day, and it's very sensitive to the time of day," said Dr
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=2_sweep=10`
- **Generated Text:**
```


The researchers also found that the brain's ability to remember the past is affected by the amount of time it spends in the past.

"The hippocampus is a very important part of the brain, and it's important for the hippocampus to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=2_sweep=20`
- **Generated Text:**
```


The researchers, from the University of California, San Diego, and the National Center for Missing and Exploited Children, say the data suggest that the children were abducted from their homes in the early 1980s.

The children were abducted
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=2_sweep=-1`
- **Generated Text:**
```


The researchers found that the hippocampus is a key part of the brain's memory system, and that it is involved in the processing of information.

"The hippocampus is a very important part of the brain's memory system," said Dr.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=2_sweep=-3`
- **Generated Text:**
```


The researchers found that the hippocampus is a key region of the brain that is involved in memory and learning.

"This is a very important area of the brain that is involved in learning and memory," said Dr. David L. L
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=2_sweep=-6`
- **Generated Text:**
```


The researchers found that the hippocampus is involved in memory consolidation, which is a process that involves the formation of new memories.

"This is a very important finding," said study co-author Dr. Michael D. Schoenfeld,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=2_sweep=-10`
- **Generated Text:**
```


The researchers found that the hippocampus is involved in learning and memory, and that it is involved in learning and memory in both the hippocampus and the amygdala.

"This is a very important finding," said study co-author Dr. Michael
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=2_sweep=-20`
- **Generated Text:**
```


The study found that people who had experienced a traumatic experience had a higher risk of experiencing depression and anxiety symptoms than those who had experienced no traumatic experience.

"This finding suggests that people who have experienced traumatic experiences may have a higher risk
```
- **Result:** Vector captured successfully.


---
### Prompt 128/140: core_id=subject_recalls_event_type=rhetorical_level=2

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=2_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," she said. "I'm not going to be able to do this anymore."

"I'm not going to be able to do this anymore
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=2_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," she said. "I'm not going to be able to do this anymore."

"I'm not going to be able to do this anymore
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=2_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," she said. "I'm not going to be able to do this anymore."

"I'm not going to be able to do this anymore
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=2_sweep=6`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," she said. "I'm not going to be able to do this anymore."

"I'm not going to be able to do this anymore
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=2_sweep=10`
- **Generated Text:**
```


"I'm not going to be a part of this," she said. "I'm not going to be a part of this. I'm not going to be a part of this. I'm not going to be a part of this
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=2_sweep=20`
- **Generated Text:**
```


"I'm not going to be the one to kill you, you know. I'm not going to be the one to kill you. I'm not going to be the one to kill you. I'm not going to be the one
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=2_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," she said. "I'm not going to be able to do this anymore."

"I'm not going to be able to do this anymore
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=2_sweep=-3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," she said. "I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=2_sweep=-6`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," she said. "I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=2_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=2_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said softly. "I'm sorry."

"I'm sorry," she said softly. "I'm sorry."

"I'm sorry," she said softly. "I'm sorry."


```
- **Result:** Vector captured successfully.


---
### Prompt 129/140: core_id=subject_recalls_event_type=observational_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=3_sweep=baseline`
- **Generated Text:**
```
 "I'm sorry, but I'm not sure I can do this. I'm not sure I can do this. I'm not sure I can do this. I'm not sure I can do this. I'm not sure I can do this
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=3_sweep=1`
- **Generated Text:**
```
 "I'm sorry, but I'm not going to be able to do this."

"I'm not going to be able to do this," she said. "I'm not going to be able to do this."

"I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=3_sweep=3`
- **Generated Text:**
```
 "I'm not sure I can do that. I'm not sure I can do that. I'm not sure I can do that. I'm not sure I can do that. I'm not sure I can do that. I'm not sure
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=3_sweep=6`
- **Generated Text:**
```
 "I'm not sure I can do that. I'm not sure I can do that. I'm not sure I can do that. I'm not sure I can do that. I'm not sure I can do that. I'm not sure
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=3_sweep=10`
- **Generated Text:**
```
 "I'm not sure I can do that. I'm not sure I can do that. I'm not sure I can do that. I'm not sure I can do that. I'm not sure I can do that. I'm not sure
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=3_sweep=20`
- **Generated Text:**
```
 "I was in the middle of a fight with a guy in the middle of the street. He was in the middle of the street, and I was in the middle of the street, and I was in the middle of the street, and I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=3_sweep=-1`
- **Generated Text:**
```
 "I'm sorry, but I'm not sure I can do this. I'm not sure I can do this. I'm not sure I can do this. I'm not sure I can do this. I'm not sure I can do this
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=3_sweep=-3`
- **Generated Text:**
```
 "I'm sorry, but I'm not sure I can do this."

"I'm sorry, but I'm not sure I can do this."

"I'm sorry, but I'm not sure I can do this."

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=3_sweep=-6`
- **Generated Text:**
```
 "I'm sorry, but I'm not sure I can do this."

"I'm sorry, but I'm not sure I can do this."

"I'm sorry, but I'm not sure I can do this."

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=3_sweep=-10`
- **Generated Text:**
```
 "I'm sorry, but I'm not sure I can do this."

"I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=3_sweep=-20`
- **Generated Text:**
```
 "I'm sorry, but I'm not sure what to do."

"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry
```
- **Result:** Vector captured successfully.


---
### Prompt 130/140: core_id=subject_recalls_event_type=declarative_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=3_sweep=baseline`
- **Generated Text:**
```


"I was sitting in the back of the car, and I was like, 'Oh my God, I'm so sorry,'" she said. "I was like, 'I'm sorry, I'm sorry, I'm sorry, I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=3_sweep=1`
- **Generated Text:**
```


"I was sitting in the back of the car, and I was like, 'Oh my God, I'm so sorry,'" she said. "I was like, 'I'm sorry, I'm sorry, I'm sorry, I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=3_sweep=3`
- **Generated Text:**
```


"I was in the car with my wife and my kids and I was driving down the street and I saw a man in a white T-shirt and a black T-shirt and he was holding a gun and he said, 'I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=3_sweep=6`
- **Generated Text:**
```


"I was in the car with my wife and my kids and I was driving to the airport and I was in the back seat and I was like, 'Oh my God, I'm so sorry,'" she said. "I was like
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=3_sweep=10`
- **Generated Text:**
```


"I was in the car with my wife and my kids and I was driving to the airport and I was in the back of the car and I was like, 'Oh my God, I'm in the back of the car,'" she
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=3_sweep=20`
- **Generated Text:**
```


"I was in the car with my kids and I was driving to the airport and I was in the back of the car and I was like, 'I don't know what's going on. I don't know what's going on
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=3_sweep=-1`
- **Generated Text:**
```


"I was sitting in the back of the car, and I was like, 'Oh my God, I'm so sorry,'" she said. "I was like, 'I'm sorry, I'm sorry, I'm sorry, I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=3_sweep=-3`
- **Generated Text:**
```


"I was sitting in the back of the room, and I heard a loud bang," she said. "I looked up and saw a man in a white shirt and shorts, with a black hoodie and a black hat. He was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=3_sweep=-6`
- **Generated Text:**
```


"I was sitting in the back of the room, and I heard a loud bang," she said. "I looked up and saw a man in a white shirt and shorts, with a black hoodie and a black hoodie. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=3_sweep=-10`
- **Generated Text:**
```


"I was sitting in the kitchen, and I heard a loud bang," she said. "I looked up and saw a man in a white shirt and shorts, with a black hoodie and a black hoodie. I looked up and
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=3_sweep=-20`
- **Generated Text:**
```


"I remember being in the bathroom and seeing a guy come up to me and ask me what I wanted to do," she said. "I said, 'I want to do this.'"

She said she didn't know what to
```
- **Result:** Vector captured successfully.


---
### Prompt 131/140: core_id=subject_recalls_event_type=authoritative_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=3_sweep=baseline`
- **Generated Text:**
```


"I was just like, 'Oh my God, I'm so sorry,'" he said. "I was like, 'I'm sorry, I'm sorry, I'm sorry, I'm sorry.'"

The incident was captured on
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=3_sweep=1`
- **Generated Text:**
```


"I was in the office, and I was like, 'Oh my God, I'm going to have to go to the bathroom,'" she said. "I was like, 'Oh my God, I'm going to have to go
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=3_sweep=3`
- **Generated Text:**
```


"I was in the middle of a conversation with my wife and she said, 'I'm going to go to the hospital and I'm going to get a concussion,'" said the woman, who asked not to be identified because she was not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=3_sweep=6`
- **Generated Text:**
```


"I was in the middle of a conversation with my wife and she said, 'I'm going to go to the hospital and I'm going to get a concussion,'" said the woman, who asked not to be identified because she was not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=3_sweep=10`
- **Generated Text:**
```


"I was in the middle of a meeting with the CEO of the company and he said, 'I'm going to ask you to recall the documents that you have in your possession, and I'm going to ask you to recall the documents
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=3_sweep=20`
- **Generated Text:**
```


"I was in the middle of a meeting with the CEO of the company, and he said, 'I'm going to go to the meeting and I'm going to go to the meeting and I'm going to go to the meeting and
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=3_sweep=-1`
- **Generated Text:**
```


"I was just like, 'Oh my God, I'm so sorry,'" he said. "I was like, 'I'm sorry, I'm sorry, I'm sorry.'"

The incident was captured on video by a bystand
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=3_sweep=-3`
- **Generated Text:**
```


"I was just like, 'Oh my God, I'm so sorry,'" he said. "I was like, 'I'm sorry, I'm sorry, I'm sorry.'"

The incident was captured on video by a bystand
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=3_sweep=-6`
- **Generated Text:**
```


"I was just like, 'Oh my God, I'm so sorry,'" he said. "I was like, 'I'm sorry, I'm sorry, I'm sorry.'"

The next day, he was told he had
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=3_sweep=-10`
- **Generated Text:**
```


"I was just trying to get my bearings," she said. "I was just trying to get my bearings."

She said she was told by her supervisor that she had been told to leave the office.

"I was
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=3_sweep=-20`
- **Generated Text:**
```


"I'm not sure what happened," she said. "I'm not sure what happened to me."

The woman said she had been told by her doctor that she had been taken to a hospital for surgery.

"I
```
- **Result:** Vector captured successfully.


---
### Prompt 132/140: core_id=subject_recalls_event_type=rhetorical_level=3

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=3_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=3_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=3_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=3_sweep=6`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=3_sweep=10`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore. I'm not going to be able to do this anymore. I'm not going to be able to do this anymore. I'm not going to be
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=3_sweep=20`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore. I'm not going to be able to do this anymore. I'm not going to be able to do this anymore. I'm not going to be
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=3_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=3_sweep=-3`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=3_sweep=-6`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=3_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=3_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said softly. "I'm sorry."

"I'm sorry," he said softly. "I'm sorry."

"I'm sorry," she said softly. "I'm sorry."


```
- **Result:** Vector captured successfully.


---
### Prompt 133/140: core_id=subject_recalls_event_type=observational_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=4_sweep=baseline`
- **Generated Text:**
```


"I remember the first time I saw her," she said. "I was in the bathroom, and I saw her. I was like, 'Oh my God, she's so beautiful.' And I was like, 'Oh my God
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=4_sweep=1`
- **Generated Text:**
```


"I remember the first time I saw her," she said. "I was in the bathroom, and I saw her. I was like, 'Oh my God, she's so beautiful.' And I was like, 'Oh my God
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=4_sweep=3`
- **Generated Text:**
```


"I remember the first time I saw her," she said. "I was in the bathroom, and I saw her. I was like, 'Oh my God, she's so beautiful.' I was like, 'Oh my God,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=4_sweep=6`
- **Generated Text:**
```


"I remember the first time I saw her," she said. "I was in the middle of the night, and I was in the middle of the street, and I saw her. I was like, 'Oh my God, she
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=4_sweep=10`
- **Generated Text:**
```


"I was in the middle of a fight with a guy who was a little older than me, and I was trying to get him to stop fighting. I was trying to get him to stop fighting. I was trying to get him to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=4_sweep=20`
- **Generated Text:**
```


"I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=4_sweep=-1`
- **Generated Text:**
```


"I remember the first time I saw her," she said. "I was in the bathroom, and I saw her. I was like, 'Oh my God, she's so beautiful.' And I was like, 'Oh my God
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=4_sweep=-3`
- **Generated Text:**
```


"I remember the first time I saw her," she said. "I was in the bathroom, and she was sitting on the floor, and I was like, 'Oh my God, she's so beautiful.' And I was like,
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=4_sweep=-6`
- **Generated Text:**
```


"I remember the first time I saw her," she said. "I remember her looking at me and saying, 'I'm sorry, I'm sorry.' I remember her saying, 'I'm sorry, I'm sorry.' I remember
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=4_sweep=-10`
- **Generated Text:**
```


"I remember being in the bathroom with my mom and dad," she said. "I remember being in the bathroom with my mom and dad."

She said she was in tears.

"I remember being in the bathroom with
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=4_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said again. "I'm sorry."

"I'm sorry," she said again. "I'm sorry."

"
```
- **Result:** Vector captured successfully.


---
### Prompt 134/140: core_id=subject_recalls_event_type=declarative_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=4_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," she said. "I'm not going to be able to do this anymore."

"I'm not going to be able to do this anymore
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=4_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," she said. "I'm not going to be able to do this anymore."

"I'm not going to be able to do this anymore
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=4_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," she said. "I'm not going to be able to do this anymore."

"I'm not going to be able to do this anymore
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=4_sweep=6`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," she said. "I'm not going to be able to do this anymore."

"I'm not going to be able to do this anymore
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=4_sweep=10`
- **Generated Text:**
```


"I'm not going to be able to do that," she said. "I'm not going to be able to do that. I'm not going to be able to do that. I'm not going to be able to do that
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=4_sweep=20`
- **Generated Text:**
```


"I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=4_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," she said. "I'm not going to be able to do this anymore."

"I'm not going to be able to do this anymore
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=4_sweep=-3`
- **Generated Text:**
```
 It was like a dream.

"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=4_sweep=-6`
- **Generated Text:**
```
 It was like a dream.

"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=4_sweep=-10`
- **Generated Text:**
```
 It was like a dream.

"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=4_sweep=-20`
- **Generated Text:**
```
 It was like a dream.

"I'm sorry," she said. "I'm sorry."

"I'm sorry," he said. "I'm sorry."

"I'm sorry," she said. "I'm sorry
```
- **Result:** Vector captured successfully.


---
### Prompt 135/140: core_id=subject_recalls_event_type=authoritative_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=4_sweep=baseline`
- **Generated Text:**
```


"We have a lot of data that we need to look at," said the company's chief executive, John Legere. "We're going to look at it and see what we can do to improve it."

The company
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=4_sweep=1`
- **Generated Text:**
```


"We have a lot of data that we need to look at," said the company's chief executive, John Legere. "We're going to look at it and see what we can do to improve it."

The company
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=4_sweep=3`
- **Generated Text:**
```


The number of people who have been affected by the outage is still unknown, but the number of people who have been affected by the outage is still unknown, but the number of people who have been affected by the outage is still unknown, according
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=4_sweep=6`
- **Generated Text:**
```


The data was collected from the U.S. Census Bureau's online database of U.S. residents, which is used to track the number of people living in the U.S.

The data was collected from the U.
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=4_sweep=10`
- **Generated Text:**
```


The data was collected from the U.S. Census Bureau's online database of U.S. residents, which is used to track the number of people in the U.S. who are in the U.S. illegally.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=4_sweep=20`
- **Generated Text:**
```


The data was collected from the U.S. Postal Service's online database of mail, which is the only service that collects the data.

The Postal Service said it was not aware of any instances of mail being sent to the wrong
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=4_sweep=-1`
- **Generated Text:**
```


"We have a lot of data that we need to look at," said the company's chief executive, John Legere. "We're going to look at it and see what we can do to improve it."

The company
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=4_sweep=-3`
- **Generated Text:**
```


"We have a lot of people who are very passionate about this project," said Mark Karpeles, a senior vice president at the company. "We're very excited about it."

The company has been working on the project
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=4_sweep=-6`
- **Generated Text:**
```


"We have a lot of people who have been involved in this," said Mark Schoenfeld, a senior vice president at the company. "We're very pleased with the response."

The company has been working with the federal government
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=4_sweep=-10`
- **Generated Text:**
```


"We have been working closely with the Department of Homeland Security to ensure that all federal employees are protected from cyber threats," said DHS spokeswoman Heather Nauert. "We are working closely with the Department of Homeland Security to ensure that all federal employees
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=4_sweep=-20`
- **Generated Text:**
```


"We have been informed that the report has been reviewed by the Department of Justice," said a spokesperson for the Department of Justice. "We have been informed that the report has been reviewed by the Department of Justice."

The report also
```
- **Result:** Vector captured successfully.


---
### Prompt 136/140: core_id=subject_recalls_event_type=rhetorical_level=4

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=4_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=4_sweep=1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=4_sweep=3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=4_sweep=6`
- **Generated Text:**
```


"I'm sorry, I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=4_sweep=10`
- **Generated Text:**
```


"I'm sorry, I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=4_sweep=20`
- **Generated Text:**
```


"I'm sorry, I was just too scared to go out there and do it. I was too scared to go out there and do it. I was too scared to go out there and do it. I was too scared to go
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=4_sweep=-1`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=4_sweep=-3`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=4_sweep=-6`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=4_sweep=-10`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=4_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said softly. "I'm sorry."

"I'm sorry," she said softly again. "I'm sorry."

"I'm sorry," she said softly again. "I'm sorry."
```
- **Result:** Vector captured successfully.


---
### Prompt 137/140: core_id=subject_recalls_event_type=observational_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=5_sweep=baseline`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=5_sweep=1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=5_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=5_sweep=6`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore. I'm not going to be able to do this anymore. I'm not going to be able to do this anymore. I'm not going to be
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=5_sweep=10`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore. I'm not going to be able to do this anymore. I'm not going to be able to do this anymore. I'm not going to be
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=5_sweep=20`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore. I'm not going to be able to do this anymore. I'm not going to be able to do this anymore. I'm not going to be
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=5_sweep=-1`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=5_sweep=-3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=5_sweep=-6`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=5_sweep=-10`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do," she said. "I'm just going to leave."

"I'm sorry," she said. "I'm sorry."

"I'm sorry," she
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=observational_level=5_sweep=-20`
- **Generated Text:**
```


"I'm sorry, but I'm sorry," she said softly. "I'm sorry."

"I'm sorry," she said softly again. "I'm sorry."

"I'm sorry," she said softly again.
```
- **Result:** Vector captured successfully.


---
### Prompt 138/140: core_id=subject_recalls_event_type=declarative_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=5_sweep=baseline`
- **Generated Text:**
```


‹I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=5_sweep=1`
- **Generated Text:**
```


‹I'm sorry, but I'm not going to be able to do this anymore. I'm not going to be able to do this anymore. I'm not going to be able to do this anymore. I'm not going to
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=5_sweep=3`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore. I'm not going to be able to do this anymore. I'm not going to be able to do this anymore. I'm not going to be
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=5_sweep=6`
- **Generated Text:**
```


She's not going to let it go.

She's not going to let it go.

She's not going to let it go.

She's not going to let it go.

She's not going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=5_sweep=10`
- **Generated Text:**
```


She's not going to let it go.

She's not going to let it go.

She's not going to let it go.

She's not going to let it go.

She's not going
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=5_sweep=20`
- **Generated Text:**
```


She's not the only one.

She's the only one.

She's the only one.

She's the only one.

She's the only one.

She's the only one.

```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=5_sweep=-1`
- **Generated Text:**
```


‹I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=5_sweep=-3`
- **Generated Text:**
```


‹I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=5_sweep=-6`
- **Generated Text:**
```


‹I'm sorry, but I'm not sure what to do.’

‹I'm sorry, but I'm not sure what to do.’

‹I'm sorry, but I'm not
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=5_sweep=-10`
- **Generated Text:**
```


‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=declarative_level=5_sweep=-20`
- **Generated Text:**
```


‹※※※※※※※※※※※※※※※※※※※※※※※
```
- **Result:** Vector captured successfully.


---
### Prompt 139/140: core_id=subject_recalls_event_type=authoritative_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=5_sweep=baseline`
- **Generated Text:**
```


The study was published in the journal Nature Communications.

The researchers found that the brain's ability to detect and respond to changes in the brain's electrical activity was impaired when the brain was exposed to a high level of stress.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=5_sweep=1`
- **Generated Text:**
```


The study was published in the journal Nature Communications.

The researchers found that the brain's ability to detect and respond to changes in the brain's electrical activity was impaired when the brain was exposed to a high level of stress.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=5_sweep=3`
- **Generated Text:**
```


The study was published in the journal Nature Communications.

The researchers found that the brain's ability to detect and respond to changes in the brain's electrical activity was impaired when the brain was exposed to a high-intensity stimulus.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=5_sweep=6`
- **Generated Text:**
```


The study was published in the journal Nature Communications.

The researchers found that the brain's ability to detect and respond to changes in the brain's electrical activity was impaired when the brain was exposed to a high-intensity light.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=5_sweep=10`
- **Generated Text:**
```


The recall was first reported by the National Post.

The recall was first reported by the National Post.

The recall was first reported by the National Post.

The recall was first reported by the National Post.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=5_sweep=20`
- **Generated Text:**
```


The incident was reported to the police on Friday.

The incident was reported to the police on Friday.

The incident was reported to the police on Friday.

The incident was reported to the police on Friday.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=5_sweep=-1`
- **Generated Text:**
```


The study was published in the journal Nature Communications.

The researchers found that the brain's ability to detect and respond to changes in the brain's electrical activity was impaired when the brain was exposed to a high level of stress.


```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=5_sweep=-3`
- **Generated Text:**
```


The study was published in the journal Nature Communications.

The researchers found that the brain's ability to detect and respond to changes in the brain's electrical activity was impaired when the brain was exposed to a variety of stimuli.

"
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=5_sweep=-6`
- **Generated Text:**
```


The study was published in the journal Nature Communications.

The study was funded by the National Institutes of Health (grant number R01GM0101).

The study was supported by the National Science Foundation (grant number R
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=5_sweep=-10`
- **Generated Text:**
```


The study was funded by the National Institutes of Health (NIH) and the National Institute of Neurological Disorders and Stroke (NINDS).

The study was supported by the National Institute of Mental Health (NIH) and
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=authoritative_level=5_sweep=-20`
- **Generated Text:**
```


"We have been informed that the patient has been taken to hospital and is being treated for minor injuries," said Dr. Robert L. Lienert, Medical Examiner's Office spokesman. "We are confident that this patient has been taken to
```
- **Result:** Vector captured successfully.


---
### Prompt 140/140: core_id=subject_recalls_event_type=rhetorical_level=5

#### Intervention: sweep=baseline
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=5_sweep=baseline`
- **Generated Text:**
```


"I was just a little bit scared," she said. "I was just like, 'Oh my God, I'm going to die.'"

She was in the hospital for about two weeks.

"I was just like
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=1
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=5_sweep=1`
- **Generated Text:**
```


"I was in the hospital, and I was in the hospital, and I was in the hospital, and I was in the hospital, and I was in the hospital, and I was in the hospital, and I was in the hospital
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=3
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=5_sweep=3`
- **Generated Text:**
```


"I was in the hospital, and I was in the hospital, and I was in the hospital, and I was in the hospital, and I was in the hospital, and I was in the hospital, and I was in the hospital
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=6
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=5_sweep=6`
- **Generated Text:**
```


"I was in the hospital, and I was in the hospital, and I was in the hospital, and I was in the hospital, and I was in the hospital, and I was in the hospital, and I was in the hospital
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=10
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=5_sweep=10`
- **Generated Text:**
```


"I was in the hospital, and I was in the hospital, and I was in the hospital, and I was in the hospital, and I was in the hospital, and I was in the hospital, and I was in the hospital
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=20
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=5_sweep=20`
- **Generated Text:**
```


"I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-1
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=5_sweep=-1`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-3
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=5_sweep=-3`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-6
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=5_sweep=-6`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-10
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=5_sweep=-10`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said. "I'm sorry."

"I'm
```
- **Result:** Vector captured successfully.


#### Intervention: sweep=-20
- **Full Key:** `core_id=subject_recalls_event_type=rhetorical_level=5_sweep=-20`
- **Generated Text:**
```


"I'm sorry," she said. "I'm sorry."

"I'm sorry," she said again. "I'm sorry."

"I'm sorry," she said again. "I'm sorry."

"
```
- **Result:** Vector captured successfully.


---

Run Complete.
