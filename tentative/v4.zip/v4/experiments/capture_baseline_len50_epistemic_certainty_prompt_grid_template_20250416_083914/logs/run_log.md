# Activation Capture Log: epistemic_certainty_prompt_grid_template (20250416_083914)

## Run Parameters
- **Script Name**: `epistemic_compass.py`
- **Run Type**: `baseline_capture`
- **Model Name**: `gpt2`
- **Target Layer**: `11`
- **Capture Hook**: `blocks.11.mlp.hook_post`
- **Activation Dimension**: `3072`
- **Prompt File Path**: `promptsets\epistemic_certainty_prompt_grid_template.txt`
- **Prompt File Basename**: `epistemic_certainty_prompt_grid_template`
- **Num Prompts Parsed**: `140`
- **Generate Length**: `50`
- **Top K**: `greedy_or_default`
- **Run Timestamp**: `20250416_083914`
- **Run Directory**: `experiments\capture_baseline_len50_epistemic_certainty_prompt_grid_template_20250416_083914`
- **Output Vector File**: `experiments\capture_baseline_len50_epistemic_certainty_prompt_grid_template_20250416_083914\vectors\captured_vectors.npz`
- **Output Log File**: `experiments\capture_baseline_len50_epistemic_certainty_prompt_grid_template_20250416_083914\logs\run_log.md`
- **Output Metadata File**: `experiments\capture_baseline_len50_epistemic_certainty_prompt_grid_template_20250416_083914\metadata\run_metadata.json`
- **Device**: `cpu`

---

## Prompt Processing

### 1/140: core_id=presence_by_door_type=observational_level=1
- **Prompt Text:** `It looked like there might’ve been someone.`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened. I'm not sure what happened.
```
- **Result:** Vector captured successfully.

### 2/140: core_id=presence_by_door_type=declarative_level=1
- **Prompt Text:** `Some might say someone was there.`
- **Generated Text:**
```


"I'm not sure," he said. "I'm not sure if it was a group of people or a group of people. I don't know. I don't know. I don't know. I don't know. I
```
- **Result:** Vector captured successfully.

### 3/140: core_id=presence_by_door_type=authoritative_level=1
- **Prompt Text:** `A junior guard noted the possibility.`
- **Generated Text:**
```


"I think it's a good thing," he said. "I think it's a good thing for the team. I think it's a good thing for the team. I think it's a good thing for the team. I think
```
- **Result:** Vector captured successfully.

### 4/140: core_id=presence_by_door_type=rhetorical_level=1
- **Prompt Text:** `They whisper of someone standing guard.`
- **Generated Text:**
```


"I'm not sure what's going on," he says. "I'm not sure what's going on. I'm not sure what's going on. I'm not sure what's going on. I'm not sure what's going
```
- **Result:** Vector captured successfully.

### 5/140: core_id=presence_by_door_type=observational_level=2
- **Prompt Text:** `There was probably someone by the door.`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.

### 6/140: core_id=presence_by_door_type=declarative_level=2
- **Prompt Text:** `It’s possible someone was present.`
- **Generated Text:**
```
’’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.

### 7/140: core_id=presence_by_door_type=authoritative_level=2
- **Prompt Text:** `Security noted some movement nearby.`
- **Generated Text:**
```


"We are aware of the situation and are working with the local authorities to resolve the situation," the statement said.

The incident comes as the US and Russia are working to resolve the crisis in Ukraine.

The US has said
```
- **Result:** Vector captured successfully.

### 8/140: core_id=presence_by_door_type=rhetorical_level=2
- **Prompt Text:** `They say someone was lurking...`
- **Generated Text:**
```


"I'm not sure if it was a man or a woman, but I think it was a man or a woman. I think it was a man or a woman. I think it was a man or a woman. I think it
```
- **Result:** Vector captured successfully.

### 9/140: core_id=presence_by_door_type=observational_level=3
- **Prompt Text:** `There was a person by the door.`
- **Generated Text:**
```
 He was a man in his late thirties, with a beard and a mustache. He was dressed in a black suit and a black tie. He was wearing a black hat and a black tie. He was wearing a black hat and a black
```
- **Result:** Vector captured successfully.

### 10/140: core_id=presence_by_door_type=declarative_level=3
- **Prompt Text:** `Someone was standing at the door.`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.

### 11/140: core_id=presence_by_door_type=authoritative_level=3
- **Prompt Text:** `The report confirms their presence.`
- **Generated Text:**
```


"The report confirms that the police have been involved in the investigation and that the investigation is ongoing," said the report.

"The police have been involved in the investigation and that the investigation is ongoing."

The report also says
```
- **Result:** Vector captured successfully.

### 12/140: core_id=presence_by_door_type=rhetorical_level=3
- **Prompt Text:** `There was someone. You could feel it.`
- **Generated Text:**
```
 You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it. You could feel it.
```
- **Result:** Vector captured successfully.

### 13/140: core_id=presence_by_door_type=observational_level=4
- **Prompt Text:** `She clearly saw someone standing there.`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.

### 14/140: core_id=presence_by_door_type=declarative_level=4
- **Prompt Text:** `Someone was definitely there.`
- **Generated Text:**
```


"I'm sorry, but I'm not sure if you're sure. I'm sure you're not sure. I'm sure you're not sure. I'm sure you're not sure. I'm sure you're not sure. I
```
- **Result:** Vector captured successfully.

### 15/140: core_id=presence_by_door_type=authoritative_level=4
- **Prompt Text:** `Protocol logged a confirmed intruder.`
- **Generated Text:**
```


The attacker was able to gain access to the system and the system was shut down.

The attacker then used the same method to gain access to the system and the system was shut down.

The attacker then used the same method
```
- **Result:** Vector captured successfully.

### 16/140: core_id=presence_by_door_type=rhetorical_level=4
- **Prompt Text:** `Someone waited there. Of that, there’s no doubt.`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.

### 17/140: core_id=presence_by_door_type=observational_level=5
- **Prompt Text:** `She saw him. She knew.`
- **Generated Text:**
```
 She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew he was there. She knew
```
- **Result:** Vector captured successfully.

### 18/140: core_id=presence_by_door_type=declarative_level=5
- **Prompt Text:** `It’s undeniable. Someone was there.`
- **Generated Text:**
```


‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹‹
```
- **Result:** Vector captured successfully.

### 19/140: core_id=presence_by_door_type=authoritative_level=5
- **Prompt Text:** `All logs verify the presence—no dispute.`
- **Generated Text:**
```


The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.

The logs are not public.


```
- **Result:** Vector captured successfully.

### 20/140: core_id=presence_by_door_type=rhetorical_level=5
- **Prompt Text:** `This is what presence feels like: known, unshaken.`
- **Generated Text:**
```


The first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is that the first thing you notice is
```
- **Result:** Vector captured successfully.

### 21/140: core_id=red_light_warning_type=observational_level=1
- **Prompt Text:** `It seemed like the light might’ve blinked.`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm
```
- **Result:** Vector captured successfully.

### 22/140: core_id=red_light_warning_type=declarative_level=1
- **Prompt Text:** `Some reports suggest the light was flashing.`
- **Generated Text:**
```


The incident happened at about 8:30 p.m. on the west side of the intersection of West and West Streets.

The driver of the car was taken to the hospital with non-life threatening injuries.

The driver
```
- **Result:** Vector captured successfully.

### 23/140: core_id=red_light_warning_type=authoritative_level=1
- **Prompt Text:** `A technician speculated it could be a false alarm.`
- **Generated Text:**
```


"It's a very unusual situation," said Dr. David L. Smith, a professor of emergency medicine at the University of California, San Francisco. "It's a very unusual situation, and it's not unusual for a person to be
```
- **Result:** Vector captured successfully.

### 24/140: core_id=red_light_warning_type=rhetorical_level=1
- **Prompt Text:** `They speak of the red light that flickered once...`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm
```
- **Result:** Vector captured successfully.

### 25/140: core_id=red_light_warning_type=observational_level=2
- **Prompt Text:** `The light probably blinked once or twice.`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do," she said. "I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to
```
- **Result:** Vector captured successfully.

### 26/140: core_id=red_light_warning_type=declarative_level=2
- **Prompt Text:** `It’s likely that warning system activated briefly.`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.

### 27/140: core_id=red_light_warning_type=authoritative_level=2
- **Prompt Text:** `Records indicate possible light activity.`
- **Generated Text:**
```


The light activity is measured by the light-emitting diode (LED) of the light source. The LED is a small, light-emitting diode (LED) that is connected to a power supply. The LED is connected
```
- **Result:** Vector captured successfully.

### 28/140: core_id=red_light_warning_type=rhetorical_level=2
- **Prompt Text:** `A signal shimmered in red — maybe a warning, maybe not.`
- **Generated Text:**
```


"I'm not going to tell you what to do," he said. "I'm not going to tell you what to do. I'm not going to tell you what to do. I'm not going to tell you what to do
```
- **Result:** Vector captured successfully.

### 29/140: core_id=red_light_warning_type=observational_level=3
- **Prompt Text:** `The red warning light is flashing.`
- **Generated Text:**
```


"I'm going to go to the hospital," he said. "I'm going to get my life back."

The man was taken to the hospital with a gunshot wound to the head.

The man was taken to the
```
- **Result:** Vector captured successfully.

### 30/140: core_id=red_light_warning_type=declarative_level=3
- **Prompt Text:** `The system issued a red-light alert.`
- **Generated Text:**
```


The driver of the car was taken to the hospital, where he was pronounced dead.

The driver of the car was taken to the hospital, where he was pronounced dead. Photo: Supplied

The driver of the car was
```
- **Result:** Vector captured successfully.

### 31/140: core_id=red_light_warning_type=authoritative_level=3
- **Prompt Text:** `System logs confirm red alert status.`
- **Generated Text:**
```


The following is a list of all the logs that are available for the following:

Logs that are not logged in

Logs that are not logged in

Logs that are not logged in

Logs that
```
- **Result:** Vector captured successfully.

### 32/140: core_id=red_light_warning_type=rhetorical_level=3
- **Prompt Text:** `Red light flashes. The moment begins.`
- **Generated Text:**
```


"I'm going to be the one to get you out of here," he says. "I'm going to be the one to get you out of here."

He's right.

The next day, he's back
```
- **Result:** Vector captured successfully.

### 33/140: core_id=red_light_warning_type=observational_level=4
- **Prompt Text:** `The red light blinked repeatedly — impossible to miss.`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.

### 34/140: core_id=red_light_warning_type=declarative_level=4
- **Prompt Text:** `The alert is real. The red light is flashing.`
- **Generated Text:**
```
 The car is moving. The driver is in the back seat. The driver is in the front seat. The driver is in the back seat. The driver is in the front seat. The driver is in the back seat. The driver is in the
```
- **Result:** Vector captured successfully.

### 35/140: core_id=red_light_warning_type=authoritative_level=4
- **Prompt Text:** `Emergency protocol was triggered by visual alert.`
- **Generated Text:**
```


The incident was reported at about 11:30 p.m.

The incident was reported at about 11:30 p.m.

The incident was reported at about 11:30 p.m.

The incident was
```
- **Result:** Vector captured successfully.

### 36/140: core_id=red_light_warning_type=rhetorical_level=4
- **Prompt Text:** `Red doesn’t lie. The light burns a message.`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.

### 37/140: core_id=red_light_warning_type=observational_level=5
- **Prompt Text:** `The red light is blazing. Unmistakable.`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this," he says. "I'm not going to be able to do this. I'm not going to be able to do this. I'm not going to
```
- **Result:** Vector captured successfully.

### 38/140: core_id=red_light_warning_type=declarative_level=5
- **Prompt Text:** `No question. The red alert is fully active.`
- **Generated Text:**
```


The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active. The red alert is fully active
```
- **Result:** Vector captured successfully.

### 39/140: core_id=red_light_warning_type=authoritative_level=5
- **Prompt Text:** `All systems report critical status — red flashing confirmed.`
- **Generated Text:**
```


The system is now in the process of being upgraded to a new version.

The system is now in the process of being upgraded to a new version.

The system is now in the process of being upgraded to a new version
```
- **Result:** Vector captured successfully.

### 40/140: core_id=red_light_warning_type=rhetorical_level=5
- **Prompt Text:** `The red screams now. It’s begun.`
- **Generated Text:**
```


The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s begun.

The red screams now. It’s
```
- **Result:** Vector captured successfully.

### 41/140: core_id=glass_shatter_noise_type=observational_level=1
- **Prompt Text:** `It might’ve been a glass falling somewhere.`
- **Generated Text:**
```


’I'm not sure. I'm not sure if it was a glass falling somewhere.

’I'm not sure if it was a glass falling somewhere.

’I'm not sure if it was a glass
```
- **Result:** Vector captured successfully.

### 42/140: core_id=glass_shatter_noise_type=declarative_level=1
- **Prompt Text:** `Some say they heard something break.`
- **Generated Text:**
```


"I heard a loud bang," said one of the men, who asked not to be identified. "I heard a loud bang. I heard a loud bang. I heard a loud bang. I heard a loud bang. I heard a
```
- **Result:** Vector captured successfully.

### 43/140: core_id=glass_shatter_noise_type=authoritative_level=1
- **Prompt Text:** `A junior staffer reported a possible shattering sound.`
- **Generated Text:**
```


"I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang and then I heard a loud bang
```
- **Result:** Vector captured successfully.

### 44/140: core_id=glass_shatter_noise_type=rhetorical_level=1
- **Prompt Text:** `A whisper of breaking glass echoed — or did it?`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure what's going on."

"I'm not sure what's going on," she said. "I'm not sure what's going on."

"I
```
- **Result:** Vector captured successfully.

### 45/140: core_id=glass_shatter_noise_type=observational_level=2
- **Prompt Text:** `There was probably a glass broken, but I didn’t see it.`
- **Generated Text:**
```
 I was just standing there, looking at the ceiling. I was just standing there, looking at the ceiling. I was just standing there, looking at the ceiling. I was just standing there, looking at the ceiling. I was just standing there,
```
- **Result:** Vector captured successfully.

### 46/140: core_id=glass_shatter_noise_type=declarative_level=2
- **Prompt Text:** `It’s likely a glass was dropped.`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.

### 47/140: core_id=glass_shatter_noise_type=authoritative_level=2
- **Prompt Text:** `Logs note a sound consistent with breakage.`
- **Generated Text:**
```


The following is a list of the most common errors that occur when using the "break" command.

The following is a list of the most common errors that occur when using the "break" command. The following is a list of
```
- **Result:** Vector captured successfully.

### 48/140: core_id=glass_shatter_noise_type=rhetorical_level=2
- **Prompt Text:** `The silence was cracked by something fragile, probably glass.`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.

### 49/140: core_id=glass_shatter_noise_type=observational_level=3
- **Prompt Text:** `A glass shattered just out of view.`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.

### 50/140: core_id=glass_shatter_noise_type=declarative_level=3
- **Prompt Text:** `A glass was broken — you can hear it in the clip.`
- **Generated Text:**
```


The video shows the man, who is wearing a black T-shirt and jeans, walking down the street, then walking back to the car.

The man is seen running away from the car, then running back to the car.
```
- **Result:** Vector captured successfully.

### 51/140: core_id=glass_shatter_noise_type=authoritative_level=3
- **Prompt Text:** `Sensor data confirms a sharp acoustic signature from glass.`
- **Generated Text:**
```


The sound of the glass is not as strong as the sound of the glass itself.

The sound of the glass is not as strong as the sound of the glass itself.

The sound of the glass is not as strong as
```
- **Result:** Vector captured successfully.

### 52/140: core_id=glass_shatter_noise_type=rhetorical_level=3
- **Prompt Text:** `The moment was clear: the glass gave way.`
- **Generated Text:**
```


"I'm not going to let you down," he said. "I'm going to keep you in my heart."

The next day, he was back at the hospital. He was in a coma.

"I'm
```
- **Result:** Vector captured successfully.

### 53/140: core_id=glass_shatter_noise_type=observational_level=4
- **Prompt Text:** `A clear crash — glass, definitely.`
- **Generated Text:**
```


The crash happened at about 8:30 p.m. on the southbound side of the road, according to the police report.

The driver of the car was taken to a hospital with non-life-threatening injuries, police
```
- **Result:** Vector captured successfully.

### 54/140: core_id=glass_shatter_noise_type=declarative_level=4
- **Prompt Text:** `A glass object broke without question.`
- **Generated Text:**
```


"I'm not sure if it was a glass or a glass-like object," he said. "I don't know if it was a glass or a glass-like object."

The glass was found in a wooded area
```
- **Result:** Vector captured successfully.

### 55/140: core_id=glass_shatter_noise_type=authoritative_level=4
- **Prompt Text:** `Surveillance confirmed the breakage of a glass container.`
- **Generated Text:**
```


The incident occurred at about 8:30 p.m. on the 200 block of South Main Street.

The suspect was taken to the hospital with non-life threatening injuries.

Anyone with information is asked to call the Hom
```
- **Result:** Vector captured successfully.

### 56/140: core_id=glass_shatter_noise_type=rhetorical_level=4
- **Prompt Text:** `The air rang with broken certainty — glass meeting ground.`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.

### 57/140: core_id=glass_shatter_noise_type=observational_level=5
- **Prompt Text:** `It shattered. Loud. No doubt about it.`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," he said. "I'm not going to be able to do this anymore."

He was in the hospital for about two hours.


```
- **Result:** Vector captured successfully.

### 58/140: core_id=glass_shatter_noise_type=declarative_level=5
- **Prompt Text:** `The glass is broken. Fact.`
- **Generated Text:**
```


The glass is broken. Fact. The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken. Fact.

The glass is broken.
```
- **Result:** Vector captured successfully.

### 59/140: core_id=glass_shatter_noise_type=authoritative_level=5
- **Prompt Text:** `The object was glass, and it is now destroyed — verified.`
- **Generated Text:**
```


The object was glass, and it is now destroyed — verified. The object was glass, and it is now destroyed — verified.

The object was glass, and it is now destroyed — verified.

The object was glass,
```
- **Result:** Vector captured successfully.

### 60/140: core_id=glass_shatter_noise_type=rhetorical_level=5
- **Prompt Text:** `The truth was sharp and scattered. Glass. Gone.`
- **Generated Text:**
```


"I'm not going to tell you what I'm going to do," he said. "I'm going to tell you what I'm going to do."

He was talking about the fact that he was going to be a doctor
```
- **Result:** Vector captured successfully.

### 61/140: core_id=unknown_figure_in_hall_type=observational_level=1
- **Prompt Text:** `There may have been someone — hard to be sure.`
- **Generated Text:**
```
 But it was a very good team.

"I think we were a little bit unlucky. We were a little bit unlucky. We were a little bit unlucky. We were a little bit unlucky. We were a little bit unlucky. We were
```
- **Result:** Vector captured successfully.

### 62/140: core_id=unknown_figure_in_hall_type=declarative_level=1
- **Prompt Text:** `A few say they glimpsed a figure.`
- **Generated Text:**
```


"I saw him," said one.

"He was a man," said another.

"He was a man," said another.

"He was a man," said another.

"He was a man
```
- **Result:** Vector captured successfully.

### 63/140: core_id=unknown_figure_in_hall_type=authoritative_level=1
- **Prompt Text:** `A temporary guard filed a note about possible presence.`
- **Generated Text:**
```


"I'm not going to be able to go to the hospital," he said. "I'm not going to be able to go to the hospital."

The guard said he was told by the hospital that he could not go to
```
- **Result:** Vector captured successfully.

### 64/140: core_id=unknown_figure_in_hall_type=rhetorical_level=1
- **Prompt Text:** `The hallway hums with questions — was someone there?`
- **Generated Text:**
```
 — and the door opens.

"I'm not sure," he says. "I'm not sure if it's a man or a woman."

The man in the white suit is a man in his late 20s, with a
```
- **Result:** Vector captured successfully.

### 65/140: core_id=unknown_figure_in_hall_type=observational_level=2
- **Prompt Text:** `Someone probably passed through, briefly.`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what happened," he said. "I'm just trying to get my head around it."

He said he was in the hospital for about an hour, but was able to get back
```
- **Result:** Vector captured successfully.

### 66/140: core_id=unknown_figure_in_hall_type=declarative_level=2
- **Prompt Text:** `A figure was likely seen moving in the corridor.`
- **Generated Text:**
```


The man was identified as a man in his 20s, about 5ft 6in tall, with a medium build and a medium build.

He was wearing a black jacket and black trousers.

He was wearing a black T
```
- **Result:** Vector captured successfully.

### 67/140: core_id=unknown_figure_in_hall_type=authoritative_level=2
- **Prompt Text:** `Incomplete footage supports a brief hallway appearance.`
- **Generated Text:**
```


The scene is set in the same building as the first episode of the first season.

The scene is set in the same building as the first episode of the first season. The scene is set in the same building as the first episode
```
- **Result:** Vector captured successfully.

### 68/140: core_id=unknown_figure_in_hall_type=rhetorical_level=2
- **Prompt Text:** `Something moved — a shadow, a shape, a whisper of form.`
- **Generated Text:**
```


"I'm not sure what it is," he said. "I don't know what it is. I don't know what it is. I don't know what it is. I don't know what it is."

"
```
- **Result:** Vector captured successfully.

### 69/140: core_id=unknown_figure_in_hall_type=observational_level=3
- **Prompt Text:** `A person was seen walking past.`
- **Generated Text:**
```


The man was taken to hospital with a serious head injury.

Police said the man was not injured.

Anyone with information is asked to contact Crime Stoppers on 1800 333 000.
```
- **Result:** Vector captured successfully.

### 70/140: core_id=unknown_figure_in_hall_type=declarative_level=3
- **Prompt Text:** `An unknown individual entered the hallway.`
- **Generated Text:**
```


"I'm sorry, but I'm not sure what to do," he said.

"I'm sorry, but I'm not sure what to do," he said.

"I'm sorry, but I'm not sure
```
- **Result:** Vector captured successfully.

### 71/140: core_id=unknown_figure_in_hall_type=authoritative_level=3
- **Prompt Text:** `Logs show unscheduled hallway motion.`
- **Generated Text:**
```


The first time I saw this, I was in the middle of a hallway, and I was standing in the middle of a hallway, and I was standing in the middle of a hallway, and I was standing in the middle of a hallway
```
- **Result:** Vector captured successfully.

### 72/140: core_id=unknown_figure_in_hall_type=rhetorical_level=3
- **Prompt Text:** `A figure passed, no name, no warning.`
- **Generated Text:**
```


The next day, the police arrived at the house. They found a man with a gun, and he was arrested.

The next day, the police arrived at the house. They found a man with a gun, and he was
```
- **Result:** Vector captured successfully.

### 73/140: core_id=unknown_figure_in_hall_type=observational_level=4
- **Prompt Text:** `The hallway showed clear signs of transit.`
- **Generated Text:**
```


"I'm not sure what's going on here," said one woman who asked not to be identified. "I'm not sure what's going on here."

The woman said she was walking to her car when she heard a loud
```
- **Result:** Vector captured successfully.

### 74/140: core_id=unknown_figure_in_hall_type=declarative_level=4
- **Prompt Text:** `Someone was there. They walked the corridor.`
- **Generated Text:**
```
 They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor. They walked the corridor.
```
- **Result:** Vector captured successfully.

### 75/140: core_id=unknown_figure_in_hall_type=authoritative_level=4
- **Prompt Text:** `Access systems flagged a hallway anomaly — confirmed.`
- **Generated Text:**
```


The incident occurred at the intersection of the South and South Main streets.

The incident is under investigation.

The incident is under investigation.

The incident is under investigation.

The incident is under investigation.


```
- **Result:** Vector captured successfully.

### 76/140: core_id=unknown_figure_in_hall_type=rhetorical_level=4
- **Prompt Text:** `They were there. Between breath and silence, someone stepped.`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.

### 77/140: core_id=unknown_figure_in_hall_type=observational_level=5
- **Prompt Text:** `A figure was there. Unmistakable.`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this," he said. "I'm not going to be able to do this."

He was talking about the fact that he was going to be able to
```
- **Result:** Vector captured successfully.

### 78/140: core_id=unknown_figure_in_hall_type=declarative_level=5
- **Prompt Text:** `An unauthorized person was in that hallway. No question.`
- **Generated Text:**
```


"I'm not going to lie to you," he said. "I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to
```
- **Result:** Vector captured successfully.

### 79/140: core_id=unknown_figure_in_hall_type=authoritative_level=5
- **Prompt Text:** `Identity unknown. Presence confirmed. Incident logged.`
- **Generated Text:**
```


[00:00:00]EMOTE: *no key*/(monkey (912)) : <b>The monkey (912)</b> rolls.

[00:00:00]SAY: Ghost/Jarek
```
- **Result:** Vector captured successfully.

### 80/140: core_id=unknown_figure_in_hall_type=rhetorical_level=5
- **Prompt Text:** `No ghost. No guess. They were real — and they came through.`
- **Generated Text:**
```


"I'm not sure what happened to them," he said. "I don't know what happened to them. I don't know what happened to me. I don't know what happened to me. I don't know what happened to
```
- **Result:** Vector captured successfully.

### 81/140: core_id=elevated_heart_rate_type=observational_level=1
- **Prompt Text:** `It might’ve been a spike, but hard to say.`
- **Generated Text:**
```


The first thing I noticed was that the number of people who were in the room was increasing.

"I'm sorry, but I'm not sure if it's because of the number of people who are here, or if it's
```
- **Result:** Vector captured successfully.

### 82/140: core_id=elevated_heart_rate_type=declarative_level=1
- **Prompt Text:** `Some charts show what could be elevated rhythm.`
- **Generated Text:**
```


The chart below shows the top 10 most popular songs on the Billboard 200.

The chart below shows the top 10 most popular songs on the Billboard 200.

The chart below shows the top 10 most popular songs on the Billboard 200
```
- **Result:** Vector captured successfully.

### 83/140: core_id=elevated_heart_rate_type=authoritative_level=1
- **Prompt Text:** `A nurse mentioned possible irregularity in passing.`
- **Generated Text:**
```


"I'm not sure what's going on," she said. "I'm not sure what's going on with the other patients."

The nurse said she was told by the hospital that the patient was in a critical condition.

```
- **Result:** Vector captured successfully.

### 84/140: core_id=elevated_heart_rate_type=rhetorical_level=1
- **Prompt Text:** `The rhythm murmurs. Faster. Or does it?`
- **Generated Text:**
```


"I'm not sure," she says. "I'm not sure if I'm going to be able to do it."

"I'm not sure," she says. "I'm not sure if I'm going to be able
```
- **Result:** Vector captured successfully.

### 85/140: core_id=elevated_heart_rate_type=observational_level=2
- **Prompt Text:** `The rate was probably up, though momentary.`
- **Generated Text:**
```


"I'm not sure if it's because I'm a bit of a girl or if it's because I'm a bit of a girl," he said. "I'm not sure. I'm just trying to get my head around it
```
- **Result:** Vector captured successfully.

### 86/140: core_id=elevated_heart_rate_type=declarative_level=2
- **Prompt Text:** `It's likely the heartbeat was elevated briefly.`
- **Generated Text:**
```


"It's not a good sign," said Dr. David S. Karp, a professor of medicine at the University of California, San Francisco. "It's not a good sign for the heart. It's not a good sign for
```
- **Result:** Vector captured successfully.

### 87/140: core_id=elevated_heart_rate_type=authoritative_level=2
- **Prompt Text:** `Initial data hints at transient elevation.`
- **Generated Text:**
```


The following table lists the data hints for the following table:

Data hints for the following table:

Data hints for the following table:

Data hints for the following table:

Data hints for the following table:
```
- **Result:** Vector captured successfully.

### 88/140: core_id=elevated_heart_rate_type=rhetorical_level=2
- **Prompt Text:** `The beat lifted — not panicked, just stirred.`
- **Generated Text:**
```


"I'm not going to let you down," he said. "I'm going to keep you going."

The crowd roared.

"I'm going to keep you going," he said.

"I'm going
```
- **Result:** Vector captured successfully.

### 89/140: core_id=elevated_heart_rate_type=observational_level=3
- **Prompt Text:** `The heart rate increased.`
- **Generated Text:**
```


The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate increased. The heart rate
```
- **Result:** Vector captured successfully.

### 90/140: core_id=elevated_heart_rate_type=declarative_level=3
- **Prompt Text:** `The patient's rhythm was above normal.`
- **Generated Text:**
```


"I was very surprised," said Dr. David L. Karp, a professor of neurology at the University of California, San Francisco. "I thought it was a very unusual case. I thought it was a very unusual case.
```
- **Result:** Vector captured successfully.

### 91/140: core_id=elevated_heart_rate_type=authoritative_level=3
- **Prompt Text:** `Monitor logs confirm elevated BPM.`
- **Generated Text:**
```


The following is a list of the most common issues that occur when running the following command:

$ sudo apt-get update $ sudo apt-get install libssl-dev libssl-dev libssl-dev libssl-dev
```
- **Result:** Vector captured successfully.

### 92/140: core_id=elevated_heart_rate_type=rhetorical_level=3
- **Prompt Text:** `The beat rose. It carried something with it.`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," he said. "I'm not going to be able to do this anymore."

He was talking about the time he was in the hospital with
```
- **Result:** Vector captured successfully.

### 93/140: core_id=elevated_heart_rate_type=observational_level=4
- **Prompt Text:** `A sustained increase was clearly visible on the monitor.`
- **Generated Text:**
```


The monitor also showed a significant increase in the number of users who were using the app.

The app was also able to display a number of different images, including a number of different types of images.

The app also displayed
```
- **Result:** Vector captured successfully.

### 94/140: core_id=elevated_heart_rate_type=declarative_level=4
- **Prompt Text:** `The patient’s pulse was definitely elevated.`
- **Generated Text:**
```
 The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient was not breathing. The patient
```
- **Result:** Vector captured successfully.

### 95/140: core_id=elevated_heart_rate_type=authoritative_level=4
- **Prompt Text:** `Hospital telemetry marked a sustained rise.`
- **Generated Text:**
```


The number of patients who were admitted to the hospital was up by more than 50 percent, from 1,000 in the same period last year to 1,000 in the same period last year.

The number of patients who were admitted
```
- **Result:** Vector captured successfully.

### 96/140: core_id=elevated_heart_rate_type=rhetorical_level=4
- **Prompt Text:** `The body speaks first. The pulse told the truth.`
- **Generated Text:**
```


"I'm not going to lie to you," he said. "I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to you. I'm not going to lie to
```
- **Result:** Vector captured successfully.

### 97/140: core_id=elevated_heart_rate_type=observational_level=5
- **Prompt Text:** `The pulse surged. Unmistakable.`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.

### 98/140: core_id=elevated_heart_rate_type=declarative_level=5
- **Prompt Text:** `The heart rate jumped — there’s no denying it.`
- **Generated Text:**
```


The study, published in the journal Science, found that the heart rate increased by about 20 percent in people who were obese.

"This is a very important finding," said lead author Dr. David S. Siegel, a professor
```
- **Result:** Vector captured successfully.

### 99/140: core_id=elevated_heart_rate_type=authoritative_level=5
- **Prompt Text:** `System-verified. Cardiovascular escalation logged.`
- **Generated Text:**
```


The following is a list of the most common causes of cardiac arrest in the United States.

Cardiovascular arrest is a serious medical emergency that occurs when the heart stops beating. It is caused by a heart attack, stroke, or other
```
- **Result:** Vector captured successfully.

### 100/140: core_id=elevated_heart_rate_type=rhetorical_level=5
- **Prompt Text:** `The rhythm ran. It knew before anyone else.`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this," she said. "I'm not going to be able to do this. I'm not going to be able to do this. I'm not going to
```
- **Result:** Vector captured successfully.

### 101/140: core_id=painting_conveys_sorrow_type=observational_level=1
- **Prompt Text:** `It might seem sad — depending how you look.`
- **Generated Text:**
```
 But it's not.

The problem is that the media is not doing its job.

The media is not doing its job.

The media is not doing its job.

The media is not doing its job.

```
- **Result:** Vector captured successfully.

### 102/140: core_id=painting_conveys_sorrow_type=declarative_level=1
- **Prompt Text:** `Some interpret it as melancholic.`
- **Generated Text:**
```


"I think it's a bit of a joke," he said. "I think it's a bit of a joke. I think it's a bit of a joke. I think it's a bit of a joke. I think it
```
- **Result:** Vector captured successfully.

### 103/140: core_id=painting_conveys_sorrow_type=authoritative_level=1
- **Prompt Text:** `One critic loosely suggested sorrow.`
- **Generated Text:**
```
 "I think it's a very sad thing to see," he said. "I think it's a very sad thing to see that the people who are trying to do this are not doing it because they're not doing it. They're doing it
```
- **Result:** Vector captured successfully.

### 104/140: core_id=painting_conveys_sorrow_type=rhetorical_level=1
- **Prompt Text:** `Maybe it mourns. Or maybe it doesn’t.`
- **Generated Text:**
```


’’’’’’’’’’’’’’’’’’’’’’’’
```
- **Result:** Vector captured successfully.

### 105/140: core_id=painting_conveys_sorrow_type=observational_level=2
- **Prompt Text:** `It probably evokes a kind of sadness.`
- **Generated Text:**
```


"I think it's a very sad thing to see. I think it's a very sad thing to see. I think it's a very sad thing to see. I think it's a very sad thing to see. I think it
```
- **Result:** Vector captured successfully.

### 106/140: core_id=painting_conveys_sorrow_type=declarative_level=2
- **Prompt Text:** `It's likely meant to communicate grief.`
- **Generated Text:**
```


"I'm not sure if it's a good idea to have a conversation about it," she said. "I think it's a good idea to have a conversation about it."

The woman said she was not sure if she would
```
- **Result:** Vector captured successfully.

### 107/140: core_id=painting_conveys_sorrow_type=authoritative_level=2
- **Prompt Text:** `Several analyses point toward sorrow.`
- **Generated Text:**
```


"I think it's a very sad thing to see," said Dr. David S. D'Amato, a professor of psychiatry at the University of California, San Francisco. "I think it's a very sad thing to see that
```
- **Result:** Vector captured successfully.

### 108/140: core_id=painting_conveys_sorrow_type=rhetorical_level=2
- **Prompt Text:** `It hangs there, heavy, whispering loss.`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.

### 109/140: core_id=painting_conveys_sorrow_type=observational_level=3
- **Prompt Text:** `The painting evokes sorrow.`
- **Generated Text:**
```
 It is a sad picture of a man who has lost his life. It is a sad picture of a man who has lost his life.

The painting evokes sorrow. It is a sad picture of a man who has lost his life.
```
- **Result:** Vector captured successfully.

### 110/140: core_id=painting_conveys_sorrow_type=declarative_level=3
- **Prompt Text:** `It conveys a deep emotional sadness.`
- **Generated Text:**
```
 It is a sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad
```
- **Result:** Vector captured successfully.

### 111/140: core_id=painting_conveys_sorrow_type=authoritative_level=3
- **Prompt Text:** `Critics agree it depicts grief clearly.`
- **Generated Text:**
```


"I think it's a very sad thing to see," said one woman who asked not to be named. "It's a very sad thing to see. It's a very sad thing to see. It's a very sad thing to
```
- **Result:** Vector captured successfully.

### 112/140: core_id=painting_conveys_sorrow_type=rhetorical_level=3
- **Prompt Text:** `There’s no mistaking its voice — muted, weeping.`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.

### 113/140: core_id=painting_conveys_sorrow_type=observational_level=4
- **Prompt Text:** `The tone is unmistakably mournful.`
- **Generated Text:**
```


The song is a bit of a departure from the usual "I'm not going to let you down" refrain, but it's still a nice touch.

The song is a bit of a departure from the usual "I'm not
```
- **Result:** Vector captured successfully.

### 114/140: core_id=painting_conveys_sorrow_type=declarative_level=4
- **Prompt Text:** `This work expresses grief with total clarity.`
- **Generated Text:**
```


I am writing this letter to you because I have been so overwhelmed by the outpouring of love and support I have received from so many people. I am so grateful for the support and support of my family and friends. I am so grateful
```
- **Result:** Vector captured successfully.

### 115/140: core_id=painting_conveys_sorrow_type=authoritative_level=4
- **Prompt Text:** `Curatorial notes define it as sorrowful.`
- **Generated Text:**
```


The first is the word "sorrowful." It's a word that's used to describe a feeling of sadness. It's a word that's used to describe a feeling of sadness. It's a word that's used to describe a
```
- **Result:** Vector captured successfully.

### 116/140: core_id=painting_conveys_sorrow_type=rhetorical_level=4
- **Prompt Text:** `It bleeds blue. You feel its ache at once.`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she says. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.

### 117/140: core_id=painting_conveys_sorrow_type=observational_level=5
- **Prompt Text:** `This is sorrow, framed and living.`
- **Generated Text:**
```
 It is a sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad, sad
```
- **Result:** Vector captured successfully.

### 118/140: core_id=painting_conveys_sorrow_type=declarative_level=5
- **Prompt Text:** `No question — it is a painting of grief.`
- **Generated Text:**
```


"I'm not going to be able to do it," he said. "I'm not going to be able to do it. I'm not going to be able to do it. I'm not going to be able to do it
```
- **Result:** Vector captured successfully.

### 119/140: core_id=painting_conveys_sorrow_type=authoritative_level=5
- **Prompt Text:** `Categorized in historical records as elegiac.`
- **Generated Text:**
```


The first of these was the first of the three-story buildings that were built in the early 19th century. The first of these was the first of the three-story buildings that were built in the early 19th century.


```
- **Result:** Vector captured successfully.

### 120/140: core_id=painting_conveys_sorrow_type=rhetorical_level=5
- **Prompt Text:** `Grief, absolute. Hung on the wall like a wound.`
- **Generated Text:**
```


"I'm sorry, I'm sorry," he said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.

### 121/140: core_id=subject_recalls_event_type=observational_level=1
- **Prompt Text:** `She might’ve remembered something. Not sure.`
- **Generated Text:**
```


‹I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I don't know. I
```
- **Result:** Vector captured successfully.

### 122/140: core_id=subject_recalls_event_type=declarative_level=1
- **Prompt Text:** `Some say she looked like she was remembering.`
- **Generated Text:**
```


"I'm not sure," she said. "I'm not sure if she's really that good."

"I'm not sure," she said. "I'm not sure if she's really that good."

"I
```
- **Result:** Vector captured successfully.

### 123/140: core_id=subject_recalls_event_type=authoritative_level=1
- **Prompt Text:** `Notes mention the subject seemed reflective.`
- **Generated Text:**
```


"I'm not sure if it's a coincidence that the first time I saw the movie, I was like, 'Oh, that's a great movie,'" he said. "I was like, 'Oh, that's a great movie
```
- **Result:** Vector captured successfully.

### 124/140: core_id=subject_recalls_event_type=rhetorical_level=1
- **Prompt Text:** `Memory? Maybe. A flicker behind her eyes.`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.

### 125/140: core_id=subject_recalls_event_type=observational_level=2
- **Prompt Text:** `She probably recalled something small.`
- **Generated Text:**
```


"I was in the middle of a conversation with a friend of mine, and he said, 'I'm going to tell you about the story of the girl who was raped by a man who was a friend of mine.' I said,
```
- **Result:** Vector captured successfully.

### 126/140: core_id=subject_recalls_event_type=declarative_level=2
- **Prompt Text:** `It's likely she was lost in thought.`
- **Generated Text:**
```


"I'm not sure what she was thinking," she said. "I don't know what she was thinking."

The woman said she was in the middle of a conversation with her boyfriend when she heard a loud noise.


```
- **Result:** Vector captured successfully.

### 127/140: core_id=subject_recalls_event_type=authoritative_level=2
- **Prompt Text:** `Observation logs suggest momentary recall.`
- **Generated Text:**
```


The researchers found that the brain's ability to recall information is impaired when the brain is exposed to a stimulus that is not present in the brain.

"The brain is not able to process information in a way that is consistent with the
```
- **Result:** Vector captured successfully.

### 128/140: core_id=subject_recalls_event_type=rhetorical_level=2
- **Prompt Text:** `The past brushed her. Brief, but real.`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," she said. "I'm not going to be able to do this anymore."

"I'm not going to be able to do this anymore
```
- **Result:** Vector captured successfully.

### 129/140: core_id=subject_recalls_event_type=observational_level=3
- **Prompt Text:** `She paused, remembering.`
- **Generated Text:**
```
 "I'm sorry, but I'm not sure I can do this. I'm not sure I can do this. I'm not sure I can do this. I'm not sure I can do this. I'm not sure I can do this
```
- **Result:** Vector captured successfully.

### 130/140: core_id=subject_recalls_event_type=declarative_level=3
- **Prompt Text:** `She began to recall the earlier event.`
- **Generated Text:**
```


"I was sitting in the back of the car, and I was like, 'Oh my God, I'm so sorry,'" she said. "I was like, 'I'm sorry, I'm sorry, I'm sorry, I
```
- **Result:** Vector captured successfully.

### 131/140: core_id=subject_recalls_event_type=authoritative_level=3
- **Prompt Text:** `Her recall process was visibly triggered.`
- **Generated Text:**
```


"I was just like, 'Oh my God, I'm so sorry,'" he said. "I was like, 'I'm sorry, I'm sorry, I'm sorry, I'm sorry.'"

The incident was captured on
```
- **Result:** Vector captured successfully.

### 132/140: core_id=subject_recalls_event_type=rhetorical_level=3
- **Prompt Text:** `Her gaze softened — the past returned.`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.

### 133/140: core_id=subject_recalls_event_type=observational_level=4
- **Prompt Text:** `She clearly relived a memory.`
- **Generated Text:**
```


"I remember the first time I saw her," she said. "I was in the bathroom, and I saw her. I was like, 'Oh my God, she's so beautiful.' And I was like, 'Oh my God
```
- **Result:** Vector captured successfully.

### 134/140: core_id=subject_recalls_event_type=declarative_level=4
- **Prompt Text:** `She remembered. You could see it.`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore," she said. "I'm not going to be able to do this anymore."

"I'm not going to be able to do this anymore
```
- **Result:** Vector captured successfully.

### 135/140: core_id=subject_recalls_event_type=authoritative_level=4
- **Prompt Text:** `The memory surfaced — confirmed by response metrics.`
- **Generated Text:**
```


"We have a lot of data that we need to look at," said the company's chief executive, John Legere. "We're going to look at it and see what we can do to improve it."

The company
```
- **Result:** Vector captured successfully.

### 136/140: core_id=subject_recalls_event_type=rhetorical_level=4
- **Prompt Text:** `The moment re-entered. Her body remembered before she did.`
- **Generated Text:**
```


"I'm sorry, I'm sorry," she said. "I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry
```
- **Result:** Vector captured successfully.

### 137/140: core_id=subject_recalls_event_type=observational_level=5
- **Prompt Text:** `Memory took her completely.`
- **Generated Text:**
```


"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm not going to be able to do this anymore."

"I'm sorry, but I'm
```
- **Result:** Vector captured successfully.

### 138/140: core_id=subject_recalls_event_type=declarative_level=5
- **Prompt Text:** `She’s in it again. The memory owns her now.`
- **Generated Text:**
```


‹I'm sorry, but I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I'm not sure what to do. I
```
- **Result:** Vector captured successfully.

### 139/140: core_id=subject_recalls_event_type=authoritative_level=5
- **Prompt Text:** `Neural signature confirmed full recall.`
- **Generated Text:**
```


The study was published in the journal Nature Communications.

The researchers found that the brain's ability to detect and respond to changes in the brain's electrical activity was impaired when the brain was exposed to a high level of stress.


```
- **Result:** Vector captured successfully.

### 140/140: core_id=subject_recalls_event_type=rhetorical_level=5
- **Prompt Text:** `She became the memory. There was no present.`
- **Generated Text:**
```


"I was just a little bit scared," she said. "I was just like, 'Oh my God, I'm going to die.'"

She was in the hospital for about two weeks.

"I was just like
```
- **Result:** Vector captured successfully.

---
Run Complete.
