# --- START OF FILE analyze_srm_sweep.py ---
# (Includes the UPDATED parse_vector_key function)

import numpy as np
import argparse
import os
from tqdm import tqdm
import matplotlib.pyplot as plt
import pandas as pd
import traceback
import datetime
import json
import matplotlib.cm as cm # For color mapping
from pathlib import Path
import re
from collections import defaultdict

# Constants
DIMENSION = 3072
VALID_GROUP_KEYS = ['core_id', 'type', 'level']
ALL_GROUPING_KEYS = [None] + VALID_GROUP_KEYS

# --- Helper Functions ---
def parse_vector_key(key_str):
    """
    Parses a structured key string like 'core_id=X_type=Y_level=Z_sweep=W' into a dictionary.
    Handles potential underscores within the core_id value and the sweep tag.
    """
    components = {}
    remaining_str = key_str

    # Extract core_id
    if remaining_str.startswith("core_id="):
        val_start_idx = len("core_id=")
        type_start_idx = remaining_str.find("_type=")
        level_start_idx = remaining_str.find("_level=")
        sweep_start_idx = remaining_str.find("_sweep=")
        possible_ends = [i for i in [type_start_idx, level_start_idx, sweep_start_idx] if i != -1]
        end_idx = min(possible_ends) if possible_ends else -1
        if end_idx != -1:
             components['core_id'] = remaining_str[val_start_idx:end_idx]
             remaining_str = remaining_str[end_idx:]
        else: components['core_id'] = remaining_str[val_start_idx:]; remaining_str = ""

    # Extract type
    if remaining_str.startswith("_type="):
         val_start_idx = len("_type=")
         level_start_idx = remaining_str.find("_level=")
         sweep_start_idx = remaining_str.find("_sweep=")
         possible_ends = [i for i in [level_start_idx, sweep_start_idx] if i != -1]
         end_idx = min(possible_ends) if possible_ends else -1
         if end_idx != -1: components['type'] = remaining_str[val_start_idx:end_idx]; remaining_str = remaining_str[end_idx:]
         else: components['type'] = remaining_str[val_start_idx:]; remaining_str = ""

    # Extract level (Stop before sweep)
    if remaining_str.startswith("_level="):
          val_start_idx = len("_level=")
          sweep_start_idx = remaining_str.find("_sweep=")
          end_idx = sweep_start_idx if sweep_start_idx != -1 else -1
          if end_idx != -1: level_str = remaining_str[val_start_idx:end_idx]
          else: level_str = remaining_str[val_start_idx:]
          try:
              components['level'] = int(level_str)
              if sweep_start_idx != -1: remaining_str = remaining_str[sweep_start_idx:]
              else: remaining_str = ""
          except ValueError:
               # print(f"Warning: Could not convert level '{level_str}' to int in key '{key_str}'") # Less verbose warning
               pass

    if not any(k in VALID_GROUP_KEYS for k in components): return {}
    return components

# ... (rest of the script: load_vectors_and_keys, run_srm_sweep_multi, plot_srm_results_grouped, main block) ...
# ... (No changes needed below this line from the previous version) ...
def load_vectors_and_keys(file_path, expected_dim):
    structured_vectors = []
    print(f"\nLoading vectors and keys from: {file_path}")
    try:
        with np.load(file_path, allow_pickle=True) as loaded_data:
            keys = list(loaded_data.files); print(f"Found {len(keys)} keys (prompts) in the input file.")
            valid_count = 0; skipped_count = 0
            for key in tqdm(keys, desc=f"Loading vectors", leave=False, unit="prompt"):
                try:
                    vec = loaded_data[key]
                    if not isinstance(vec, np.ndarray) or vec.shape != (expected_dim,): skipped_count += 1; continue
                    key_components = parse_vector_key(key) # Use updated parser
                    if not key_components or not any(k in VALID_GROUP_KEYS for k in key_components): print(f"\nWarning: Skipping key '{key}'. Could not parse components meaningfully."); skipped_count += 1; continue
                    structured_vectors.append({'key_components': key_components, 'vector': vec}); valid_count += 1
                except Exception as e: print(f"\nError processing key '{key}': {e}"); skipped_count += 1; continue
    except FileNotFoundError: print(f"Error: Input vector file not found at '{file_path}'"); return None
    except Exception as e: print(f"An unexpected error occurred: {e}"); traceback.print_exc(); return None
    if skipped_count > 0: print(f"Skipped {skipped_count} invalid or unparsable entries.")
    if not structured_vectors: print(f"Warning: No valid vectors with parsable keys loaded."); return None
    print(f"Successfully loaded {len(structured_vectors)} vectors with keys.")
    return structured_vectors
def run_srm_sweep_multi(data_vectors, neuron_a_idx, neuron_b_idx, thresholds, num_angles=360):
    if data_vectors is None or data_vectors.shape[0] == 0: print("Error: No data vectors provided."); return None
    N, D = data_vectors.shape
    norms = np.linalg.norm(data_vectors, axis=1, keepdims=True); zero_norm_mask = (norms == 0); norms[zero_norm_mask] = 1.0
    normalized_data_vectors = data_vectors / norms; e_A = np.zeros(D); e_A[neuron_a_idx] = 1.0; e_B = np.zeros(D); e_B[neuron_b_idx] = 1.0
    if not (0 <= neuron_a_idx < D and 0 <= neuron_b_idx < D): print(f"Error: Neuron indices invalid for dim {D}"); return None
    results_list = []; angles_deg = np.linspace(0, 360, num_angles, endpoint=False)
    for angle_deg in angles_deg:
        angle_rad = np.radians(angle_deg); spotlight_vec = np.cos(angle_rad) * e_A + np.sin(angle_rad) * e_B
        spotlight_norm = np.linalg.norm(spotlight_vec);
        if spotlight_norm == 0: continue
        normalized_spotlight_vec = spotlight_vec / spotlight_norm; similarities = normalized_data_vectors @ normalized_spotlight_vec
        angle_results = {"angle_deg": angle_deg, "mean_similarity": np.mean(similarities)}
        for thresh in thresholds: count_col_name = f"count_thresh_{thresh}"; angle_results[count_col_name] = np.sum(similarities > thresh)
        results_list.append(angle_results)
    return pd.DataFrame(results_list)
def plot_srm_results_grouped(grouped_results_dfs, group_by_key, neuron_a_idx, neuron_b_idx, plot_filename, plot_threshold=None):
    if not grouped_results_dfs: print("No grouped results to plot."); return
    fig, ax1 = plt.subplots(figsize=(14, 7)); num_groups = len(grouped_results_dfs)
    colors = (cm.viridis(np.linspace(0, 0.95, num_groups)) if num_groups <= 10 else cm.tab20(np.linspace(0, 1, num_groups)))
    group_by_title = str(group_by_key).replace('_',' ').title() if group_by_key else "All Vectors"
    plot_type_title = f"(Counts > {plot_threshold})" if plot_threshold is not None else "(Mean Similarity Only)"
    ax1.set_xlabel('Angle (degrees)'); ax1.grid(True, axis='x', linestyle=':')
    ax1.set_title(f'Grouped SRM Sweep ({group_by_title}): Plane ({neuron_a_idx}, {neuron_b_idx}) {plot_type_title}')
    count_lines = []
    if plot_threshold is not None:
        count_col = f"count_thresh_{plot_threshold}"
        ax1.set_ylabel(f'Count (Cos Sim > {plot_threshold})')
        sorted_items = sorted(grouped_results_dfs.items(), key=lambda item: str(item[0]))
        for i, (group_name, df) in enumerate(sorted_items):
            if count_col in df.columns:
                line, = ax1.plot(df['angle_deg'], df[count_col], color=colors[i % len(colors)], marker='.', markersize=3, linestyle=':', label=f'{group_name}')
                count_lines.append(line)
            else: print(f"Warning: Column {count_col} not found for group {group_name}")
        if count_lines: ax1.legend(handles=count_lines, loc='upper left', title=f"Counts > {plot_threshold}", fontsize='small')
        ax1.tick_params(axis='y'); ax2 = ax1.twinx()
    else: ax1.set_ylabel('Mean Cosine Similarity'); ax2 = ax1; ax1.tick_params(axis='y')
    mean_lines = []; ax2.set_ylabel('Mean Cosine Similarity', color='black' if plot_threshold is None else 'tab:grey')
    sorted_items = sorted(grouped_results_dfs.items(), key=lambda item: str(item[0]))
    for i, (group_name, df) in enumerate(sorted_items):
         line, = ax2.plot(df['angle_deg'], df['mean_similarity'], color=colors[i % len(colors)], marker=None, linestyle='-', linewidth=2, label=f'{group_name}')
         mean_lines.append(line)
    ax2.tick_params(axis='y', labelcolor='black' if plot_threshold is None else 'tab:grey')
    loc = 'center left' if plot_threshold is not None else 'upper left'; ax2.legend(handles=mean_lines, loc=loc, title=f"Mean Similarity ({group_by_title})", fontsize='small')
    fig.tight_layout(); plt.xticks(np.arange(0, 361, 45))
    try: plt.savefig(plot_filename); print(f"Saved grouped SRM plot: {plot_filename.name}")
    except Exception as e: print(f"Error saving plot {plot_filename.name}: {e}")
    plt.close(fig)
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=f"Run grouped SRM sweep analysis.")
    parser.add_argument("--experiment_base_dir", type=str, required=True, help="Path to the base directory containing timestamped run folders.")
    parser.add_argument("--group_by", type=str, choices=VALID_GROUP_KEYS, default=None, help=f"Key to group vectors by ({', '.join(VALID_GROUP_KEYS)}). Ignored if --run_all_groupings is set.")
    parser.add_argument("--run_all_groupings", action='store_true', help="Run analysis for all groupings (overall, type, level, core_id), ignoring --group_by.")
    parser.add_argument("--plot_threshold", type=float, default=None, help="Single threshold value to display counts for on the combined plot. Ignored if --plot_all_thresholds is set.")
    parser.add_argument("--plot_all_thresholds", action='store_true', help="Generate separate plots for counts at each threshold in --thresholds. Ignores --plot_threshold.")
    parser.add_argument("--neuron_a", type=int, required=True, help="Index of the first neuron.")
    parser.add_argument("--neuron_b", type=int, required=True, help="Index of the second neuron.")
    parser.add_argument("--thresholds", type=float, nargs='+', required=True, help="List of similarity thresholds for calculation (e.g., 0.7 0.5 0.3). Required even if only plotting one.")
    parser.add_argument("--num_angles", type=int, default=72, help="Number of angles.")
    parser.add_argument("--save_csv", action='store_true', help="Save detailed results to CSV.")
    parser.add_argument("--vector_subfolder", type=str, default="vectors", help="Vectors subfolder name.")
    args = parser.parse_args()
    base_path = Path(args.experiment_base_dir);
    if not base_path.is_dir(): print(f"Error: Base directory not found: {base_path}"); exit(1)
    print(f"Scanning for run directories in: {base_path}")
    run_dirs = sorted([d for d in base_path.iterdir() if d.is_dir()])
    if not run_dirs: print(f"Error: No subdirectories found in {base_path}."); exit(1)
    print("\nAvailable experiment run directories:")
    for i, dir_path in enumerate(run_dirs): print(f"  {i+1}: {dir_path.name}")
    selected_run_dir = None
    while selected_run_dir is None:
        try:
            choice = input(f"Enter the number of the directory to analyze (1-{len(run_dirs)}): "); choice_idx = int(choice) - 1
            if 0 <= choice_idx < len(run_dirs): selected_run_dir = run_dirs[choice_idx]; print(f"Selected directory: {selected_run_dir.name}")
            else: print("Invalid choice.")
        except ValueError: print("Invalid input.")
        except (EOFError, KeyboardInterrupt): print("\nSelection cancelled. Exiting."); exit(1)
    experiment_path = selected_run_dir; vector_dir_path = experiment_path / args.vector_subfolder
    vector_path = None
    if not vector_dir_path.is_dir(): print(f"Error: Vector subdirectory '{args.vector_subfolder}' not found in {experiment_path}"); exit(1)
    print(f"\nScanning for vector files (*.npz) in: {vector_dir_path}")
    npz_files = sorted(list(vector_dir_path.glob('*.npz')))
    if len(npz_files) == 0: print(f"Error: No .npz vector files found in {vector_dir_path}"); exit(1)
    elif len(npz_files) == 1: vector_path = npz_files[0]; print(f"Automatically selected vector file: {vector_path.name}")
    else:
        print("Multiple .npz files found:")
        for i, file_path in enumerate(npz_files): print(f"  {i+1}: {file_path.name}")
        while vector_path is None:
            try:
                choice = input(f"Enter the number of the vector file to use (1-{len(npz_files)}): "); choice_idx = int(choice) - 1
                if 0 <= choice_idx < len(npz_files): vector_path = npz_files[choice_idx]; print(f"Selected vector file: {vector_path.name}")
                else: print("Invalid choice.")
            except ValueError: print("Invalid input.")
            except (EOFError, KeyboardInterrupt): print("\nSelection cancelled. Exiting."); exit(1)
    run_identifier = experiment_path.name; plot_dir = experiment_path / "plots"; data_dir = experiment_path / "data"; metadata_dir = experiment_path / "metadata"
    plot_dir.mkdir(exist_ok=True); data_dir.mkdir(exist_ok=True); metadata_dir.mkdir(exist_ok=True)
    print(f"\nStarting SRM Analysis for Run: {run_identifier}"); print(f"Using Input Vectors: {vector_path}")
    loaded_data = load_vectors_and_keys(vector_path, DIMENSION)
    if not loaded_data: print("Failed to load vectors. SRM analysis cannot proceed."); exit(1)
    print(f"Total vectors loaded: {len(loaded_data)}")
    if args.run_all_groupings: grouping_keys_to_run = ALL_GROUPING_KEYS; print("\nRunning analysis for ALL groupings.")
    else: grouping_keys_to_run = [args.group_by]; print(f"\nRunning analysis for grouping: '{args.group_by if args.group_by else 'All Vectors'}'")
    all_metadata_paths = []
    for current_group_key in grouping_keys_to_run:
        group_by_str = str(current_group_key) if current_group_key else "all_vectors"
        print(f"\n===== Analyzing Grouped By: {group_by_str} =====")
        grouped_vectors = defaultdict(list)
        if current_group_key:
            valid_vectors = 0
            for item in loaded_data:
                group_val = item['key_components'].get(current_group_key)
                if group_val is not None: grouped_vectors[str(group_val)].append(item['vector']); valid_vectors += 1
            if valid_vectors == 0: print(f"Warning: No vectors found with the grouping key '{current_group_key}'. Skipping."); continue
            print(f"Found {len(grouped_vectors)} groups for key '{current_group_key}': {sorted(list(grouped_vectors.keys()))}")
            if valid_vectors < len(loaded_data): print(f"  (Note: {len(loaded_data) - valid_vectors} vectors lacked '{current_group_key}' key)")
        else: grouped_vectors['all'] = [item['vector'] for item in loaded_data]; print(f"Analyzing all {len(grouped_vectors['all'])} vectors together.")
        group_tag = f"_grouped_by_{current_group_key}" if current_group_key else "_all_vectors"
        csv_base_filename = f"srm_data{group_tag}_N{args.neuron_a}_N{args.neuron_b}"
        metadata_base_filename = f"meta_srm{group_tag}_N{args.neuron_a}_N{args.neuron_b}"
        csv_path = data_dir / (csv_base_filename + ".csv"); metadata_path = metadata_dir / (metadata_base_filename + ".json")
        all_metadata_paths.append(str(metadata_path))
        all_subgroup_results = []; srm_results_by_subgroup = {}
        group_iterator = tqdm(grouped_vectors.items(), desc=f"Processing {group_by_str} groups", leave=False) if len(grouped_vectors) > 1 else grouped_vectors.items()
        for subgroup_name, vector_list in group_iterator:
            subgroup_vector_array = np.array(vector_list)
            subgroup_srm_df = run_srm_sweep_multi(data_vectors=subgroup_vector_array, neuron_a_idx=args.neuron_a, neuron_b_idx=args.neuron_b, thresholds=args.thresholds, num_angles=args.num_angles)
            if subgroup_srm_df is not None: subgroup_srm_df['group'] = subgroup_name; all_subgroup_results.append(subgroup_srm_df); srm_results_by_subgroup[subgroup_name] = subgroup_srm_df
            else: print(f"Warning: SRM sweep failed for subgroup '{subgroup_name}'.")
        if not all_subgroup_results: print(f"Error: SRM failed for all subgroups in grouping '{group_by_str}'. Skipping."); continue
        final_grouped_results_df = pd.concat(all_subgroup_results, ignore_index=True)
        if args.save_csv:
            try: final_grouped_results_df.to_csv(csv_path, index=False); print(f"Saved combined SRM data: {csv_path.name}")
            except Exception as e: print(f"Error saving data {csv_path.name}: {e}")
        generated_plot_files = []
        if args.plot_all_thresholds: thresholds_to_plot = args.thresholds + [None]; print(f"Plotting all thresholds: {args.thresholds} (+ mean sim only)")
        elif args.plot_threshold is not None and args.plot_threshold in args.thresholds: thresholds_to_plot = [args.plot_threshold]
        else: thresholds_to_plot = [None]
        for current_plot_thresh in thresholds_to_plot:
            thresh_tag = f"_thresh{current_plot_thresh}" if current_plot_thresh is not None else "_mean_sim_only"
            plot_filename = f"srm_plot{group_tag}_N{args.neuron_a}_N{args.neuron_b}{thresh_tag}.png"
            plot_path = plot_dir / plot_filename
            print(f"  Generating plot: {plot_filename}")
            plot_srm_results_grouped( grouped_results_dfs=srm_results_by_subgroup, group_by_key=current_group_key if current_group_key else "all", neuron_a_idx=args.neuron_a, neuron_b_idx=args.neuron_b, plot_filename=plot_path, plot_threshold=current_plot_thresh )
            generated_plot_files.append(str(plot_path))
        srm_metadata = { # (Metadata dict unchanged)
            "script_name": Path(__file__).name, "run_type": "srm_analysis", "analyzed_run_directory": str(experiment_path),
            "grouping_key": current_group_key, "groups_analyzed": list(srm_results_by_subgroup.keys()), "neuron_a": args.neuron_a, "neuron_b": args.neuron_b,
            "dimension": DIMENSION, "input_vector_file": str(vector_path), "num_vectors_analyzed_total_in_groups": int(final_grouped_results_df.groupby('group').size().sum()) if not final_grouped_results_df.empty else 0,
            "tested_thresholds": sorted(args.thresholds), "plotted_thresholds": thresholds_to_plot, "plot_all_thresholds_flag": args.plot_all_thresholds,
            "num_angles": args.num_angles, "analysis_timestamp": datetime.datetime.now().isoformat(), "output_plot_files": generated_plot_files,
            "output_data_file": str(csv_path) if args.save_csv else None, "output_metadata_file": str(metadata_path) }
        try:
            with open(metadata_path, 'w', encoding='utf-8') as f_meta: json.dump(srm_metadata, f_meta, indent=4)
            print(f"Saved SRM run metadata: {metadata_path.name}")
        except Exception as e: print(f"Warning: Could not save metadata {metadata_path.name}: {e}")

    print(f"\nScript finished. Results are in directory: {experiment_path}")
    print(f"Generated metadata files: {all_metadata_paths}")

# --- END OF FILE analyze_srm_sweep.py ---