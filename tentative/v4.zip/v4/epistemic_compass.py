# --- START OF FILE epistemic_compass.py ---

import torch
import argparse
from transformer_lens import HookedTransformer, utils
import warnings
import os
import sys
from tqdm import tqdm
import numpy as np
import traceback # For detailed error printing
import datetime
import json # For saving metadata
import re # For parsing prompt file
from pathlib import Path # For easier path handling

def parse_structured_prompts(filepath):
    """Parses the structured prompt file based on the template format."""
    # (Keep this function exactly the same as before)
    prompts_data = []
    current_core_id = None; current_level = None
    level_pattern = re.compile(r"\[LEVEL (\d+)\]"); core_id_pattern = re.compile(r">> CORE_ID:\s*(.*)")
    type_pattern = re.compile(r"^\s*([a-zA-Z_]+):\s*(.*)")
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line or line.startswith('#') or line.startswith('---') or line.startswith(">> PROPOSITION:"): continue
                core_id_match = core_id_pattern.match(line)
                if core_id_match: current_core_id = core_id_match.group(1).strip().replace(" ", "_"); current_level = None; continue
                level_match = level_pattern.match(line)
                if level_match: current_level = int(level_match.group(1)); continue
                type_match = type_pattern.match(line)
                if type_match:
                    prompt_type = type_match.group(1).lower(); prompt_text = type_match.group(2).strip()
                    if current_core_id and current_level is not None: prompts_data.append({'prompt_text': prompt_text, 'core_id': current_core_id, 'type': prompt_type, 'level': current_level})
                    else: print(f"Warning: Found prompt '{prompt_text}' on line {line_num} but CORE_ID or LEVEL not set. Skipping."); continue
    except FileNotFoundError: print(f"Error: Prompt file not found at '{filepath}'"); return None
    except Exception as e: print(f"Error parsing prompt file '{filepath}': {e}"); traceback.print_exc(); return None
    if not prompts_data: print(f"Warning: No valid prompts parsed from '{filepath}'. Check format."); return None
    print(f"Successfully parsed {len(prompts_data)} prompts from {filepath.name}.")
    return prompts_data

# --- Main Script Logic ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Capture MLP activations for structured epistemic prompts (Baseline). Saves results in a unique timestamped experiment run directory.")
    parser.add_argument("--prompt_file", type=str, required=True, help="Path to the structured prompt file (e.g., epistemic_certainty_grid.txt).")
    parser.add_argument("--experiment_base_dir", type=str, required=True, help="Path to the base directory where the unique run directory will be created (e.g., ./experiments/epistemic_runs).")
    parser.add_argument("--run_prefix", type=str, default="capture", help="Prefix for the timestamped run directory name.")
    parser.add_argument("--generate_length", type=int, default=50, help="Number of new tokens to generate.")
    parser.add_argument("--top_k", type=int, default=None, help="Top-k sampling parameter.")
    parser.add_argument("--layer", type=int, default=11, help="MLP layer index to capture.")
    args = parser.parse_args()

    # --- Setup Paths ---
    base_dir = Path(args.experiment_base_dir)
    prompt_path = Path(args.prompt_file)
    prompt_basename = prompt_path.stem
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir_name = f"{args.run_prefix}_{prompt_basename}_{timestamp}"
    run_path = base_dir / run_dir_name
    try: run_path.mkdir(parents=True, exist_ok=True); print(f"Created unique run directory: {run_path}")
    except OSError as e: print(f"Error creating output directory '{run_path}': {e}", file=sys.stderr); traceback.print_exc(); exit(1)
    vector_dir = run_path / "vectors"; log_dir = run_path / "logs"; metadata_dir = run_path / "metadata"
    vector_dir.mkdir(exist_ok=True); log_dir.mkdir(exist_ok=True); metadata_dir.mkdir(exist_ok=True)
    vector_filename = "captured_vectors.npz"; log_filename = "run_log.md"; metadata_filename = "run_metadata.json"
    vector_path = vector_dir / vector_filename; log_path = log_dir / log_filename; metadata_path = metadata_dir / metadata_filename

    # --- Parse Prompts ---
    parsed_prompts = parse_structured_prompts(prompt_path)
    if not parsed_prompts: print("Exiting due to prompt parsing failure."); exit(1)

    # --- Load Model ---
    print("Loading GPT-2 Small model...")
    try:
        model = HookedTransformer.from_pretrained("gpt2")
        device = "cuda" if torch.cuda.is_available() else "cpu"; model.to(device); model.eval()
        print(f"Using device: {device}")
        tokenizer = model.tokenizer
        if tokenizer.pad_token is None: tokenizer.pad_token = tokenizer.eos_token; model.config.pad_token_id = model.config.eos_token_id
        capture_hook_point_name = f"blocks.{args.layer}.mlp.hook_post"; DIMENSION = model.cfg.d_mlp
    except Exception as e: print(f"Error loading model: {e}", file=sys.stderr); traceback.print_exc(); exit(1)

    # --- Prepare Metadata ---
    run_metadata = {
        "script_name": Path(__file__).name, "run_type": "baseline_capture", "model_name": "gpt2",
        "target_layer": args.layer, "capture_hook": capture_hook_point_name, "activation_dimension": DIMENSION,
        "prompt_file_path": str(prompt_path), "prompt_file_basename": prompt_basename,
        "num_prompts_parsed": len(parsed_prompts), "generate_length": args.generate_length,
        "top_k": args.top_k if args.top_k is not None else "greedy_or_default",
        "run_timestamp": timestamp, "run_directory": str(run_path),
        "output_vector_file": str(vector_path), "output_log_file": str(log_path),
        "output_metadata_file": str(metadata_path), "device": device,
    }
    try:
        with open(metadata_path, 'w', encoding='utf-8') as f_meta: json.dump(run_metadata, f_meta, indent=4)
        print(f"Initial metadata saved to: {metadata_path}")
    except Exception as e: print(f"Warning: Could not save initial metadata file '{metadata_path}': {e}")

    # --- Main Processing ---
    print(f"Starting baseline capture run for {len(parsed_prompts)} prompts.")
    all_vectors = {}

    try:
        with open(log_path, 'w', encoding='utf-8') as logfile:
            logfile.write(f"# Activation Capture Log: {prompt_basename} ({timestamp})\n\n")
            logfile.write("## Run Parameters\n");
            for key, value in run_metadata.items(): logfile.write(f"- **{key.replace('_', ' ').title()}**: `{value}`\n")
            logfile.write("\n---\n\n## Prompt Processing\n\n"); logfile.flush()

            with torch.no_grad(), tqdm(total=len(parsed_prompts), desc=f"Capturing {prompt_basename}", unit="prompt") as pbar:
                for i, prompt_info in enumerate(parsed_prompts):
                    prompt_text = prompt_info['prompt_text']; core_id = prompt_info['core_id']
                    prompt_type = prompt_info['type']; level = prompt_info['level']
                    pbar.set_description(f"{core_id} L{level} {prompt_type[:4]}...")
                    vector_key = f"core_id={core_id}_type={prompt_type}_level={level}"
                    logfile.write(f"### {i+1}/{len(parsed_prompts)}: {vector_key}\n"); logfile.write(f"- **Prompt Text:** `{prompt_text}`\n")

                    try:
                        input_ids = tokenizer(prompt_text, return_tensors="pt")["input_ids"].to(device); input_len = input_ids.shape[1]
                        if input_len == 0: logfile.write("- **Result:** Error - Empty prompt.\n\n"); logfile.flush(); pbar.update(1); continue

                        output_ids = model.generate(input_ids, max_new_tokens=args.generate_length,
                             do_sample=(args.top_k is not None and args.top_k > 0),
                             top_k=args.top_k if (args.top_k is not None and args.top_k > 0) else None,
                             eos_token_id=tokenizer.eos_token_id)

                        generated_len = output_ids.shape[1] - input_len
                        if generated_len > 0:
                             result_text = tokenizer.decode(output_ids[0, input_len:], skip_special_tokens=True)
                             logfile.write(f"- **Generated Text:**\n```\n{result_text}\n```\n")
                        else: logfile.write("- **Generated Text:** (No new tokens)\n- **Result:** Skipped capture.\n\n"); logfile.flush(); pbar.update(1); continue

                        # --- Capture Activations ---
                        # Use a mutable container (list) to hold the value
                        capture_container = [None]

                        # Define the hook function - NO nonlocal needed
                        def save_hook(activation_tensor, hook):
                            # Modify the *content* of the list
                            capture_container[0] = activation_tensor.clone().detach().cpu()

                        fwd_hooks = [(capture_hook_point_name, save_hook)]
                        try:
                            with model.hooks(fwd_hooks=fwd_hooks): model(output_ids, return_type=None)
                        except Exception as e_inner:
                            logfile.write(f"- **Result:** Error during capture forward pass: {e_inner}\n\n")
                            traceback.print_exc(file=sys.stderr); logfile.flush(); pbar.update(1); continue

                        # --- Process and Store Vector ---
                        # Get the captured value from the container
                        captured_mlp_post_activation = capture_container[0]
                        if captured_mlp_post_activation is not None:
                            generated_vectors_tensor = captured_mlp_post_activation[:, input_len:, :]
                            if generated_vectors_tensor.shape[1] > 0:
                                mean_vector_np = np.mean(generated_vectors_tensor.squeeze(0).numpy(), axis=0)
                                if mean_vector_np.shape == (DIMENSION,):
                                    all_vectors[vector_key] = mean_vector_np
                                    logfile.write(f"- **Result:** Vector captured successfully.\n\n")
                                else: logfile.write(f"- **Result:** Error - Mean vector shape mismatch ({mean_vector_np.shape}).\n\n")
                            else: logfile.write("- **Result:** Warning - Sliced activation had 0 length.\n\n")
                        else:
                            # This path indicates the hook didn't modify the container's content
                            logfile.write("- **Result:** Error - Failed to capture activation (container[0] is None).\n\n")

                    except Exception as e:
                        logfile.write(f"- **Result:** ERROR processing this prompt: {str(e)}\n\n")
                        print(f"\n--- ERROR processing {vector_key} ---"); traceback.print_exc(); print(f"--- END ERROR ---")
                    finally: logfile.flush(); pbar.update(1)

            logfile.write("---\nRun Complete.\n")

    except Exception as e:
        print(f"\n--- FATAL ERROR during main processing loop ---"); traceback.print_exc()
        if 'logfile' in locals() and not logfile.closed: logfile.write("\n\nFATAL ERROR occurred.\n")

    # --- Final Saving ---
    final_vector_count = len(all_vectors)
    run_metadata["final_vector_count"] = final_vector_count
    try:
        with open(metadata_path, 'w', encoding='utf-8') as f_meta: json.dump(run_metadata, f_meta, indent=4) # Update metadata
        if all_vectors:
            print(f"\nSaving {final_vector_count} collected mean vectors to {vector_path}...")
            np.savez_compressed(vector_path, **all_vectors)
            print("Vectors saved successfully.")
        else: print(f"\nNo vectors were successfully collected to save to {vector_path}.") # Check log if this happens!
    except Exception as e: print(f"\n--- ERROR saving final vectors or metadata ---"); traceback.print_exc()

    print(f"\nScript finished. Results are in directory: {run_path}") # Point to the unique run directory

# --- END OF FILE epistemic_compass.py ---