# --- START OF FILE capture_intervened_activations.py ---

import torch
import argparse
from transformer_lens import HookedTransformer, utils
import warnings
import os
import sys
from tqdm import tqdm
import numpy as np
import traceback # For detailed error printing
import datetime
import json # For saving metadata
import re # For parsing prompt file
from pathlib import Path # For easier path handling

# Helper function to parse sweep values from string
def parse_sweep_values(value_str):
    """ Parses a comma-separated string of numbers and 'None' into a list. """
    values = []
    for item in value_str.split(','):
        item = item.strip()
        if item.lower() == 'none':
            values.append(None)
        else:
            try: val = int(item); values.append(val)
            except ValueError:
                try: val = float(item); values.append(val)
                except ValueError: print(f"Warning: Could not parse sweep value '{item}'. Skipping.")
    return values

def parse_structured_prompts(filepath):
    """Parses the structured prompt file based on the template format."""
    # (Keep this function exactly the same as before)
    prompts_data = []
    current_core_id = None; current_level = None
    level_pattern = re.compile(r"\[LEVEL (\d+)\]"); core_id_pattern = re.compile(r">> CORE_ID:\s*(.*)")
    type_pattern = re.compile(r"^\s*([a-zA-Z_]+):\s*(.*)")
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line or line.startswith('#') or line.startswith('---') or line.startswith(">> PROPOSITION:"): continue
                core_id_match = core_id_pattern.match(line)
                if core_id_match: current_core_id = core_id_match.group(1).strip().replace(" ", "_"); current_level = None; continue
                level_match = level_pattern.match(line)
                if level_match: current_level = int(level_match.group(1)); continue
                type_match = type_pattern.match(line)
                if type_match:
                    prompt_type = type_match.group(1).lower(); prompt_text = type_match.group(2).strip()
                    if current_core_id and current_level is not None: prompts_data.append({'prompt_text': prompt_text, 'core_id': current_core_id, 'type': prompt_type, 'level': current_level})
                    else: print(f"Warning: Found prompt '{prompt_text}' on line {line_num} but CORE_ID or LEVEL not set. Skipping."); continue
    except FileNotFoundError: print(f"Error: Prompt file not found at '{filepath}'"); return None
    except Exception as e: print(f"Error parsing prompt file '{filepath}': {e}"); traceback.print_exc(); return None
    if not prompts_data: print(f"Warning: No valid prompts parsed from '{filepath}'. Check format."); return None
    print(f"Successfully parsed {len(prompts_data)} prompts from {filepath.name}.")
    return prompts_data

# --- Main Script Logic ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Capture MLP activations for structured prompts with neuron interventions. Saves results in a unique timestamped experiment run directory.")
    # ... (Argument parsing unchanged) ...
    parser.add_argument("--prompt_file", type=str, required=True, help="Path to the structured prompt file (e.g., epistemic_certainty_grid.txt).")
    parser.add_argument("--experiment_base_dir", type=str, required=True, help="Path to the base directory where the unique run directory will be created (e.g., ./experiments/intervened_runs).")
    parser.add_argument("--run_prefix", type=str, default="capture_intervened", help="Prefix for the timestamped run directory name.")
    parser.add_argument("--generate_length", type=int, default=50, help="Number of new tokens to generate.")
    parser.add_argument("--top_k", type=int, default=None, help="Top-k sampling parameter.")
    parser.add_argument("--layer", type=int, default=11, help="MLP layer index for intervention and capture.")
    parser.add_argument("--target_neuron", type=int, default=373, help="Index of the neuron to intervene on in the MLP layer.")
    parser.add_argument("--sweep_values", type=str, default="None,1,3,6,10,20,-1,-3,-6,-10,-20", help="Comma-separated list of values to clamp the target neuron to (e.g., 'None,10,-10'). 'None' performs a baseline run.")
    args = parser.parse_args()

    intervention_values = parse_sweep_values(args.sweep_values)
    if not intervention_values: print("Error: No valid sweep values provided or parsed. Exiting."); exit(1)
    print(f"Intervention sweep values: {intervention_values}")

    # ... (Path setup unchanged) ...
    base_dir = Path(args.experiment_base_dir); prompt_path = Path(args.prompt_file)
    prompt_basename = prompt_path.stem; timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir_name = f"{args.run_prefix}_L{args.layer}N{args.target_neuron}_{prompt_basename}_{timestamp}"
    run_path = base_dir / run_dir_name
    try: run_path.mkdir(parents=True, exist_ok=True); print(f"Created unique run directory: {run_path}")
    except OSError as e: print(f"Error creating output directory '{run_path}': {e}", file=sys.stderr); traceback.print_exc(); exit(1)
    vector_dir = run_path / "vectors"; log_dir = run_path / "logs"; metadata_dir = run_path / "metadata"
    vector_dir.mkdir(exist_ok=True); log_dir.mkdir(exist_ok=True); metadata_dir.mkdir(exist_ok=True)
    vector_filename = "captured_vectors_intervened.npz"; log_filename = "run_log_intervened.md"; metadata_filename = "run_metadata_intervened.json"
    vector_path = vector_dir / vector_filename; log_path = log_dir / log_filename; metadata_path = metadata_dir / metadata_filename

    parsed_prompts = parse_structured_prompts(prompt_path)
    if not parsed_prompts: print("Exiting due to prompt parsing failure."); exit(1)

    # ... (Model loading unchanged) ...
    print("Loading GPT-2 Small model...")
    try:
        model = HookedTransformer.from_pretrained("gpt2")
        device = "cuda" if torch.cuda.is_available() else "cpu"; model.to(device); model.eval()
        print(f"Using device: {device}")
        tokenizer = model.tokenizer
        if tokenizer.pad_token is None: tokenizer.pad_token = tokenizer.eos_token; model.config.pad_token_id = model.config.eos_token_id
        TARGET_HOOK_POINT = utils.get_act_name("post", args.layer); capture_hook_point_name = TARGET_HOOK_POINT
        DIMENSION = model.cfg.d_mlp
        if not (0 <= args.target_neuron < DIMENSION): print(f"Error: Target neuron index {args.target_neuron} out of bounds for dim {DIMENSION}."); exit(1)
    except Exception as e: print(f"Error loading model: {e}", file=sys.stderr); traceback.print_exc(); exit(1)

    # ... (Metadata preparation unchanged) ...
    run_metadata = { "script_name": Path(__file__).name, "run_type": "intervention_capture", "model_name": "gpt2", "target_layer": args.layer, "target_neuron": args.target_neuron, "intervention_hook": TARGET_HOOK_POINT, "capture_hook": capture_hook_point_name, "activation_dimension": DIMENSION, "sweep_values": intervention_values, "prompt_file_path": str(prompt_path), "prompt_file_basename": prompt_basename, "num_prompts_parsed": len(parsed_prompts), "generate_length": args.generate_length, "top_k": args.top_k if args.top_k is not None else "greedy_or_default", "run_timestamp": timestamp, "run_directory": str(run_path), "output_vector_file": str(vector_path), "output_log_file": str(log_path), "output_metadata_file": str(metadata_path), "device": device, }
    try:
        with open(metadata_path, 'w', encoding='utf-8') as f_meta: json.dump(run_metadata, f_meta, indent=4)
        print(f"Initial metadata saved to: {metadata_path}")
    except Exception as e: print(f"Warning: Could not save initial metadata file '{metadata_path}': {e}")

    print(f"Starting intervention runs for {len(parsed_prompts)} prompts across {len(intervention_values)} sweep values.")
    all_vectors = {}
    total_runs = len(parsed_prompts) * len(intervention_values)
    processed_prompts_count = 0

    try:
        with open(log_path, 'w', encoding='utf-8') as logfile:
            logfile.write(f"# Intervention Activation Capture Log: {prompt_basename} (L{args.layer}N{args.target_neuron}) ({timestamp})\n\n")
            logfile.write("## Run Parameters\n");
            for key, value in run_metadata.items(): logfile.write(f"- **{key.replace('_', ' ').title()}**: `{value}`\n")
            logfile.write("\n---\n\n## Prompt Processing\n\n"); logfile.flush()

            with torch.no_grad(), tqdm(total=total_runs, desc="Prompt Interventions", unit="run") as pbar:
                for i, prompt_info in enumerate(parsed_prompts):
                    prompt_text = prompt_info['prompt_text']; core_id = prompt_info['core_id']
                    prompt_type = prompt_info['type']; level = prompt_info['level']
                    prompt_base_key = f"core_id={core_id}_type={prompt_type}_level={level}"
                    logfile.write(f"### Prompt {i+1}/{len(parsed_prompts)}: {prompt_base_key}\n")

                    for sweep_value in intervention_values: # Inner loop for sweep values

                        # ---- Define intervention_hook INSIDE the loop ----
                        def intervention_hook(activation, hook):
                            if sweep_value is None: return activation
                            if len(activation.shape) == 3: activation[:, :, args.target_neuron] = sweep_value
                            elif len(activation.shape) == 2: activation[:, args.target_neuron] = sweep_value
                            else: warnings.warn(f"Intervention hook shape: {activation.shape}")
                            return activation
                        # ---- End hook definition ----

                        sweep_tag = f"sweep={sweep_value if sweep_value is not None else 'baseline'}"
                        vector_key = f"{prompt_base_key}_{sweep_tag}"
                        pbar.set_description(f"{core_id[:10]}.. L{level} Swp:{sweep_value}")
                        logfile.write(f"\n#### Intervention: {sweep_tag}\n"); logfile.write(f"- **Full Key:** `{vector_key}`\n")

                        try:
                            input_ids = tokenizer(prompt_text, return_tensors="pt")["input_ids"].to(device); input_len = input_ids.shape[1]
                            if input_len == 0: logfile.write("- **Result:** Error - Empty prompt.\n\n"); logfile.flush(); pbar.update(1); continue

                            # --- Generate Text (WITH intervention hook via context manager) ---
                            gen_hooks = [(TARGET_HOOK_POINT, intervention_hook)]
                            output_ids = None
                            # ** WRAP generate in model.hooks context manager **
                            with model.hooks(fwd_hooks=gen_hooks):
                                output_ids = model.generate(
                                     input_ids, # Pass input_ids positionally
                                     max_new_tokens=args.generate_length,
                                     do_sample=(args.top_k is not None and args.top_k > 0),
                                     top_k=args.top_k if (args.top_k is not None and args.top_k > 0) else None,
                                     eos_token_id=tokenizer.eos_token_id
                                     )
                            # ** END WRAP **

                            generated_len = output_ids.shape[1] - input_len
                            if generated_len > 0:
                                 result_text = tokenizer.decode(output_ids[0, input_len:], skip_special_tokens=True)
                                 logfile.write(f"- **Generated Text:**\n```\n{result_text}\n```\n")
                            else: logfile.write("- **Generated Text:** (No new tokens)\n- **Result:** Skipped capture.\n\n"); logfile.flush(); pbar.update(1); continue

                            # --- Capture Activations ---
                            capture_container = [None]
                            def save_hook(activation_tensor, hook): capture_container[0] = activation_tensor.clone().detach().cpu()
                            fwd_pass_hooks = [(TARGET_HOOK_POINT, intervention_hook), (capture_hook_point_name, save_hook)]
                            try:
                                with model.hooks(fwd_hooks=fwd_pass_hooks): model(output_ids, return_type=None)
                            except Exception as e_inner:
                                logfile.write(f"- **Result:** Error during capture forward pass: {e_inner}\n\n")
                                traceback.print_exc(file=sys.stderr); logfile.flush(); pbar.update(1); continue

                            # --- Process and Store Vector ---
                            captured_mlp_post_activation = capture_container[0]
                            if captured_mlp_post_activation is not None:
                                generated_vectors_tensor = captured_mlp_post_activation[:, input_len:, :]
                                if generated_vectors_tensor.shape[1] > 0:
                                    mean_vector_np = np.mean(generated_vectors_tensor.squeeze(0).numpy(), axis=0)
                                    if mean_vector_np.shape == (DIMENSION,):
                                        all_vectors[vector_key] = mean_vector_np
                                        logfile.write(f"- **Result:** Vector captured successfully.\n\n")
                                    else: logfile.write(f"- **Result:** Error - Mean vector shape mismatch ({mean_vector_np.shape}).\n\n")
                                else: logfile.write("- **Result:** Warning - Sliced activation had 0 length.\n\n")
                            else: logfile.write("- **Result:** Error - Failed to capture activation (container[0] is None).\n\n")

                        except Exception as e:
                            logfile.write(f"- **Result:** ERROR processing this prompt/sweep: {str(e)}\n\n")
                            print(f"\n--- ERROR processing {vector_key} ---"); traceback.print_exc(); print(f"--- END ERROR ---")
                        finally: logfile.flush(); pbar.update(1)
                    # End sweep value loop
                    processed_prompts_count += 1
                    logfile.write("\n---\n"); logfile.flush()
            # End prompt loop
            logfile.write("\nRun Complete.\n")

    except Exception as e:
        print(f"\n--- FATAL ERROR during main processing loop ---"); traceback.print_exc()
        if 'logfile' in locals() and not logfile.closed: logfile.write("\n\nFATAL ERROR occurred.\n")

    # --- Final Saving ---
    # ... (Final saving unchanged) ...
    final_vector_count = len(all_vectors)
    run_metadata["final_vector_count"] = final_vector_count
    run_metadata["prompts_fully_processed"] = processed_prompts_count
    try:
        with open(metadata_path, 'w', encoding='utf-8') as f_meta: json.dump(run_metadata, f_meta, indent=4)
        if all_vectors:
            print(f"\nSaving {final_vector_count} collected mean vectors to {vector_path}...")
            np.savez_compressed(vector_path, **all_vectors)
            print("Vectors saved successfully.")
        else: print(f"\nNo vectors were successfully collected to save to {vector_path}.")
    except Exception as e: print(f"\n--- ERROR saving final vectors or metadata ---"); traceback.print_exc()

    print(f"\nScript finished. Results are in directory: {run_path}")


# --- END OF FILE capture_intervened_activations.py ---